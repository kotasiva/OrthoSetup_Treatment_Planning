﻿Action()
{

	web_set_sockets_option("SSL_VERSION", "TLS");
	
		//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Portal}")));
	
	// Initialize Throughput Calculations
    // Declare Complex Transaction
	TransactionType = "Simple";
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1, "CAD_00_Portal_URL" );
	
	lr_start_transaction("CAD_00_Portal_URL");


	web_url("SmileDirectClubWeb", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=custom/style.css", ENDITEM, 
		"Url=receiver/js/external/jquery.dotdotdot.min_08EE54CBA886AD0A.js", ENDITEM, 
		"Url=receiver/js/external/hammer.v2.0.8.min_F699A1E56189259A.js", ENDITEM, 
		"Url=receiver/js/external/velocity.min_B218502A82F66680.js", ENDITEM, 
		"Url=receiver/images/1x/CitrixReceiver_WebScreen_CBE548FB8FEE049E.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/js/external/slick.min_FEB62CC230E2BA2A.js", ENDITEM, 
		"Url=receiver/js/ctxs.core.min_33B1CC992A07D57E.js", ENDITEM, 
		"Url=receiver/js/ctxs.webui.min_895B3076E3BA6027.js", ENDITEM, 
		"Url=receiver/images/1x/folder_template_C13BB96DEBC9F30F.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/images/1x/actionSprite_531B7A6FF85CA98E.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/images/common/ReceiverFullScreenBackground_46E559C0E6B5A27B.jpg", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=custom/strings.en.js", ENDITEM, 
		"Url=custom/script.js", ENDITEM, 
		"Url=receiver/images/1x/viewSprite_B2F322BDCB824FAF.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/images/common/authspinner_B0BCD339560CA593.gif", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL2NqTTJXVmxLZW1OTFNISnJWREJMZG5GbGRWbGxTVGNyTVRFMFBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=receiver/images/common/icon_loading_9A0623127A028FEB.png", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL2NFTm9NM1JKUnpObVZFTnpORXhRTUUxT2EyY3lVa3N5TXl0alBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL1duZHhaRlZXV0VWTWRuYzNPRGw2VEhWUUsyRkNTSE5WYVhoclBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL1UxZFNOblpTYkhaRmVUbEJNRzAzTjB3MWNHRkRLMUIyYm1zNFBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL00zZE9NVWROUmtWMFQwZDBhME5yWVRJM2NsaDBia04yUTFkU1QxbFNkVGhXU1ZWQlRXWlNWbFJpZHowLS9pbWFnZQ--?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL2JHRnhlRmhYYmtwdmJqbFVWV3hwVlZaV1EyOXBlbmxITTI5QlBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		LAST);

	web_add_auto_header("X-Citrix-IsUsingHTTPS", 
		"Yes");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

/*Correlation comment: Automatic rules - Do not change!  
Original value='0A1D42FE3C0AEFD92BCF5C2FAD48B106' 
Name ='CitrixXenApp_CsrfToken' 
Type ='Rule' 
AppName ='Citrix_XenApp' 
RuleName ='CsrfToken'*/
	web_reg_save_param_ex(
		"ParamName=CitrixXenApp_CsrfToken",
		"LB/IC=CsrfToken=",
		"RB/IC=;",
		SEARCH_FILTERS,
		"Scope=Cookies",
		LAST);

	web_custom_request("Configuration", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Home/Configuration", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_add_auto_header("Csrf-Token",
		"{CitrixXenApp_CsrfToken}");

	web_custom_request("GetDetectionTicket", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionTicket", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("GetDetectionStatus", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionStatus", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body=ticket=CDT_9nFRkPaYWvAovijmDKzZu5os7s6RSyZrruQNGEX7WtimRnEGyMpb!u0p0vT_wcPb", 
		LAST);

	web_custom_request("GetDetectionStatus_2", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionStatus", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body=ticket=CDT_9nFRkPaYWvAovijmDKzZu5os7s6RSyZrruQNGEX7WtimRnEGyMpb!u0p0vT_wcPb", 
		LAST);

	web_add_cookie("CtxsUserPreferredClient=Native; DOMAIN=storefront.smileco.com");

	web_add_cookie("CtxsClientDetectionDone=true; DOMAIN=storefront.smileco.com");

	web_add_cookie("CtxsHasUpgradeBeenShown=true; DOMAIN=storefront.smileco.com");

	web_submit_data("List", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/List", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=format", "Value=json", ENDITEM, 
		"Name=resourceDetails", "Value=Default", ENDITEM, 
		LAST);

	web_custom_request("GetAuthMethods", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Authentication/GetAuthMethods", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);
	
	
	web_custom_request("Login", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ExplicitAuth/Login", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/vnd.citrix.authenticateresponse-1+xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncType=", 
		EXTRARES, 
		"Url=../receiver/images/1x/CitrixStoreFront_auth_14B96BFF2B0A6FF8.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=../receiver/images/1x/spinner_white_auth_button_53FD5A337A529DA7.gif", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		LAST);

	web_submit_data("LoginAttempt", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ExplicitAuth/LoginAttempt", 
		"Method=POST", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=username", "Value={UserName}", ENDITEM, 
		"Name=password", "Value={Password}", ENDITEM, 
		"Name=saveCredentials", "Value=false", ENDITEM, 
		"Name=loginBtn", "Value=Log On", ENDITEM, 
		"Name=StateContext", "Value=", ENDITEM, 
		LAST);

	web_revert_auto_header("Csrf-Token");

	web_revert_auto_header("X-Citrix-IsUsingHTTPS");

	web_revert_auto_header("X-Requested-With");

	web_custom_request("reportDetectionStatus", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClub/clientAssistant/reportDetectionStatus", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"Body=ticket=CDT_9nFRkPaYWvAovijmDKzZu5os7s6RSyZrruQNGEX7WtimRnEGyMpb!u0p0vT_wcPb&protocolVersion=1&hdxVersion=14.7.0.13011&hdxIsPassthrough=False&hdxIsPassthroughVariable=False", 
		LAST);

//	web_add_cookie("CtxsPasswordChangeAllowed=true; DOMAIN=storefront.smileco.com");

	web_add_auto_header("Csrf-Token",
		"{CitrixXenApp_CsrfToken}");

	web_add_auto_header("X-Citrix-IsUsingHTTPS", 
		"Yes");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_submit_data("List_2", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/List", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=format", "Value=json", ENDITEM, 
		"Name=resourceDetails", "Value=Default", ENDITEM, 
		EXTRARES, 
		"Url=../receiver/images/1x/CitrixReceiverLogo_Home_5C24BCEC5A182425.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=../receiver/images/1x/spinner_5CF0D1C8A76AAC8E.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=../receiver/images/1x/search_close_BC5A22358E58905F.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=../receiver/images/1x/ico_search_E84E3D63D821F80D.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		LAST);

	web_custom_request("GetUserName", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Authentication/GetUserName", 
		"Method=POST", 
		"Resource=0", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("AllowSelfServiceAccountManagement", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ExplicitAuth/AllowSelfServiceAccountManagement", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);
	
		lr_end_transaction("CAD_00_Portal_URL", LR_AUTO);

//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_00_Portal_URL");


	lr_think_time(45);

	lr_start_transaction("CAD_BP3_01_CLick_ICA");

	web_submit_data("{ICA_FILE}", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/GetLaunchStatus/{ICA_FILE}", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=displayNameDesktopTitle", "Value={CITRIX_DESKTOP}", ENDITEM, 
		"Name=createFileFetchTicket", "Value=false", ENDITEM, 
		EXTRARES, 
//		"Url=https://safebrowsing.googleapis.com/v4/threatListUpdates:fetch?$req="
//		"Ch0KDGdvb2dsZWNocm9tZRINNzUuMC4zNzcwLjE0MhopCAUQARobCg0IBRAGGAEiAzAwMTABEN6JBxoCGAuidtPwIgQgASACKAEaKQgBEAEaGwoNCAEQBhgBIgMwMDEwARCWswYaAhgL6lUaJCIEIAEgAigBGikIBxABGhsKDQgHEAYYASIDMDAxMAEQ_fQFGgIYCxGYd0QiBCABIAIoARonCAEQARoZCg0IARAGGAEiAzAwMTADEBQaAhgLmhN4KiIEIAEgAigDGigIARAIGhoKDQgBEAgYASIDMDAxMAQQ8BcaAhgL8pEKZyIEIAEgAigEGicICRABGhkKDQgJEAYYASIDMDAxMAYQAhoCGAsFHOT7IgQgASACKAYaJwgPEAEaGQoNCA8QBhgBIgMwMDEwARB3GgIYC4hTj4QiBCABIAIoARonCAkQARoZCg0ICRAGGAEiAzAwMTABEBUaAhgLm5xhAyIEIAEgAigBGicIChAIGhkKDQ"
//		"gKEAgYASIDMDAxMAEQBRoCGAtJNtG4IgQgASACKAEaKAgIEAEaGgoNCAgQBhgBIgMwMDEwARDRBhoCGAu0Q9_cIgQgASACKAEaKAgNEAEaGgoNCA0QBhgBIgMwMDEwARCRSBoCGAvpccqaIgQgASACKAEaKQgDEAEaGwoNCAMQBhgBIgMwMDEwARCptQYaAhgLExU1fCIEIAEgAigBGikIDhABGhsKDQgOEAYYASIDMDAxMAEQw5MCGgIYC_aHZuIiBCABIAIoASICCAE=&$ct=application/x-protobuf&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", "Referer=", ENDITEM, 
		LAST);

	ctrx_nfuse_connect("https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/LaunchIca/{ICA_FILE}.ica?CsrfToken={CitrixXenApp_CsrfToken}&IsUsingHttps=Yes&displayNameDesktopTitle={CITRIX_DESKTOP}&launchId=1567587516803", CTRX_LAST);

	lr_end_transaction("CAD_BP3_01_CLick_ICA",LR_AUTO);
	
	lr_think_time(30);
	
	lr_start_transaction("CAD_BP3_02_Open_ICA");

	ctrx_wait_for_event("LOGON", CTRX_LAST);

	lr_end_transaction("CAD_BP3_02_Open_ICA", LR_AUTO);

	
	lr_think_time(45);

	lr_start_transaction("CAD_BP3_03_Open_CAD_App");

	ctrx_mouse_double_click(38, 217, LEFT_BUTTON, 0, "NULL=snapshot1", CTRX_LAST);

	lr_end_transaction("CAD_BP3_03_Open_CAD_App",LR_AUTO);
	
	lr_think_time(30);

	lr_start_transaction("CAD_BP3_04_Click_Patient");

	ctrx_sync_on_window("CA Digital - CA Digital", ACTIVATE, 0, 0, 1281, 985, "snapshot2", CTRX_LAST);

	ctrx_mouse_click(330, 632, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot3", CTRX_LAST);

	lr_end_transaction("CAD_BP3_04_Click_Patient",LR_AUTO);
	
	lr_think_time(10);

	lr_start_transaction("CAD_BP3_05_Create_Patient");

	ctrx_mouse_click(887, 758, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot4", CTRX_LAST);

	lr_end_transaction("CAD_BP3_05_Create_Patient",LR_AUTO);

	lr_start_transaction("CAD_BP3_06_Patient_Details");

	ctrx_mouse_click(1127, 263, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot5", CTRX_LAST);

	ctrx_type("CAD{PatientID}", "", CTRX_LAST);

	ctrx_mouse_click(1116, 299, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot8", CTRX_LAST);

	ctrx_type("CAF{PatientID}", "", CTRX_LAST);

	ctrx_mouse_click(1125, 338, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot10", CTRX_LAST);

	ctrx_type("CAL{PatientID}", "", CTRX_LAST);

	ctrx_mouse_click(1134, 383, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot12", CTRX_LAST);

	ctrx_type("01/07/1986", "", CTRX_LAST);

	ctrx_mouse_click(1125, 424, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot31", CTRX_LAST);

	ctrx_type("MRN{PatientID}", "", CTRX_LAST);

	ctrx_mouse_click(1131, 498, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot33", CTRX_LAST);

	ctrx_type("{Date}", "", CTRX_LAST);

	ctrx_mouse_click(1182, 901, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot36", CTRX_LAST);

	lr_end_transaction("CAD_BP3_06_Patient_Details",LR_AUTO);

	lr_think_time(30);

	lr_start_transaction("CAD_BP3_07_Import_STLFiles");

	ctrx_mouse_click(249, 62, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot37", CTRX_LAST);

	ctrx_sync_on_window("Load document...", ACTIVATE, 415, 309, 450, 364, "snapshot38", CTRX_LAST);

	ctrx_mouse_click(426, 211, LEFT_BUTTON, 0, "Load document...=snapshot39", CTRX_LAST);

	ctrx_sync_on_window("Open", ACTIVATE, 220, 272, 841, 433, "snapshot40", CTRX_LAST);

	ctrx_mouse_click(351, 99, LEFT_BUTTON, 0, "Open=snapshot41", CTRX_LAST);

	ctrx_mouse_click(774, 375, LEFT_BUTTON, 0, "Open=snapshot42", CTRX_LAST);

	ctrx_sync_on_window("Load document...", ACTIVATE, 415, 309, 450, 364, "snapshot43", CTRX_LAST);

	ctrx_mouse_click(427, 247, LEFT_BUTTON, 0, "Load document...=snapshot44", CTRX_LAST);

	ctrx_sync_on_window("Open", ACTIVATE, 220, 272, 841, 433, "snapshot45", CTRX_LAST);

	ctrx_mouse_click(372, 79, LEFT_BUTTON, 0, "Open=snapshot46", CTRX_LAST);

	ctrx_mouse_click(786, 372, LEFT_BUTTON, 0, "Open=snapshot47", CTRX_LAST);
	
	lr_end_transaction("CAD_BP3_07_Import_STLFiles",LR_AUTO);

	lr_think_time(15);
	
	lr_start_transaction("CAD_BP3_08_LoadSTLFiles");


	ctrx_sync_on_window("Load document...", ACTIVATE, 415, 309, 450, 364, "snapshot48", CTRX_LAST);

	ctrx_mouse_click(216, 341, LEFT_BUTTON, 0, "Load document...=snapshot49", CTRX_LAST);

	lr_end_transaction("CAD_BP3_08_LoadSTLFiles", LR_AUTO);


	lr_think_time(60);

	lr_start_transaction("CAD_BP3_09_Open_Impressions");

	ctrx_sync_on_window("CA Digital - CA Digital", ACTIVATE, 0, 0, 1281, 985, "snapshot50", CTRX_LAST);

	ctrx_mouse_double_click(293, 288, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot51", CTRX_LAST);

	lr_end_transaction("CAD_BP3_09_Open_Impressions",LR_AUTO);

	lr_think_time(45);

	lr_start_transaction("CAD_BP3_10_Step_1");

	ctrx_sync_on_window("CA Digital - CA Digital_2", ACTIVATE, 0, 0, 1281, 985, "snapshot52", CTRX_LAST);

	ctrx_mouse_click(536, 184, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot53", CTRX_LAST);

	ctrx_mouse_click(536, 184, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot54", CTRX_LAST);

//	web_revert_auto_header("Csrf-Token");
//
//	web_revert_auto_header("X-Citrix-IsUsingHTTPS");
//
//	web_revert_auto_header("X-Requested-With");
//
//	lr_think_time(5);
//
//	ctrx_mouse_click(504, 186, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot55", CTRX_LAST);
//
//	ctrx_mouse_click(504, 186, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot56", CTRX_LAST);

	lr_end_transaction("CAD_BP3_10_Step_1",LR_AUTO);

	lr_think_time(30);

	lr_start_transaction("CAD_BP3_11_Step_2");

	ctrx_mouse_click(126, 131, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(20);

	ctrx_mouse_click(795, 525, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(949, 523, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(795, 629, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(951, 627, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(4);

	ctrx_mouse_click(174, 472, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(185, 417, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(194, 375, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(210, 338, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(216, 295, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(245, 266, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(278, 246, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(320, 248, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(356, 262, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(386, 287, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(396, 326, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(411, 369, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(415, 414, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(427, 462, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(15);

	ctrx_mouse_click(189, 663, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(202, 718, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(210, 766, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(222, 804, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(237, 833, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(264, 866, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(293, 873, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(325, 873, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(355, 865, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(380, 835, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(395, 802, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(410, 768, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(418, 717, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(436, 664, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(4);

	ctrx_mouse_click(807, 578, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_end_transaction("CAD_BP3_11_Step_2",LR_AUTO);

	lr_think_time(60);
	
	lr_start_transaction("CAD_BP3_12_Step_3");
	
	ctrx_mouse_click(179, 138, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(120);

	ctrx_mouse_click(791, 189, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(757, 240, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(10);

	ctrx_mouse_click(55, 298, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(15);

	ctrx_mouse_click(185, 354, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_down(180, 349, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_up(190, 352, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(10);

	ctrx_mouse_down(189, 342, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_up(185, 359, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);


	lr_end_transaction("CAD_BP3_12_Step_3",LR_AUTO);

	lr_think_time(30);

	lr_start_transaction("CAD_BP3_13_Step_4");

	ctrx_mouse_click(252, 123, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot112", CTRX_LAST);

	lr_end_transaction("CAD_BP3_13_Step_4",LR_AUTO);

	lr_think_time(60);

	lr_start_transaction("CAD_BP3_14_Export_STL");

	ctrx_mouse_click(62, 923, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot113", CTRX_LAST);

	lr_think_time(10);

	ctrx_sync_on_window("Save", ACTIVATE, 200, 273, 882, 433, "snapshot114", CTRX_LAST);

	ctrx_mouse_click(849, 213, LEFT_BUTTON, 0, "Save=snapshot115", CTRX_LAST);

	ctrx_sync_on_window("Select Export File Types", ACTIVATE, 508, 391, 265, 201, "snapshot116", CTRX_LAST);

	ctrx_mouse_click(23, 50, LEFT_BUTTON, 0, "Select Export File Types=snapshot117", CTRX_LAST);

	ctrx_mouse_click(21, 79, LEFT_BUTTON, 0, "Select Export File Types=snapshot118", CTRX_LAST);

	ctrx_mouse_click(57, 173, LEFT_BUTTON, 0, "Select Export File Types=snapshot119", CTRX_LAST);

	ctrx_sync_on_window("Save", ACTIVATE, 200, 273, 882, 433, "snapshot120", CTRX_LAST);

	ctrx_mouse_click(827, 374, LEFT_BUTTON, 0, "Save=snapshot121", CTRX_LAST);

	lr_end_transaction("CAD_BP3_14_Export_STL",LR_AUTO);

	lr_think_time(180);

	lr_start_transaction("CAD_BP3_15_Home");

//	ctrx_sync_on_window("CA Digital - CA Digital_2", ACTIVATE, 0, 0, 1281, 985, "snapshot109", CTRX_LAST);

	ctrx_mouse_click(151, 68, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot110", CTRX_LAST);

	lr_end_transaction("CAD_BP3_15_Home",LR_AUTO);

	lr_think_time(15);

	lr_start_transaction("CAD_BP3_16_Close_CAD_App");

	ctrx_mouse_click(171, 998, RIGHT_BUTTON, 0, "NULL", CTRX_LAST);

	ctrx_sync_on_window("Windows Shell Experience Host", ACTIVATE, 43, 936, 257, 49, "", CTRX_LAST);

	ctrx_mouse_click(71, 25, LEFT_BUTTON, 0, "Windows Shell Experience Host", CTRX_LAST);

	lr_end_transaction("CAD_BP3_16_Close_CAD_App",LR_AUTO);

	lr_start_transaction("CAD_BP3_17_Close_Citrix_Server");

	ctrx_logoff(CTRX_NORMAL_LOGOFF, CTRX_LAST);

	lr_end_transaction("CAD_BP3_17_Close_Citrix_Server",LR_AUTO);
	
	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_MouseClicks}")));

//	Initialize Throughput Calculations
//	Declare Transaction
	TransactionType = "Simple";

	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1, "CAD_02_Logout");

	
	lr_start_transaction("CAD_02_Logout");

	web_add_cookie("CtxsDesktopAutoLaunchDone=no; DOMAIN=storefront.smileco.com");

	web_add_header("Csrf-Token",
		"{CitrixXenApp_CsrfToken}");

	web_add_auto_header("X-Citrix-IsUsingHTTPS", 
		"Yes");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_custom_request("Disconnect", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Sessions/Disconnect", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_02_Logout");
  

	lr_end_transaction("CAD_02_Logout", LR_AUTO);

	return 0;
}