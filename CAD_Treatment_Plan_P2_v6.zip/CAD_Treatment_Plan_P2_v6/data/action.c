Action()
{

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_url("client_model_v5_variation_0.pb", 
		"URL=https://ssl.gstatic.com/safebrowsing/csd/client_model_v5_variation_0.pb", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t1.inf", 
		LAST);

	web_url("client_model_v5_ext_variation_0.pb", 
		"URL=https://ssl.gstatic.com/safebrowsing/csd/client_model_v5_ext_variation_0.pb", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t2.inf", 
		LAST);

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=75", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t3.inf", 
		LAST);

	lr_think_time(13);

	web_url("SmileDirectClubWeb", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=custom/style.css", ENDITEM, 
		"Url=receiver/js/external/jquery.dotdotdot.min_08EE54CBA886AD0A.js", ENDITEM, 
		"Url=receiver/js/external/hammer.v2.0.8.min_F699A1E56189259A.js", ENDITEM, 
		"Url=receiver/js/external/velocity.min_B218502A82F66680.js", ENDITEM, 
		"Url=receiver/images/1x/CitrixReceiver_WebScreen_CBE548FB8FEE049E.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/js/external/slick.min_FEB62CC230E2BA2A.js", ENDITEM, 
		"Url=receiver/js/ctxs.core.min_33B1CC992A07D57E.js", ENDITEM, 
		"Url=receiver/js/ctxs.webui.min_895B3076E3BA6027.js", ENDITEM, 
		"Url=receiver/images/1x/folder_template_C13BB96DEBC9F30F.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/images/1x/actionSprite_531B7A6FF85CA98E.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/images/common/ReceiverFullScreenBackground_46E559C0E6B5A27B.jpg", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=custom/strings.en.js", ENDITEM, 
		"Url=custom/script.js", ENDITEM, 
		"Url=receiver/images/1x/viewSprite_B2F322BDCB824FAF.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/images/common/authspinner_B0BCD339560CA593.gif", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL2NqTTJXVmxLZW1OTFNISnJWREJMZG5GbGRWbGxTVGNyTVRFMFBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=receiver/images/common/icon_loading_9A0623127A028FEB.png", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL2NFTm9NM1JKUnpObVZFTnpORXhRTUUxT2EyY3lVa3N5TXl0alBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL1duZHhaRlZXV0VWTWRuYzNPRGw2VEhWUUsyRkNTSE5WYVhoclBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL1UxZFNOblpTYkhaRmVUbEJNRzAzTjB3MWNHRkRLMUIyYm1zNFBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL00zZE9NVWROUmtWMFQwZDBhME5yWVRJM2NsaDBia04yUTFkU1QxbFNkVGhXU1ZWQlRXWlNWbFJpZHowLS9pbWFnZQ--?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL2JHRnhlRmhYYmtwdmJqbFVWV3hwVlZaV1EyOXBlbmxITTI5QlBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		LAST);

	web_add_auto_header("X-Citrix-IsUsingHTTPS", 
		"Yes");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_custom_request("Configuration", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Home/Configuration", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_add_auto_header("Csrf-Token", 
		"0A1D42FE3C0AEFD92BCF5C2FAD48B106");

	web_custom_request("GetDetectionTicket", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionTicket", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("GetDetectionStatus", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionStatus", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body=ticket=CDT_9nFRkPaYWvAovijmDKzZu5os7s6RSyZrruQNGEX7WtimRnEGyMpb!u0p0vT_wcPb", 
		LAST);

	web_custom_request("GetDetectionStatus_2", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionStatus", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body=ticket=CDT_9nFRkPaYWvAovijmDKzZu5os7s6RSyZrruQNGEX7WtimRnEGyMpb!u0p0vT_wcPb", 
		LAST);

	web_add_cookie("CtxsUserPreferredClient=Native; DOMAIN=storefront.smileco.com");

	web_add_cookie("CtxsClientDetectionDone=true; DOMAIN=storefront.smileco.com");

	web_add_cookie("CtxsHasUpgradeBeenShown=true; DOMAIN=storefront.smileco.com");

	web_submit_data("List", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/List", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=format", "Value=json", ENDITEM, 
		"Name=resourceDetails", "Value=Default", ENDITEM, 
		LAST);

	web_custom_request("GetAuthMethods", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Authentication/GetAuthMethods", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("Login", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ExplicitAuth/Login", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/vnd.citrix.authenticateresponse-1+xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncType=", 
		EXTRARES, 
		"Url=../receiver/images/1x/CitrixStoreFront_auth_14B96BFF2B0A6FF8.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=../receiver/images/1x/spinner_white_auth_button_53FD5A337A529DA7.gif", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		LAST);

	web_submit_data("LoginAttempt", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ExplicitAuth/LoginAttempt", 
		"Method=POST", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=username", "Value=Crtest.user5", ENDITEM, 
		"Name=password", "Value=P@$$word5", ENDITEM, 
		"Name=saveCredentials", "Value=false", ENDITEM, 
		"Name=loginBtn", "Value=Log On", ENDITEM, 
		"Name=StateContext", "Value=", ENDITEM, 
		LAST);

	web_revert_auto_header("Csrf-Token");

	web_revert_auto_header("X-Citrix-IsUsingHTTPS");

	web_revert_auto_header("X-Requested-With");

	web_custom_request("reportDetectionStatus", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClub/clientAssistant/reportDetectionStatus", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"Body=ticket=CDT_9nFRkPaYWvAovijmDKzZu5os7s6RSyZrruQNGEX7WtimRnEGyMpb!u0p0vT_wcPb&protocolVersion=1&hdxVersion=14.7.0.13011&hdxIsPassthrough=False&hdxIsPassthroughVariable=False", 
		LAST);

	web_add_cookie("CtxsPasswordChangeAllowed=true; DOMAIN=storefront.smileco.com");

	web_add_auto_header("Csrf-Token", 
		"0A1D42FE3C0AEFD92BCF5C2FAD48B106");

	web_add_auto_header("X-Citrix-IsUsingHTTPS", 
		"Yes");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_submit_data("List_2", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/List", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=format", "Value=json", ENDITEM, 
		"Name=resourceDetails", "Value=Default", ENDITEM, 
		EXTRARES, 
		"Url=../receiver/images/1x/CitrixReceiverLogo_Home_5C24BCEC5A182425.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=../receiver/images/1x/spinner_5CF0D1C8A76AAC8E.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=../receiver/images/1x/search_close_BC5A22358E58905F.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=../receiver/images/1x/ico_search_E84E3D63D821F80D.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		LAST);

	web_custom_request("GetUserName", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Authentication/GetUserName", 
		"Method=POST", 
		"Resource=0", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("AllowSelfServiceAccountManagement", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ExplicitAuth/AllowSelfServiceAccountManagement", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	lr_think_time(9);

	lr_start_transaction("Click_VDI");

	web_submit_data("WGVuRGVza3RvcCBDb250cm9sbGVyLldpbjEwX2NhZHRzdCAkUzc2LTEzNA--", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/GetLaunchStatus/WGVuRGVza3RvcCBDb250cm9sbGVyLldpbjEwX2NhZHRzdCAkUzc2LTEzNA--", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=displayNameDesktopTitle", "Value=Win10_CADTraining", ENDITEM, 
		"Name=createFileFetchTicket", "Value=false", ENDITEM, 
		EXTRARES, 
		"Url=https://safebrowsing.googleapis.com/v4/threatListUpdates:fetch?$req="
		"Ch0KDGdvb2dsZWNocm9tZRINNzUuMC4zNzcwLjE0MhopCAUQARobCg0IBRAGGAEiAzAwMTABEN6JBxoCGAuidtPwIgQgASACKAEaKQgBEAEaGwoNCAEQBhgBIgMwMDEwARCWswYaAhgL6lUaJCIEIAEgAigBGikIBxABGhsKDQgHEAYYASIDMDAxMAEQ_fQFGgIYCxGYd0QiBCABIAIoARonCAEQARoZCg0IARAGGAEiAzAwMTADEBQaAhgLmhN4KiIEIAEgAigDGigIARAIGhoKDQgBEAgYASIDMDAxMAQQ8BcaAhgL8pEKZyIEIAEgAigEGicICRABGhkKDQgJEAYYASIDMDAxMAYQAhoCGAsFHOT7IgQgASACKAYaJwgPEAEaGQoNCA8QBhgBIgMwMDEwARB3GgIYC4hTj4QiBCABIAIoARonCAkQARoZCg0ICRAGGAEiAzAwMTABEBUaAhgLm5xhAyIEIAEgAigBGicIChAIGhkKDQ"
		"gKEAgYASIDMDAxMAEQBRoCGAtJNtG4IgQgASACKAEaKAgIEAEaGgoNCAgQBhgBIgMwMDEwARDRBhoCGAu0Q9_cIgQgASACKAEaKAgNEAEaGgoNCA0QBhgBIgMwMDEwARCRSBoCGAvpccqaIgQgASACKAEaKQgDEAEaGwoNCAMQBhgBIgMwMDEwARCptQYaAhgLExU1fCIEIAEgAigBGikIDhABGhsKDQgOEAYYASIDMDAxMAEQw5MCGgIYC_aHZuIiBCABIAIoASICCAE=&$ct=application/x-protobuf&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", "Referer=", ENDITEM, 
		LAST);

	ctrx_nfuse_connect("https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/LaunchIca/WGVuRGVza3RvcCBDb250cm9sbGVyLldpbjEwX2NhZHRzdCAkUzc2LTEzNA--.ica?CsrfToken=0A1D42FE3C0AEFD92BCF5C2FAD48B106&IsUsingHttps=Yes&displayNameDesktopTitle=Win10_CADTraining&launchId=1567587516803", CTRX_LAST);

	lr_end_transaction("Click_VDI",LR_AUTO);

	lr_start_transaction("Open_ICA");

	ctrx_wait_for_event("LOGON", CTRX_LAST);

	lr_end_transaction("Open_ICA",LR_AUTO);

	lr_start_transaction("Open_CAD");

	ctrx_mouse_double_click(38, 217, LEFT_BUTTON, 0, "NULL=snapshot1", CTRX_LAST);

	lr_end_transaction("Open_CAD",LR_AUTO);

	lr_start_transaction("Open_Patient_files");

	ctrx_sync_on_window("CA Digital - CA Digital", ACTIVATE, 0, 0, 1281, 985, "snapshot2", CTRX_LAST);

	ctrx_mouse_click(330, 632, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot3", CTRX_LAST);

	lr_end_transaction("Open_Patient_files",LR_AUTO);

	lr_start_transaction("Create");

	ctrx_mouse_click(887, 758, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot4", CTRX_LAST);

	lr_end_transaction("Create",LR_AUTO);

	lr_start_transaction("Fill_patient_details");

	ctrx_mouse_click(1127, 263, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot5", CTRX_LAST);

	ctrx_type("CADP983562789", "", CTRX_LAST);

	ctrx_mouse_click(1116, 299, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot8", CTRX_LAST);

	ctrx_type("CAF9034567", "", CTRX_LAST);

	ctrx_mouse_click(1125, 338, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot10", CTRX_LAST);

	ctrx_type("CAL8746730", "", CTRX_LAST);

	ctrx_mouse_click(1134, 383, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot12", CTRX_LAST);

	ctrx_type("01.07.1986", "", CTRX_LAST);

	ctrx_key("LEFT_ARROW_KEY", 0, "", CTRX_LAST);

	ctrx_key("LEFT_ARROW_KEY", 0, "", CTRX_LAST);

	ctrx_key("LEFT_ARROW_KEY", 0, "", CTRX_LAST);

	ctrx_key("LEFT_ARROW_KEY", 0, "", CTRX_LAST);

	ctrx_key("LEFT_ARROW_KEY", 0, "", CTRX_LAST);

	ctrx_key("LEFT_ARROW_KEY", 0, "", CTRX_LAST);

	ctrx_key("LEFT_ARROW_KEY", 0, "", CTRX_LAST);

	ctrx_key("BACKSPACE_KEY", 0, "", CTRX_LAST);

	ctrx_type("/", "", CTRX_LAST);

	ctrx_key("RIGHT_ARROW_KEY", 0, "", CTRX_LAST);

	ctrx_key("RIGHT_ARROW_KEY", 0, "", CTRX_LAST);

	ctrx_key("RIGHT_ARROW_KEY", 0, "", CTRX_LAST);

	ctrx_key("RIGHT_ARROW_KEY", 0, "", CTRX_LAST);

	ctrx_key("LEFT_ARROW_KEY", 0, "", CTRX_LAST);

	ctrx_key("BACKSPACE_KEY", 0, "", CTRX_LAST);

	ctrx_type("/", "", CTRX_LAST);

	ctrx_mouse_click(1125, 424, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot31", CTRX_LAST);

	ctrx_type("MRN893567489", "", CTRX_LAST);

	ctrx_mouse_click(1131, 498, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot33", CTRX_LAST);

	ctrx_type("09/04/2019", "", CTRX_LAST);

	ctrx_mouse_click(1182, 901, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot36", CTRX_LAST);

	lr_end_transaction("Fill_patient_details",LR_AUTO);

	lr_think_time(12);

	lr_start_transaction("Load_STL_FILES");

	ctrx_mouse_click(249, 62, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot37", CTRX_LAST);

	ctrx_sync_on_window("Load document...", ACTIVATE, 415, 309, 450, 364, "snapshot38", CTRX_LAST);

	ctrx_mouse_click(426, 211, LEFT_BUTTON, 0, "Load document...=snapshot39", CTRX_LAST);

	ctrx_sync_on_window("Open", ACTIVATE, 220, 272, 841, 433, "snapshot40", CTRX_LAST);

	ctrx_mouse_click(351, 99, LEFT_BUTTON, 0, "Open=snapshot41", CTRX_LAST);

	ctrx_mouse_click(774, 375, LEFT_BUTTON, 0, "Open=snapshot42", CTRX_LAST);

	ctrx_sync_on_window("Load document...", ACTIVATE, 415, 309, 450, 364, "snapshot43", CTRX_LAST);

	ctrx_mouse_click(427, 247, LEFT_BUTTON, 0, "Load document...=snapshot44", CTRX_LAST);

	ctrx_sync_on_window("Open", ACTIVATE, 220, 272, 841, 433, "snapshot45", CTRX_LAST);

	ctrx_mouse_click(372, 79, LEFT_BUTTON, 0, "Open=snapshot46", CTRX_LAST);

	ctrx_mouse_click(786, 372, LEFT_BUTTON, 0, "Open=snapshot47", CTRX_LAST);

	lr_think_time(5);

	ctrx_sync_on_window("Load document...", ACTIVATE, 415, 309, 450, 364, "snapshot48", CTRX_LAST);

	ctrx_mouse_click(216, 341, LEFT_BUTTON, 0, "Load document...=snapshot49", CTRX_LAST);

	lr_end_transaction("Load_STL_FILES",LR_AUTO);

	lr_think_time(45);

	lr_start_transaction("Open_stlfiles");

	ctrx_sync_on_window("CA Digital - CA Digital", ACTIVATE, 0, 0, 1281, 985, "snapshot50", CTRX_LAST);

	ctrx_mouse_double_click(293, 288, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot51", CTRX_LAST);

	lr_end_transaction("Open_stlfiles",LR_AUTO);

	lr_think_time(36);

	lr_start_transaction("Step1");

	ctrx_sync_on_window("CA Digital - CA Digital_2", ACTIVATE, 0, 0, 1281, 985, "snapshot52", CTRX_LAST);

	ctrx_mouse_click(536, 184, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot53", CTRX_LAST);

	ctrx_mouse_click(536, 184, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot54", CTRX_LAST);

	web_revert_auto_header("Csrf-Token");

	web_revert_auto_header("X-Citrix-IsUsingHTTPS");

	web_revert_auto_header("X-Requested-With");

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=9:2489946523&cup2hreq=8a67f4add02485e25d4f1ae73ffecac8485884a835ae08608af24a4504f6df61", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx2,crx3\",\"app\":[{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"CHBF\",\"cohortname\":\"Auto\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{989666d5-52f7-42e8-b1d2-c1208889b184}\",\"rd\":4624},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"CHBF\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{838328e1-6a57-4c30-8ed3-2d940075e84b}\",\"rd\""
		":4624},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"CHBF\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{a6b6f887-7cbd-4a2e-87d6-efc2e0bc7a26}\",\"rd\":4624},\"updatecheck\":{},\"version\":\"4.10.1440.18\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"CHBF\",\"cohort\":\"1:j5l:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.3eb16d6c28b502ac4cfee8f4a148df05f4d93229fa36a71db8b08d06329ff18a\"}]},\"ping\":{\"ping_freshness\":\"{1ade6aa6-ad35-4ea7-954f-1fd855b22112}\",\"rd\":4624},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"CHBF\",\"cohort\":\"1:cux:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.fd49e95c952bdb265a80513767311a5e069ac9dbf2ed4b480b96513b0ccbe086\"}]},\"ping\":{\"ping_freshness\":\""
		"{2a64419f-6fcc-4ed8-9422-f20ffd37a45f}\",\"rd\":4624},\"updatecheck\":{},\"version\":\"36\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"CHBF\",\"cohort\":\"1:ofl:\",\"cohorthint\":\"stable64\",\"cohortname\":\"stable64\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\"ping\":{\"ping_freshness\":\"{8a0704e6-b901-4700-b6bb-6248a6f5aa14}\",\"rd\":4624},\"updatecheck\":{},\"version\":\"2018.8.8.0\"},{\""
		"appid\":\"mimojjlkmoijpicakmndhoigimigcmbb\",\"brand\":\"CHBF\",\"cohort\":\"1:d0j:\",\"cohorthint\":\"Chrome [M50... M99]\",\"cohortname\":\"Chrome [M50... M99]\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.ddf75a54e39f56bae13bfa038d0c5a3d042965b09f38a20bbdf8d470a76e4f89\"}]},\"ping\":{\"ping_freshness\":\"{208e3890-d4c2-485e-933e-0cc58f8d57ae}\",\"rd\":4624},\"updatecheck\":{},\"version\":\"32.0.0.238\"},{\"appid\":\"copjbmjbojbakpaedmpkhmiplmmehfck\",\"brand\":\"CHBF\",\"cohort\":\""
		"1:p1x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.207921137eee9c0831e0bd890330986c10dfd9382034491b82de3f86ae6915f7\"}]},\"ping\":{\"ping_freshness\":\"{ec6f2bc4-a1d5-4fc3-9250-b1f4eab82aac}\",\"rd\":4624},\"updatecheck\":{},\"version\":\"2018.9.6.0\"},{\"appid\":\"hnimpnehoodheedghdeeijklkeaacbdc\",\"brand\":\"CHBF\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.1cd7dc2056afaa0f6a705c9a17d22bba6578b33f5dae9e2d6518a0bfcced2396\"}]},\"ping\":{\"ping_freshness\":\"{ef30f613-2eda-434a-92b9-de132b91562e}\",\"rd\":4624},\"updatecheck\":{},\"version\":\"0.57.44.2492\"},{\"appid\":\"aemomkdncapdnfajjbbcbdebjljbpmpj\",\"brand\":\"CHBF\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.65717b0144bfb0bd193f8ce31bf0dd7c95ff6d5844f2bc0c742974c1ccf889ae\"}]},\"ping\":{\"ping_freshness\":\"{40f3e29d-8b6e-43c0-a702-dd501bdfb410}\",\"rd\":4624},\"updatecheck\":{}"
		",\"version\":\"1.0.5.0\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"CHBF\",\"cohort\":\"1:bm1:sbl@0.01,sf3@0.1\",\"cohorthint\":\"M54ToM99\",\"cohortname\":\"M54ToM99\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.72ae053d74e3a8df90460d740b8e33a80ba24509b65fddb66f53609aecdbbcf7\"}]},\"ping\":{\"ping_freshness\":\"{71f3f3f5-7514-497d-9eab-67af78d1205b}\",\"rd\":4624},\"updatecheck\":{},\"version\":\"9.4.1\"},{\"appid\":\"gkmgaooipdjhmangpemjhigmamcehddo\",\"brand\":\""
		"CHBF\",\"cohort\":\"1:pw3:\",\"cohorthint\":\"ESET Stable\",\"cohortname\":\"ESET Stable\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.8b5dbfc11accdd2dfab5a2e1cf5455838ad4744fb19e2a54a6747c50736e2d3e\"}]},\"ping\":{\"ping_freshness\":\"{d140ec07-f124-477e-84f9-1a35b099e952}\",\"rd\":4624},\"tag\":\"eset_exp_b\",\"updatecheck\":{},\"version\":\"44.215.200.3\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"CHBF\",\"cohort\":\"1:jcl:\",\"cohorthint\":\"Auto\",\"cohortname\""
		":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.88757e7f657165d8d54f7361174f768381c289df6674e4f85eb7a514ae187092\"}]},\"ping\":{\"ping_freshness\":\"{d1515466-0957-4e4f-bdf4-72871b9c695b}\",\"rd\":4624},\"updatecheck\":{},\"version\":\"5366\"},{\"appid\":\"ojjgnpkioondelmggbekfhllhdaimnho\",\"brand\":\"CHBF\",\"cohort\":\"1:0:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.badb9b0b0f9725f0d2b19bdc546bade2d3e8882f8c8469cce673d021a5fe1fd5\"}]},\"ping\":{\"ping_freshness\":\"{0e8e70a2-d97f-4834-ac06-9c9da01aea67}\",\"rd\":4624},\"updatecheck\":{},\"version\":\"1229\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":true,\"hw\":{\"physmemory\":16},\"lang\":\"en-US\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.17134.915\"},\"prodversion\":\"75.0.3770.142\",\"protocol\":\"3.1\",\"requestid\":\""
		"{aa990068-4e26-423b-81b5-0ba24a66b5ca}\",\"sessionid\":\"{a1dd9a87-0466-4b97-9665-8636622552f9}\",\"updater\":{\"autoupdatecheckenabled\":false,\"ismachine\":true,\"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":-1,\"version\":\"1.3.34.13\"},\"updaterversion\":\"75.0.3770.142\"}}", 
		LAST);

	lr_think_time(5);

	ctrx_mouse_click(504, 186, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot55", CTRX_LAST);

	ctrx_mouse_click(504, 186, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot56", CTRX_LAST);

	lr_think_time(4);

	web_custom_request("json_2", 
		"URL=https://update.googleapis.com/service/update2/json", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx2,crx3\",\"app\":[{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"event\":[{\"download_time_ms\":12110,\"downloaded\":18991,\"downloader\":\"bits\",\"eventresult\":1,\"eventtype\":14,\"nextversion\":\"5376\",\"previousversion\":\"5366\",\"total\":18991,\"url\":\"http://redirector.gvt1.com/edgedl/release2/chrome_component/VlbAN8cCvwK6FEDIKkHDIQ_5376/AJe-zd3UewDmMmJ5cg4DGn0\"},{\"eventresult\":1,\"eventtype\":3,\""
		"nextfp\":\"1.1bc5af5f5613b31885463fa8f7d51bd0a749465045062d86784762c573e41a83\",\"nextversion\":\"5376\",\"previousfp\":\"1.88757e7f657165d8d54f7361174f768381c289df6674e4f85eb7a514ae187092\",\"previousversion\":\"5366\"}],\"version\":\"5376\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"hw\":{\"physmemory\":16},\"lang\":\"en-US\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.17134.915\"},\"prodversion\":\"75.0.3770.142\",\"protocol\":\"3.1\",\"requestid"
		"\":\"{666fb3eb-15ae-497d-a9f5-b350e396583b}\",\"sessionid\":\"{a1dd9a87-0466-4b97-9665-8636622552f9}\",\"updaterversion\":\"75.0.3770.142\"}}", 
		LAST);

	lr_end_transaction("Step1",LR_AUTO);

	lr_think_time(9);

	lr_start_transaction("Step2");

	ctrx_mouse_click(124, 130, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot57", CTRX_LAST);

	lr_think_time(37);

	ctrx_mouse_click(789, 521, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot58", CTRX_LAST);

	ctrx_mouse_click(950, 523, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot59", CTRX_LAST);

	ctrx_mouse_click(791, 629, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot60", CTRX_LAST);

	ctrx_mouse_click(950, 630, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot61", CTRX_LAST);

	ctrx_mouse_click(159, 648, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot62", CTRX_LAST);

	ctrx_mouse_click(169, 712, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot63", CTRX_LAST);

	ctrx_mouse_click(172, 766, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot64", CTRX_LAST);

	ctrx_mouse_click(181, 803, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot65", CTRX_LAST);

	ctrx_mouse_click(190, 848, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot66", CTRX_LAST);

	ctrx_mouse_click(215, 875, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot67", CTRX_LAST);

	ctrx_mouse_click(250, 889, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot68", CTRX_LAST);

	ctrx_mouse_click(282, 896, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot69", CTRX_LAST);

	ctrx_mouse_click(317, 893, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot70", CTRX_LAST);

	ctrx_mouse_click(356, 870, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot71", CTRX_LAST);

	ctrx_mouse_click(376, 830, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot72", CTRX_LAST);

	ctrx_mouse_click(392, 795, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot73", CTRX_LAST);

	ctrx_mouse_click(408, 745, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot74", CTRX_LAST);

	ctrx_mouse_click(439, 687, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot75", CTRX_LAST);

	ctrx_mouse_click(142, 493, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot76", CTRX_LAST);

	ctrx_mouse_click(151, 430, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot77", CTRX_LAST);

	ctrx_mouse_click(159, 383, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot78", CTRX_LAST);

	ctrx_mouse_click(168, 343, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot79", CTRX_LAST);

	ctrx_mouse_click(179, 297, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot80", CTRX_LAST);

	ctrx_mouse_click(203, 260, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot81", CTRX_LAST);

	ctrx_mouse_click(246, 241, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot82", CTRX_LAST);

	ctrx_mouse_click(294, 237, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot83", CTRX_LAST);

	ctrx_mouse_click(341, 244, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot84", CTRX_LAST);

	ctrx_mouse_click(377, 282, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot85", CTRX_LAST);

	ctrx_mouse_click(396, 326, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot86", CTRX_LAST);

	ctrx_mouse_click(417, 362, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot87", CTRX_LAST);

	ctrx_mouse_click(430, 408, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot88", CTRX_LAST);

	ctrx_mouse_click(451, 462, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot89", CTRX_LAST);

	lr_think_time(4);

	ctrx_mouse_click(806, 578, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot90", CTRX_LAST);

	lr_think_time(52);

	ctrx_mouse_down(461, 478, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot91", CTRX_LAST);

	ctrx_mouse_up(467, 489, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot92", CTRX_LAST);

	ctrx_mouse_down(469, 474, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot93", CTRX_LAST);

	ctrx_mouse_up(481, 486, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot94", CTRX_LAST);

	ctrx_mouse_click(945, 570, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot95", CTRX_LAST);

	lr_end_transaction("Step2",LR_AUTO);

	lr_think_time(15);

	lr_start_transaction("Step3");

	ctrx_mouse_click(190, 134, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot96", CTRX_LAST);

	lr_end_transaction("Step3",LR_AUTO);

	lr_think_time(116);

	lr_start_transaction("Step4");

	ctrx_mouse_click(256, 130, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot97", CTRX_LAST);

	lr_end_transaction("Step4",LR_AUTO);

	lr_think_time(42);

	lr_start_transaction("Export_stl");

	ctrx_mouse_click(54, 918, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot98", CTRX_LAST);

	ctrx_sync_on_window("Save", ACTIVATE, 200, 273, 882, 433, "snapshot99", CTRX_LAST);

	ctrx_mouse_click(857, 207, LEFT_BUTTON, 0, "Save=snapshot100", CTRX_LAST);

	ctrx_sync_on_window("Select Export File Types", ACTIVATE, 508, 391, 265, 201, "snapshot101", CTRX_LAST);

	ctrx_mouse_click(20, 81, LEFT_BUTTON, 0, "Select Export File Types=snapshot102", CTRX_LAST);

	ctrx_mouse_click(22, 51, LEFT_BUTTON, 0, "Select Export File Types=snapshot103", CTRX_LAST);

	ctrx_mouse_click(78, 177, LEFT_BUTTON, 0, "Select Export File Types=snapshot104", CTRX_LAST);

	ctrx_sync_on_window("Save", ACTIVATE, 200, 273, 882, 433, "snapshot105", CTRX_LAST);

	ctrx_mouse_click(823, 372, LEFT_BUTTON, 0, "Save=snapshot106", CTRX_LAST);

	lr_think_time(58);

	ctrx_sync_on_window("Warning", ACTIVATE, 241, 441, 798, 141, "snapshot107", CTRX_LAST);

	ctrx_mouse_click(400, 113, LEFT_BUTTON, 0, "Warning=snapshot108", CTRX_LAST);

	lr_end_transaction("Export_stl",LR_AUTO);

	lr_think_time(14);

	lr_start_transaction("Home");

	ctrx_sync_on_window("CA Digital - CA Digital_2", ACTIVATE, 0, 0, 1281, 985, "snapshot109", CTRX_LAST);

	ctrx_mouse_click(151, 68, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot110", CTRX_LAST);

	lr_end_transaction("Home",LR_AUTO);

	lr_think_time(20);

	lr_start_transaction("Close_CAD");

	ctrx_sync_on_window("CA Digital - CA Digital_2", ACTIVATE, 0, 0, 1281, 985, "snapshot111", CTRX_LAST);

	ctrx_mouse_click(1254, 12, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot112", CTRX_LAST);

	ctrx_mouse_click(1254, 12, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot113", CTRX_LAST);

	ctrx_mouse_click(1256, 8, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot114", CTRX_LAST);

	lr_end_transaction("Close_CAD",LR_AUTO);

	lr_start_transaction("Close_Citrix");

	ctrx_logoff(CTRX_NORMAL_LOGOFF, CTRX_LAST);

	lr_end_transaction("Close_Citrix",LR_AUTO);

	lr_start_transaction("Logout");

	web_add_cookie("CtxsDesktopAutoLaunchDone=no; DOMAIN=storefront.smileco.com");

	web_add_header("Csrf-Token", 
		"0A1D42FE3C0AEFD92BCF5C2FAD48B106");

	web_add_auto_header("X-Citrix-IsUsingHTTPS", 
		"Yes");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	lr_think_time(11);

	web_custom_request("Disconnect", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Sessions/Disconnect", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_add_header("Csrf-Token", 
		"0D113A36F190601F3C8925FA8718D627");

	web_custom_request("Logoff", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Authentication/Logoff", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	return 0;
}