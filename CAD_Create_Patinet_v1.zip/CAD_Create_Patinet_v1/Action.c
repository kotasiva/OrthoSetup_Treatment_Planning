﻿Action()
{

	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Login}")));
	

	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1, "CAD_BP1_01_CLick_ICA" );
	
	lr_start_transaction("CAD_BP1_01_CLick_ICA");

	web_submit_data("{ICA_FILE}", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/GetLaunchStatus/{ICA_FILE}", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t40.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=displayNameDesktopTitle", "Value={CITRIX_DESKTOP}", ENDITEM, 
		"Name=createFileFetchTicket", "Value=false", ENDITEM, 
		EXTRARES, 
//		"Url=https://safebrowsing.googleapis.com/v4/threatListUpdates:fetch?$req="
//		"Ch0KDGdvb2dsZWNocm9tZRINNzAuMC4zNTM4LjEwMhonCAEQARoZCg0IARAGGAEiAzAwMTADEBQaAhgELXnMECIEIAEgAigDGicICRABGhkKDQgJEAYYASIDMDAxMAEQCxoCGARL5DCfIgQgASACKAEaKQgFEAEaGwoNCAUQBhgBIgMwMDEwARC0uQUaAhgEueL6BiIEIAEgAigBGikIAxABGhsKDQgDEAYYASIDMDAxMAEQ0JcFGgIYBJkPe9UiBCABIAIoARopCAEQARobCg0IARAGGAEiAzAwMTABEJWSBRoCGASrth6MIgQgASACKAEaJwgPEAEaGQoNCA8QBhgBIgMwMDEwARAMGgIYBHEn78MiBCABIAIoARopCAcQARobCg0IBxAGGAEiAzAwMTABELqjBBoCGAR4dt7yIgQgASACKAEaKAgBEAgaGgoNCAEQCBgBIgMwMDEwBBCCFRoCGAQ-nsi6IgQgASACKAQaJwgKEAgaGQ"
//		"oNCAoQCBgBIgMwMDEwARAFGgIYBBb_oVMiBCABIAIoARonCAkQARoZCg0ICRAGGAEiAzAwMTAGEAIaAhgERV24FiIEIAEgAigGGigICBABGhoKDQgIEAYYASIDMDAxMAEQuwQaAhgEJ1M9siIEIAEgAigBGigIDRABGhoKDQgNEAYYASIDMDAxMAEQ4B0aAhgEqBdxSyIEIAEgAigBGigIDhABGhoKDQgOEAYYASIDMDAxMAEQ_EMaAhgEf1YaMCIEIAEgAigBIgIIAQ==&$ct=application/x-protobuf&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", "Referer=", ENDITEM, 
		LAST);

//	ctrx_nfuse_connect("https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/LaunchIca/{ICA_FILE}-.ica?CsrfToken={CitrixXenApp_CsrfToken}&IsUsingHttps=Yes&displayNameDesktopTitle=Win7GPU2GB%204CPU&launchId=1542707590576", CTRX_LAST);
	
	ctrx_nfuse_connect("https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/LaunchIca/{ICA_FILE}.ica?CsrfToken={CitrixXenApp_CsrfToken}&IsUsingHttps=Yes&displayNameDesktopTitle={CITRIX_DESKTOP}&launchId=1542707590576", CTRX_LAST);
	
	lr_end_transaction("CAD_BP1_01_CLick_ICA", LR_AUTO);
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP1_01_CLick_ICA" );

	
		//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Links}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP1_02_Open_ICA" );	

	lr_start_transaction("CAD_BP1_02_Open_ICA");		

	ctrx_wait_for_event("LOGON", CTRX_LAST);
	
	lr_end_transaction("CAD_BP1_02_Open_ICA",LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP1_02_Open_ICA" );

	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Links}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP1_03_Open_CAD_App" );	

	lr_start_transaction("CAD_BP1_03_Open_CAD_App");
	
	ctrx_sync_on_window("Desktop", ACTIVATE, 0, 0, 1361, 699, "snapshot1", CTRX_LAST);

	ctrx_mouse_double_click(38, 254, LEFT_BUTTON, 0, "NULL=snapshot1", CTRX_LAST);

	lr_end_transaction("CAD_BP1_03_Open_CAD_App",LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP1_03_Open_CAD_App" );
	
	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Links}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP1_04_Click_Patient" );	

	lr_start_transaction("CAD_BP1_04_Click_Patient");

	ctrx_sync_on_window("CA Digital - CA Digital", ACTIVATE, -4, -4, 1369, 663, "snapshot2", CTRX_LAST);

	ctrx_mouse_click(375, 484, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot3", CTRX_LAST);

	lr_end_transaction("CAD_BP1_04_Click_Patient",LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP1_04_Click_Patient" );


		//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Links}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP1_05_Create_Patient" );	
		
	lr_start_transaction("CAD_BP1_05_Create_Patient");
	

	ctrx_mouse_click(941, 547, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot4", CTRX_LAST);

	lr_end_transaction("CAD_BP1_05_Create_Patient",LR_AUTO);
	
		//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP1_05_Create_Patient" );


	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Links}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP1_06_Patient_Details" );	
		
	lr_start_transaction("CAD_BP1_06_Patient_Details");
	
	ctrx_mouse_click(1227, 241, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot5", CTRX_LAST);
	
	lr_think_time(10);

	ctrx_mouse_click(1207, 243, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot6", CTRX_LAST);

	ctrx_key("NO_KEY", MODIF_SHIFT, "", CTRX_LAST);

	ctrx_type("C{PatientID}", "", CTRX_LAST);

	ctrx_mouse_click(1328, 277, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot9", CTRX_LAST);

	ctrx_mouse_click(1246, 316, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot10", CTRX_LAST);

	ctrx_mouse_click(1206, 302, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot11", CTRX_LAST);

	ctrx_type("CAD{FirstnameRand}", "", CTRX_LAST);

	ctrx_mouse_click(1208, 331, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot13", CTRX_LAST);

	ctrx_type("CAD", "", CTRX_LAST);

	ctrx_mouse_click(1195, 360, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot15", CTRX_LAST);

	ctrx_type("20.11.1986", "", CTRX_LAST);

	ctrx_mouse_click(1264, 653, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot18", CTRX_LAST);

	lr_end_transaction("CAD_BP1_06_Patient_Details",LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP1_06_Patient_Details" );




	return 0;
}