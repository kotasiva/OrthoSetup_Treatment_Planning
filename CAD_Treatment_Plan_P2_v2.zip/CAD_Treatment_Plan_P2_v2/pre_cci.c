# 1 "c:\\users\\siva.kota\\documents\\phase2\\cad_treatment_plan_p2_v2\\\\combined_CAD_Treatment_Plan_P2_v2.c"
# 1 "globals.h" 1



 
 
# 1 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/lrun.h" 1
 
 












 











# 103 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/lrun.h"





















































		


		typedef unsigned size_t;
	
	
        
	

















	

 



















 
 
 
 
 


 
 
 
 
 
 














int     lr_start_transaction   (char * transaction_name);
int lr_start_sub_transaction          (char * transaction_name, char * trans_parent);
long lr_start_transaction_instance    (char * transaction_name, long parent_handle);
int   lr_start_cross_vuser_transaction		(char * transaction_name, char * trans_id_param); 



int     lr_end_transaction     (char * transaction_name, int status);
int lr_end_sub_transaction            (char * transaction_name, int status);
int lr_end_transaction_instance       (long transaction, int status);
int   lr_end_cross_vuser_transaction	(char * transaction_name, char * trans_id_param, int status);


 
typedef char* lr_uuid_t;
 



lr_uuid_t lr_generate_uuid();

 


int lr_generate_uuid_free(lr_uuid_t uuid);

 



int lr_generate_uuid_on_buf(lr_uuid_t buf);

   
# 273 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/lrun.h"
int lr_start_distributed_transaction  (char * transaction_name, lr_uuid_t correlator, long timeout  );

   







int lr_end_distributed_transaction  (lr_uuid_t correlator, int status);


double lr_stop_transaction            (char * transaction_name);
double lr_stop_transaction_instance   (long parent_handle);


void lr_resume_transaction           (char * trans_name);
void lr_resume_transaction_instance  (long trans_handle);


int lr_update_transaction            (const char *trans_name);


 
void lr_wasted_time(long time);


 
int lr_set_transaction(const char *name, double duration, int status);
 
long lr_set_transaction_instance(const char *name, double duration, int status, long parent_handle);


int   lr_user_data_point                      (char *, double);
long lr_user_data_point_instance                   (char *, double, long);
 



int lr_user_data_point_ex(const char *dp_name, double value, int log_flag);
long lr_user_data_point_instance_ex(const char *dp_name, double value, long parent_handle, int log_flag);


int lr_transaction_add_info      (const char *trans_name, char *info);
int lr_transaction_instance_add_info   (long trans_handle, char *info);
int lr_dpoint_add_info           (const char *dpoint_name, char *info);
int lr_dpoint_instance_add_info        (long dpoint_handle, char *info);


double lr_get_transaction_duration       (char * trans_name);
double lr_get_trans_instance_duration    (long trans_handle);
double lr_get_transaction_think_time     (char * trans_name);
double lr_get_trans_instance_think_time  (long trans_handle);
double lr_get_transaction_wasted_time    (char * trans_name);
double lr_get_trans_instance_wasted_time (long trans_handle);
int    lr_get_transaction_status		 (char * trans_name);
int	   lr_get_trans_instance_status		 (long trans_handle);

 



int lr_set_transaction_status(int status);

 



int lr_set_transaction_status_by_name(int status, const char *trans_name);
int lr_set_transaction_instance_status(int status, long trans_handle);


typedef void* merc_timer_handle_t;
 

merc_timer_handle_t lr_start_timer();
double lr_end_timer(merc_timer_handle_t timer_handle);


 
 
 
 
 
 











 



int   lr_rendezvous  (char * rendezvous_name);
 




int   lr_rendezvous_ex (char * rendezvous_name);



 
 
 
 
 
char *lr_get_vuser_ip (void);
void   lr_whoami (int *vuser_id, char ** sgroup, int *scid);
char *	  lr_get_host_name (void);
char *	  lr_get_master_host_name (void);

 
long     lr_get_attrib_long	(char * attr_name);
char *   lr_get_attrib_string	(char * attr_name);
double   lr_get_attrib_double      (char * attr_name);

char * lr_paramarr_idx(const char * paramArrayName, unsigned int index);
char * lr_paramarr_random(const char * paramArrayName);
int    lr_paramarr_len(const char * paramArrayName);

int	lr_param_unique(const char * paramName);
int lr_param_sprintf(const char * paramName, const char * format, ...);


 
 
static void *ci_this_context = 0;






 








void lr_continue_on_error (int lr_continue);
char *   lr_unmask (const char *EncodedString);
char *   lr_decrypt (const char *EncodedString);


 
 
 
 
 
 



 







 















void   lr_abort (void);
void lr_exit(int exit_option, int exit_status);
void lr_abort_ex (unsigned long flags);

void   lr_peek_events (void);


 
 
 
 
 


void   lr_think_time (double secs);

 


void lr_force_think_time (double secs);


 
 
 
 
 



















int   lr_msg (char * fmt, ...);
int   lr_debug_message (unsigned int msg_class,
									    char * format,
										...);
# 513 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/lrun.h"
void   lr_new_prefix (int type,
                                 char * filename,
                                 int line);
# 516 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/lrun.h"
int   lr_log_message (char * fmt, ...);
int   lr_message (char * fmt, ...);
int   lr_error_message (char * fmt, ...);
int   lr_output_message (char * fmt, ...);
int   lr_vuser_status_message (char * fmt, ...);
int   lr_error_message_without_fileline (char * fmt, ...);
int   lr_fail_trans_with_error (char * fmt, ...);

 
 
 
 
 
# 540 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/lrun.h"

 
 
 
 
 





int   lr_next_row ( char * table);
int lr_advance_param ( char * param);



														  
														  

														  
														  

													      
 


char *   lr_eval_string (char * str);
int   lr_eval_string_ext (const char *in_str,
                                     unsigned long const in_len,
                                     char ** const out_str,
                                     unsigned long * const out_len,
                                     unsigned long const options,
                                     const char *file,
								     long const line);
# 574 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/lrun.h"
void   lr_eval_string_ext_free (char * * pstr);

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
int lr_param_increment (char * dst_name,
                              char * src_name);
# 597 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/lrun.h"













											  
											  

											  
											  
											  

int	  lr_save_var (char *              param_val,
							  unsigned long const param_val_len,
							  unsigned long const options,
							  char *			  param_name);
# 621 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/lrun.h"
int   lr_save_string (const char * param_val, const char * param_name);



int   lr_set_custom_error_message (const char * param_val, ...);

int   lr_remove_custom_error_message ();


int   lr_free_parameter (const char * param_name);
int   lr_save_int (const int param_val, const char * param_name);
int   lr_save_timestamp (const char * tmstampParam, ...);
int   lr_save_param_regexp (const char *bufferToScan, unsigned int bufSize, ...);

int   lr_convert_double_to_integer (const char *source_param_name, const char * target_param_name);
int   lr_convert_double_to_double (const char *source_param_name, const char *format_string, const char * target_param_name);

 
 
 
 
 
 
# 700 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/lrun.h"
void   lr_save_datetime (const char *format, int offset, const char *name);









 











 
 
 
 
 






 



char * lr_error_context_get_entry (char * key);

 



long   lr_error_context_get_error_id (void);


 
 
 

int lr_table_get_rows_num (char * param_name);

int lr_table_get_cols_num (char * param_name);

char * lr_table_get_cell_by_col_index (char * param_name, int row, int col);

char * lr_table_get_cell_by_col_name (char * param_name, int row, const char* col_name);

int lr_table_get_column_name_by_index (char * param_name, int col, 
											char * * const col_name,
											size_t * col_name_len);
# 761 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/lrun.h"

int lr_table_get_column_name_by_index_free (char * col_name);

 
 
 
 
# 776 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/lrun.h"
int   lr_zip (const char* param1, const char* param2);
int   lr_unzip (const char* param1, const char* param2);

 
 
 
 
 
 
 
 

 
 
 
 
 
 
int   lr_param_substit (char * file,
                                   int const line,
                                   char * in_str,
                                   size_t const in_len,
                                   char * * const out_str,
                                   size_t * const out_len);
# 800 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/lrun.h"
void   lr_param_substit_free (char * * pstr);


 
# 812 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/lrun.h"





char *   lrfnc_eval_string (char * str,
                                      char * file_name,
                                      long const line_num);
# 820 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/lrun.h"


int   lrfnc_save_string ( const char * param_val,
                                     const char * param_name,
                                     const char * file_name,
                                     long const line_num);
# 826 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/lrun.h"

int   lrfnc_free_parameter (const char * param_name );







typedef struct _lr_timestamp_param
{
	int iDigits;
}lr_timestamp_param;

extern const lr_timestamp_param default_timestamp_param;

int   lrfnc_save_timestamp (const char * param_name, const lr_timestamp_param* time_param);

int lr_save_searched_string(char * buffer, long buf_size, unsigned int occurrence,
			    char * search_string, int offset, unsigned int param_val_len, 
			    char * param_name);

 
char *   lr_string (char * str);

 
# 929 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/lrun.h"

int   lr_save_value (char * param_val,
                                unsigned long const param_val_len,
                                unsigned long const options,
                                char * param_name,
                                char * file_name,
                                long const line_num);
# 936 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/lrun.h"


 
 
 
 
 











int   lr_printf (char * fmt, ...);
 
int   lr_set_debug_message (unsigned int msg_class,
                                       unsigned int swtch);
# 958 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/lrun.h"
unsigned int   lr_get_debug_message (void);


 
 
 
 
 

void   lr_double_think_time ( double secs);
void   lr_usleep (long);


 
 
 
 
 
 




int *   lr_localtime (long offset);


int   lr_send_port (long port);


# 1034 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/lrun.h"



struct _lr_declare_identifier{
	char signature[24];
	char value[128];
};

int   lr_pt_abort (void);

void vuser_declaration (void);






# 1063 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/lrun.h"


# 1075 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/lrun.h"
















 
 
 
 
 







int    _lr_declare_transaction   (char * transaction_name);


 
 
 
 
 







int   _lr_declare_rendezvous  (char * rendezvous_name);

 
 
 
 
 


typedef int PVCI;






typedef int VTCERR;









PVCI   vtc_connect(char * servername, int portnum, int options);
VTCERR   vtc_disconnect(PVCI pvci);
VTCERR   vtc_get_last_error(PVCI pvci);
VTCERR   vtc_query_column(PVCI pvci, char * columnName, int columnIndex, char * *outvalue);
VTCERR   vtc_query_row(PVCI pvci, int rowIndex, char * **outcolumns, char * **outvalues);
VTCERR   vtc_send_message(PVCI pvci, char * column, char * message, unsigned short *outRc);
VTCERR   vtc_send_if_unique(PVCI pvci, char * column, char * message, unsigned short *outRc);
VTCERR   vtc_send_row1(PVCI pvci, char * columnNames, char * messages, char * delimiter, unsigned char sendflag, unsigned short *outUpdates);
VTCERR   vtc_update_message(PVCI pvci, char * column, int index , char * message, unsigned short *outRc);
VTCERR   vtc_update_message_ifequals(PVCI pvci, char * columnName, int index,	char * message, char * ifmessage, unsigned short 	*outRc);
VTCERR   vtc_update_row1(PVCI pvci, char * columnNames, int index , char * messages, char * delimiter, unsigned short *outUpdates);
VTCERR   vtc_retrieve_message(PVCI pvci, char * column, char * *outvalue);
VTCERR   vtc_retrieve_messages1(PVCI pvci, char * columnNames, char * delimiter, char * **outvalues);
VTCERR   vtc_retrieve_row(PVCI pvci, char * **outcolumns, char * **outvalues);
VTCERR   vtc_rotate_message(PVCI pvci, char * column, char * *outvalue, unsigned char sendflag);
VTCERR   vtc_rotate_messages1(PVCI pvci, char * columnNames, char * delimiter, char * **outvalues, unsigned char sendflag);
VTCERR   vtc_rotate_row(PVCI pvci, char * **outcolumns, char * **outvalues, unsigned char sendflag);
VTCERR   vtc_increment(PVCI pvci, char * column, int index , int incrValue, int *outValue);
VTCERR   vtc_clear_message(PVCI pvci, char * column, int index , unsigned short *outRc);
VTCERR   vtc_clear_column(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_ensure_index(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_drop_index(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_clear_row(PVCI pvci, int rowIndex, unsigned short *outRc);
VTCERR   vtc_create_column(PVCI pvci, char * column,unsigned short *outRc);
VTCERR   vtc_column_size(PVCI pvci, char * column, int *size);
void   vtc_free(char * msg);
void   vtc_free_list(char * *msglist);

VTCERR   lrvtc_connect(char * servername, int portnum, int options);
VTCERR   lrvtc_disconnect();
VTCERR   lrvtc_query_column(char * columnName, int columnIndex);
VTCERR   lrvtc_query_row(int columnIndex);
VTCERR   lrvtc_send_message(char * columnName, char * message);
VTCERR   lrvtc_send_if_unique(char * columnName, char * message);
VTCERR   lrvtc_send_row1(char * columnNames, char * messages, char * delimiter, unsigned char sendflag);
VTCERR   lrvtc_update_message(char * columnName, int index , char * message);
VTCERR   lrvtc_update_message_ifequals(char * columnName, int index, char * message, char * ifmessage);
VTCERR   lrvtc_update_row1(char * columnNames, int index , char * messages, char * delimiter);
VTCERR   lrvtc_retrieve_message(char * columnName);
VTCERR   lrvtc_retrieve_messages1(char * columnNames, char * delimiter);
VTCERR   lrvtc_retrieve_row();
VTCERR   lrvtc_rotate_message(char * columnName, unsigned char sendflag);
VTCERR   lrvtc_rotate_messages1(char * columnNames, char * delimiter, unsigned char sendflag);
VTCERR   lrvtc_rotate_row(unsigned char sendflag);
VTCERR   lrvtc_increment(char * columnName, int index , int incrValue);
VTCERR   lrvtc_noop();
VTCERR   lrvtc_clear_message(char * columnName, int index);
VTCERR   lrvtc_clear_column(char * columnName); 
VTCERR   lrvtc_ensure_index(char * columnName); 
VTCERR   lrvtc_drop_index(char * columnName); 
VTCERR   lrvtc_clear_row(int rowIndex);
VTCERR   lrvtc_create_column(char * columnName);
VTCERR   lrvtc_column_size(char * columnName);



 
 
 
 
 

 
int lr_enable_ip_spoofing();
int lr_disable_ip_spoofing();


 




int lr_convert_string_encoding(char * sourceString, char * fromEncoding, char * toEncoding, char * paramName);
int lr_read_file(const char *filename, const char *outputParam, int continueOnError);

int lr_get_char_count(const char * string);


 
int lr_db_connect (char * pFirstArg, ...);
int lr_db_disconnect (char * pFirstArg,	...);
int lr_db_executeSQLStatement (char * pFirstArg, ...);
int lr_db_dataset_action(char * pFirstArg, ...);
int lr_checkpoint(char * pFirstArg,	...);
int lr_db_getvalue(char * pFirstArg, ...);







 
 



















# 6 "globals.h" 2

# 1 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/ctrxfuncs.h" 1
 















 
 



 
 
 
 
 













 
 
 
 
 






















 
















 
 
typedef enum ObjAttribute
{
	ENABLED,
	VISIBLE,
	FOCUSED,
	CHECKED,
	LINES,
	TEXT,
	CAPTURE,
	CAPTURE_LINE,
	ITEM
} eObjAttribute;

typedef enum ConnectionOptionEnum
{
	APPLICATION,
	NETWORK_PROTOCOL,
	ICAFILE,
	CLIENT_NAME
} eConnectionOption;

typedef enum WindowEventEnum
{
	CREATE,
	ACTIVATE
} eWindowEvent;




int ctrx_connect_server(char * server_name, char * username, char * password, char * domain,...);
int ctrx_nfuse_connect(char * mpcUrl, ...);
int ctrx_disconnect_server(char * server_name, ...);
int ctrx_mouse_move(long xPos, long yPos, long buttonId, long modifiers, ...);
int ctrx_mouse_down(long xPos, long yPos, long buttonId, long modifiers, char * window_name, ...);
int ctrx_mouse_up(long xPos, long yPos, long buttonId, long modifiers, char * window_name, ...);
int ctrx_mouse_click(long xPos, long yPos, long buttonId, long modifiers, char * window_name, ...);
int ctrx_mouse_double_click(long xPos, long yPos, long buttonId, long modifiers, char * window_name, ...);
int ctrx_key_down(char * keyId, long modifierState);
int ctrx_key_up(char * keyId, long modifierState);
int ctrx_key(char * keyId, long modifierState,...);
int ctrx_set_window(char * window_name, ...);
int ctrx_set_window_ex(char * window_name, long _time32, ...);
int ctrx_unset_window(char * window_name, ...);
int ctrx_type(char * data, ...);
int ctrx_set_waiting_time(long _time32);
int ctrx_save_bitmap(long xstart, long ystart, long width, long height, char * file_name);
int ctrx_get_bitmap_value(long xstart, long ystart, long width, long height, char * buffer,...);
int ctrx_sync_on_bitmap(long xstart, long ystart, long width, long height, char * hash, ...);
int ctrx_sync_on_bitmap_change(long xstart, long ystart, long width, long height,...);
int ctrx_set_connect_opt(eConnectionOption opt, char * value, ...);
int ctrx_win_exist(char * win_name, long waiting_time, ...);
int ctrx_wait_for_event(char * event_name, ...);
void ctrx_set_exception(char * title, long function, void *this_context);
void ctrx_execute_on_window(char * title, long function, void *this_context);
int ctrx_get_window_name(char * buffer, ...);
int ctrx_get_window_position(char * title, long * xpos, long * ypos, long * width, long * height, ...);
int ctrx_sync_on_window(char * window_name, eWindowEvent event, long xpos, long ypos, long width, long height, char * filename, ...);
int ctrx_activate_window(char * window_name, ...);
int ctrx_get_text(char * window_name, long xpos, long ypos, long width, long height, char * filename, char * text_buffer, ...);
int ctrx_get_text_ocr(char * window_name, long xpos, long ypos, long width, long height, char * filename, char * text_buffer, ...);
int ctrx_get_text_location(char * window_name, long *lpXPos, long *lpYPos, long *lpWidth, long *lpHeight, char * pcText, long bMatchWholeWordOnly,char * filename, ...);
int ctrx_menu_select_item(char * window_name,char * menu_path,...);
int ctrx_list_select_item(char * window_name,long xpos, long ypos,char * item,...);
int ctrx_obj_mouse_move(char * obj_desc,long xPos, long yPos, long buttonId, long modifiers,...);
int ctrx_obj_mouse_up(char * obj_desc,long xPos, long yPos, long buttonId, long modifiers, char * window_name,...);
int ctrx_obj_mouse_down(char * obj_desc,long xPos, long yPos, long buttonId, long modifiers, char * window_name,...);
int ctrx_obj_mouse_click(char * obj_desc,long xPos, long yPos, long buttonId, long modifiers, char * window_name,...);
int ctrx_obj_mouse_double_click(char * obj_desc,long xPos, long yPos, long buttonId, long modifiers, char * window_name,...);
int ctrx_obj_get_info(char * window_name,long xpos, long ypos, eObjAttribute attribute, char *value, ...);
int ctrx_button_get_info(char * window_name,long xpos, long ypos, eObjAttribute attribute, char *value, ...);
int ctrx_edit_get_info(char * window_name,long xpos, long ypos, eObjAttribute attribute, char *value, ...);
int ctrx_list_get_info(char * window_name,long xpos, long ypos, eObjAttribute attribute, char *value, ...);
int ctrx_sync_on_obj_info(char * window_name,long xpos, long ypos, eObjAttribute attribute, char *value, ...);
int ctrx_sync_on_text(long xpos, long ypos, char * value, eObjAttribute textEvent, char * window_name, ...);
int ctrx_sync_on_text_ex(long xpos, long ypos, long width, long height, char * value, char * window_name, ...);
int ctrx_sync_on_text_ocr(long xpos, long ypos, long width, long height, char * value, char * window_name, ...);
int ctrx_logoff(long force, ...);
int ctrx_get_server_name(char * buffer, ...);
int ctrx_run_published_app(char * app_name, ...);
int ctrx_get_waiting_time(long *_time32);

 



 
char	text_buffer[1024];

 
char	object_value_buffer[1024];








# 7 "globals.h" 2

# 1 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/web_api.h" 1







# 1 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/as_web.h" 1



























































 




 



 











 





















 
 
 

  int
	web_add_filter(
		const char *		mpszArg,
		...
	);									 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_add_auto_filter(
		const char *		mpszArg,
		...
	);									 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
	
  int
	web_add_auto_header(
		const char *		mpszHeader,
		const char *		mpszValue);

  int
	web_add_header(
		const char *		mpszHeader,
		const char *		mpszValue);
  int
	web_add_cookie(
		const char *		mpszCookie);
  int
	web_cleanup_auto_headers(void);
  int
	web_cleanup_cookies(void);
  int
	web_concurrent_end(
		const char * const	mpszReserved,
										 
		...								 
	);
  int
	web_concurrent_start(
		const char * const	mpszConcurrentGroupName,
										 
										 
		...								 
										 
	);
  int
	web_create_html_param(
		const char *		mpszParamName,
		const char *		mpszLeftDelim,
		const char *		mpszRightDelim);
  int
	web_create_html_param_ex(
		const char *		mpszParamName,
		const char *		mpszLeftDelim,
		const char *		mpszRightDelim,
		const char *		mpszNum);
  int
	web_custom_request(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	spdy_custom_request(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_disable_keep_alive(void);
  int
	web_enable_keep_alive(void);
  int
	web_find(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_get_int_property(
		const int			miHttpInfoType);
  int
	web_image(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_image_check(
		const char *		mpszName,
		...);
  int
	web_java_check(
		const char *		mpszName,
		...);
  int
	web_link(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

	
  int
	web_global_verification(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
  int
	web_reg_find(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										 
										 
				
  int
	web_reg_save_param(
		const char *		mpszParamName,
		...);							 
										 
										 
										 
										 
										 
										 

  int
	web_convert_param(
		const char * 		mpszParamName, 
										 
		...);							 
										 
										 


										 

										 
  int
	web_remove_auto_filter(
		const char *		mpszArg,
		...
	);									 
										 
				
  int
	web_remove_auto_header(
		const char *		mpszHeaderName,
		...);							 
										 



  int
	web_remove_cookie(
		const char *		mpszCookie);

  int
	web_save_header(
		const char *		mpszType,	 
		const char *		mpszName);	 
  int
	web_set_certificate(
		const char *		mpszIndex);
  int
	web_set_certificate_ex(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_set_connections_limit(
		const char *		mpszLimit);
  int
	web_set_max_html_param_len(
		const char *		mpszLen);
  int
	web_set_max_retries(
		const char *		mpszMaxRetries);
  int
	web_set_proxy(
		const char *		mpszProxyHost);
  int
	web_set_pac(
		const char *		mpszPacUrl);
  int
	web_set_proxy_bypass(
		const char *		mpszBypass);
  int
	web_set_secure_proxy(
		const char *		mpszProxyHost);
  int
	web_set_sockets_option(
		const char *		mpszOptionID,
		const char *		mpszOptionValue
	);
  int
	web_set_option(
		const char *		mpszOptionID,
		const char *		mpszOptionValue,
		...								 
	);
  int
	web_set_timeout(
		const char *		mpszWhat,
		const char *		mpszTimeout);
  int
	web_set_user(
		const char *		mpszUserName,
		const char *		mpszPwd,
		const char *		mpszHost);

  int
	web_sjis_to_euc_param(
		const char *		mpszParamName,
										 
		const char *		mpszParamValSjis);
										 

  int
	web_submit_data(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	spdy_submit_data(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_submit_form(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_url(
		const char *		mpszUrlName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	spdy_url(
		const char *		mpszUrlName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int 
	web_set_proxy_bypass_local(
		const char * mpszNoLocal
		);

  int 
	web_cache_cleanup(void);

  int
	web_create_html_query(
		const char* mpszStartQuery,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int 
	web_create_radio_button_param(
		const char *NameFiled,
		const char *NameAndVal,
		const char *ParamName
		);

  int
	web_convert_from_formatted(
		const char * mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										
  int
	web_convert_to_formatted(
		const char * mpszArg1,
		...);							 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_ex(
		const char * mpszParamName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_xpath(
		const char * mpszParamName,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_json(
		const char * mpszParamName,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_regexp(
		 const char * mpszParamName,
		 ...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_attrib(
		const char * mpszParamName,
		...);
										 
										 
										 
										 
										 
										 
										 		
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_js_run(
		const char * mpszCode,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_js_reset(void);

  int
	web_convert_date_param(
		const char * 		mpszParamName,
		...);










# 789 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/as_web.h"


# 802 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/as_web.h"



























# 840 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/as_web.h"

 
 
 


  int
	FormSubmit(
		const char *		mpszFormName,
		...);
  int
	InitWebVuser(void);
  int
	SetUser(
		const char *		mpszUserName,
		const char *		mpszPwd,
		const char *		mpszHost);
  int
	TerminateWebVuser(void);
  int
	URL(
		const char *		mpszUrlName);
























# 908 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/as_web.h"


  int
	web_rest(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 

  int
web_stream_open(
	const char *		mpszArg1,
	...
);
  int
	web_stream_wait(
		const char *		mpszArg1,
		...
	);

  int
	web_stream_close(
		const char *		mpszArg1,
		...
	);

  int
web_stream_play(
	const char *		mpszArg1,
	...
	);

  int
web_stream_pause(
	const char *		mpszArg1,
	...
	);

  int
web_stream_seek(
	const char *		mpszArg1,
	...
	);

  int
web_stream_get_param_int(
	const char*			mpszStreamID,
	const int			miStateType
	);

  double
web_stream_get_param_double(
	const char*			mpszStreamID,
	const int			miStateType
	);

  int
web_stream_get_param_string(
	const char*			mpszStreamID,
	const int			miStateType,
	const char*			mpszParameterName
	);

  int
web_stream_set_param_int(
	const char*			mpszStreamID,
	const int			miStateType,
	const int			miStateValue
	);

  int
web_stream_set_param_double(
	const char*			mpszStreamID,
	const int			miStateType,
	const double		mdfStateValue
	);

  int
web_stream_set_custom_mpd(
	const char*			mpszStreamID,
	const char*			aMpdBuf
	);

 
 
 






# 9 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/web_api.h" 2

















 







 















  int
	web_reg_add_cookie(
		const char *		mpszCookie,
		...);							 
										 

  int
	web_report_data_point(
		const char *		mpszEventType,
		const char *		mpszEventName,
		const char *		mpszDataPointName,
		const char *		mpszLAST);	 
										 
										 
										 

  int
	web_text_link(
		const char *		mpszStepName,
		...);

  int
	web_element(
		const char *		mpszStepName,
		...);

  int
	web_image_link(
		const char *		mpszStepName,
		...);

  int
	web_static_image(
		const char *		mpszStepName,
		...);

  int
	web_image_submit(
		const char *		mpszStepName,
		...);

  int
	web_button(
		const char *		mpszStepName,
		...);

  int
	web_edit_field(
		const char *		mpszStepName,
		...);

  int
	web_radio_group(
		const char *		mpszStepName,
		...);

  int
	web_check_box(
		const char *		mpszStepName,
		...);

  int
	web_list(
		const char *		mpszStepName,
		...);

  int
	web_text_area(
		const char *		mpszStepName,
		...);

  int
	web_map_area(
		const char *		mpszStepName,
		...);

  int
	web_eval_java_script(
		const char *		mpszStepName,
		...);

  int
	web_reg_dialog(
		const char *		mpszArg1,
		...);

  int
	web_reg_cross_step_download(
		const char *		mpszArg1,
		...);

  int
	web_browser(
		const char *		mpszStepName,
		...);

  int
	web_control(
		const char *		mpszStepName,
		...);

  int
	web_set_rts_key(
		const char *		mpszArg1,
		...);

  int
	web_save_param_length(
		const char * 		mpszParamName,
		...);

  int
	web_save_timestamp_param(
		const char * 		mpszParamName,
		...);

  int
	web_load_cache(
		const char *		mpszStepName,
		...);							 
										 

  int
	web_dump_cache(
		const char *		mpszStepName,
		...);							 
										 
										 

  int
	web_reg_find_in_log(
		const char *		mpszArg1,
		...);							 
										 
										 

  int
	web_get_sockets_info(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 

  int
	web_add_cookie_ex(
		const char *		mpszArg1,
		...);							 
										 
										 
										 

  int
	web_hook_java_script(
		const char *		mpszArg1,
		...);							 
										 
										 
										 

 
 
 
 
 
 
 
 
 
 
 
 
  int
	web_reg_async_attributes(
		const char *		mpszArg,
		...
	);

 
 
 
 
 
 
  int
	web_sync(
		 const char *		mpszArg1,
		 ...
	);

 
 
 
 
  int
	web_stop_async(
		const char *		mpszArg1,
		...
	);

 
 
 
 
 

 
 
 

typedef enum WEB_ASYNC_CB_RC_ENUM_T
{
	WEB_ASYNC_CB_RC_OK,				 

	WEB_ASYNC_CB_RC_ABORT_ASYNC_NOT_ERROR,
	WEB_ASYNC_CB_RC_ABORT_ASYNC_ERROR,
										 
										 
										 
										 
	WEB_ASYNC_CB_RC_ENUM_COUNT
} WEB_ASYNC_CB_RC_ENUM;

 
 
 

typedef enum WEB_CONVERS_CB_CALL_REASON_ENUM_T
{
	WEB_CONVERS_CB_CALL_REASON_BUFFER_RECEIVED,
	WEB_CONVERS_CB_CALL_REASON_END_OF_TASK,

	WEB_CONVERS_CB_CALL_REASON_ENUM_COUNT
} WEB_CONVERS_CB_CALL_REASON_ENUM;

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

typedef
int														 
	(*RequestCB_t)();

typedef
int														 
	(*ResponseBodyBufferCB_t)(
		  const char *		aLastBufferStr,
		  int				aLastBufferLen,
		  const char *		aAccumulatedStr,
		  int				aAccumulatedLen,
		  int				aHttpStatusCode);

typedef
int														 
	(*ResponseCB_t)(
		  const char *		aResponseHeadersStr,
		  int				aResponseHeadersLen,
		  const char *		aResponseBodyStr,
		  int				aResponseBodyLen,
		  int				aHttpStatusCode);

typedef
int														 
	(*ResponseHeadersCB_t)(
		  int				aHttpStatusCode,
		  const char *		aAccumulatedHeadersStr,
		  int				aAccumulatedHeadersLen);



 
 
 

typedef enum WEB_CONVERS_UTIL_RC_ENUM_T
{
	WEB_CONVERS_UTIL_RC_OK,
	WEB_CONVERS_UTIL_RC_CONVERS_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_TASK_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_INFO_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_INFO_UNAVIALABLE,
	WEB_CONVERS_UTIL_RC_INVALID_ARGUMENT,

	WEB_CONVERS_UTIL_RC_ENUM_COUNT
} WEB_CONVERS_UTIL_RC_ENUM;

 
 
 

  int					 
	web_util_set_request_url(
		  const char *		aUrlStr);

  int					 
	web_util_set_request_body(
		  const char *		aRequestBodyStr);

  int					 
	web_util_set_formatted_request_body(
		  const char *		aRequestBodyStr);


 
 
 
 
 

 
 
 
 
 

 
 
 
 
 
 
 
 

 
 
  int
web_websocket_connect(
		 const char *	mpszArg1,
		 ...
		 );


 
 
 
 
 																						
  int
web_websocket_send(
	   const char *		mpszArg1,
		...
	   );

 
 
 
 
 
 
  int
web_websocket_close(
		const char *	mpszArg1,
		...
		);

 
typedef
void														
(*OnOpen_t)(
			  const char* connectionID,  
			  const char * responseHeader,  
			  int length  
);

typedef
void														
(*OnMessage_t)(
	  const char* connectionID,  
	  int isbinary,  
	  const char * data,  
	  int length  
	);

typedef
void														
(*OnError_t)(
	  const char* connectionID,  
	  const char * message,  
	  int length  
	);

typedef
void														
(*OnClose_t)(
	  const char* connectionID,  
	  int isClosedByClient,  
	  int code,  
	  const char* reason,  
	  int length  
	 );
 
 
 
 
 





# 8 "globals.h" 2

# 1 "lrw_custom_body.h" 1
 




# 9 "globals.h" 2


 
 


# 1 "c:\\users\\siva.kota\\documents\\phase2\\cad_treatment_plan_p2_v2\\\\combined_CAD_Treatment_Plan_P2_v2.c" 2


# 1 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/SharedParameter.h" 1



 
 
 
 
# 100 "C:\\Program Files (x86)\\HPE\\LoadRunner\\include/SharedParameter.h"






typedef int PVCI2;






typedef int VTCERR2;


 
 
 

 
extern PVCI2    vtc_connect(char *servername, int portnum, int options);
extern VTCERR2  vtc_disconnect(PVCI2 pvci);
extern VTCERR2  vtc_get_last_error(PVCI2 pvci);

 
extern VTCERR2  vtc_query_column(PVCI2 pvci, char *columnName, int columnIndex, char **outvalue);
extern VTCERR2  vtc_query_row(PVCI2 pvci, int columnIndex, char ***outcolumns, char ***outvalues);
extern VTCERR2  vtc_send_message(PVCI2 pvci, char *column, char *message, unsigned short *outRc);
extern VTCERR2  vtc_send_if_unique(PVCI2 pvci, char *column, char *message, unsigned short *outRc);
extern VTCERR2  vtc_send_row1(PVCI2 pvci, char *columnNames, char *messages, char *delimiter,  unsigned char sendflag, unsigned short *outUpdates);
extern VTCERR2  vtc_update_message(PVCI2 pvci, char *column, int index , char *message, unsigned short *outRc);
extern VTCERR2  vtc_update_message_ifequals(PVCI2 pvci, char	*columnName, int index,	char *message, char	*ifmessage,	unsigned short 	*outRc);
extern VTCERR2  vtc_update_row1(PVCI2 pvci, char *columnNames, int index , char *messages, char *delimiter, unsigned short *outUpdates);
extern VTCERR2  vtc_retrieve_message(PVCI2 pvci, char *column, char **outvalue);
extern VTCERR2  vtc_retrieve_messages1(PVCI2 pvci, char *columnNames, char *delimiter, char ***outvalues);
extern VTCERR2  vtc_retrieve_row(PVCI2 pvci, char ***outcolumns, char ***outvalues);
extern VTCERR2  vtc_rotate_message(PVCI2 pvci, char *column, char **outvalue, unsigned char sendflag);
extern VTCERR2  vtc_rotate_messages1(PVCI2 pvci, char *columnNames, char *delimiter, char ***outvalues, unsigned char sendflag);
extern VTCERR2  vtc_rotate_row(PVCI2 pvci, char ***outcolumns, char ***outvalues, unsigned char sendflag);
extern VTCERR2	vtc_increment(PVCI2 pvci, char *column, int index , int incrValue, int *outValue);
extern VTCERR2  vtc_clear_message(PVCI2 pvci, char *column, int index , unsigned short *outRc);
extern VTCERR2  vtc_clear_column(PVCI2 pvci, char *column, unsigned short *outRc);

extern VTCERR2  vtc_clear_row(PVCI2 pvci, int rowIndex, unsigned short *outRc);

extern VTCERR2  vtc_create_column(PVCI2 pvci, char *column,unsigned short *outRc);
extern VTCERR2  vtc_column_size(PVCI2 pvci, char *column, int *size);
extern VTCERR2  vtc_ensure_index(PVCI2 pvci, char *column, unsigned short *outRc);
extern VTCERR2  vtc_drop_index(PVCI2 pvci, char *column, unsigned short *outRc);

extern VTCERR2  vtc_noop(PVCI2 pvci);

 
extern void vtc_free(char *msg);
extern void vtc_free_list(char **msglist);

 


 




 




















 




 
 
 

extern VTCERR2  lrvtc_connect(char *servername, int portnum, int options);
extern VTCERR2  lrvtc_disconnect();
extern VTCERR2  lrvtc_query_column(char *columnName, int columnIndex);
extern VTCERR2  lrvtc_query_row(int columnIndex);
extern VTCERR2  lrvtc_send_message(char *columnName, char *message);
extern VTCERR2  lrvtc_send_if_unique(char *columnName, char *message);
extern VTCERR2  lrvtc_send_row1(char *columnNames, char *messages, char *delimiter,  unsigned char sendflag);
extern VTCERR2  lrvtc_update_message(char *columnName, int index , char *message);
extern VTCERR2  lrvtc_update_message_ifequals(char *columnName, int index, char 	*message, char *ifmessage);
extern VTCERR2  lrvtc_update_row1(char *columnNames, int index , char *messages, char *delimiter);
extern VTCERR2  lrvtc_retrieve_message(char *columnName);
extern VTCERR2  lrvtc_retrieve_messages1(char *columnNames, char *delimiter);
extern VTCERR2  lrvtc_retrieve_row();
extern VTCERR2  lrvtc_rotate_message(char *columnName, unsigned char sendflag);
extern VTCERR2  lrvtc_rotate_messages1(char *columnNames, char *delimiter, unsigned char sendflag);
extern VTCERR2  lrvtc_rotate_row(unsigned char sendflag);
extern VTCERR2  lrvtc_increment(char *columnName, int index , int incrValue);
extern VTCERR2  lrvtc_clear_message(char *columnName, int index);
extern VTCERR2  lrvtc_clear_column(char *columnName);
extern VTCERR2  lrvtc_clear_row(int rowIndex);
extern VTCERR2  lrvtc_create_column(char *columnName);
extern VTCERR2  lrvtc_column_size(char *columnName);
extern VTCERR2  lrvtc_ensure_index(char *columnName);
extern VTCERR2  lrvtc_drop_index(char *columnName);

extern VTCERR2  lrvtc_noop();

 
 
 

                               


 
 
 





















# 3 "c:\\users\\siva.kota\\documents\\phase2\\cad_treatment_plan_p2_v2\\\\combined_CAD_Treatment_Plan_P2_v2.c" 2


# 1 "vuser_init.c" 1
vuser_init()
{
	return 0;
}
# 5 "c:\\users\\siva.kota\\documents\\phase2\\cad_treatment_plan_p2_v2\\\\combined_CAD_Treatment_Plan_P2_v2.c" 2

# 1 "Action.c" 1
Action()
{

	web_set_sockets_option("SSL_VERSION", "TLS");
	
	lr_start_transaction("CAD_00_Portal_URL");



	web_url("SmileDirectClubWeb", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EXTRARES", 
		"Url=receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", "ENDITEM", 
		"Url=custom/style.css", "ENDITEM", 
		"Url=receiver/js/external/jquery.dotdotdot.min_08EE54CBA886AD0A.js", "ENDITEM", 
		"Url=receiver/js/external/hammer.v2.0.8.min_F699A1E56189259A.js", "ENDITEM", 
		"Url=receiver/js/external/velocity.min_B218502A82F66680.js", "ENDITEM", 
		"Url=receiver/images/1x/CitrixReceiver_WebScreen_CBE548FB8FEE049E.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", "ENDITEM", 
		"Url=receiver/js/external/slick.min_FEB62CC230E2BA2A.js", "ENDITEM", 
		"Url=receiver/js/ctxs.core.min_33B1CC992A07D57E.js", "ENDITEM", 
		"Url=receiver/js/ctxs.webui.min_895B3076E3BA6027.js", "ENDITEM", 
		"Url=receiver/images/1x/folder_template_C13BB96DEBC9F30F.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", "ENDITEM", 
		"Url=receiver/images/1x/actionSprite_531B7A6FF85CA98E.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", "ENDITEM", 
		"Url=receiver/images/common/ReceiverFullScreenBackground_46E559C0E6B5A27B.jpg", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", "ENDITEM", 
		"Url=custom/strings.en.js", "ENDITEM", 
		"Url=custom/script.js", "ENDITEM", 
		"Url=receiver/images/1x/viewSprite_B2F322BDCB824FAF.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", "ENDITEM", 
		"Url=receiver/images/common/authspinner_B0BCD339560CA593.gif", "ENDITEM", 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL2NqTTJXVmxLZW1OTFNISnJWREJMZG5GbGRWbGxTVGNyTVRFMFBRLS0vaW1hZ2U-?size=128", "ENDITEM", 
		"Url=receiver/images/common/icon_loading_9A0623127A028FEB.png", "ENDITEM", 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL2NFTm9NM1JKUnpObVZFTnpORXhRTUUxT2EyY3lVa3N5TXl0alBRLS0vaW1hZ2U-?size=128", "ENDITEM", 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL1duZHhaRlZXV0VWTWRuYzNPRGw2VEhWUUsyRkNTSE5WYVhoclBRLS0vaW1hZ2U-?size=128", "ENDITEM", 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL1UxZFNOblpTYkhaRmVUbEJNRzAzTjB3MWNHRkRLMUIyYm1zNFBRLS0vaW1hZ2U-?size=128", "ENDITEM", 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL00zZE9NVWROUmtWMFQwZDBhME5yWVRJM2NsaDBia04yUTFkU1QxbFNkVGhXU1ZWQlRXWlNWbFJpZHowLS9pbWFnZQ--?size=128", "ENDITEM", 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL2JHRnhlRmhYYmtwdmJqbFVWV3hwVlZaV1EyOXBlbmxITTI5QlBRLS0vaW1hZ2U-?size=128", "ENDITEM", 
		"LAST");

	web_add_auto_header("X-Citrix-IsUsingHTTPS", 
		"Yes");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

 





	web_reg_save_param_ex(
		"ParamName=CitrixXenApp_CsrfToken",
		"LB/IC=CsrfToken=",
		"RB/IC=;",
		"SEARCH_FILTERS",
		"Scope=Cookies",
		"LAST");

	web_custom_request("Configuration", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Home/Configuration", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=", 
		"LAST");

	web_add_auto_header("Csrf-Token",
		"{CitrixXenApp_CsrfToken}");

	web_custom_request("GetDetectionTicket", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionTicket", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"EncType=", 
		"LAST");

	web_custom_request("GetDetectionStatus", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionStatus", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body=ticket=CDT_9nFRkPaYWvAovijmDKzZu5os7s6RSyZrruQNGEX7WtimRnEGyMpb!u0p0vT_wcPb", 
		"LAST");

	web_custom_request("GetDetectionStatus_2", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionStatus", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body=ticket=CDT_9nFRkPaYWvAovijmDKzZu5os7s6RSyZrruQNGEX7WtimRnEGyMpb!u0p0vT_wcPb", 
		"LAST");

	web_add_cookie("CtxsUserPreferredClient=Native; DOMAIN=storefront.smileco.com");

	web_add_cookie("CtxsClientDetectionDone=true; DOMAIN=storefront.smileco.com");

	web_add_cookie("CtxsHasUpgradeBeenShown=true; DOMAIN=storefront.smileco.com");

	web_submit_data("List", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/List", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=format", "Value=json", "ENDITEM", 
		"Name=resourceDetails", "Value=Default", "ENDITEM", 
		"LAST");

	web_custom_request("GetAuthMethods", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Authentication/GetAuthMethods", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=", 
		"LAST");
	
	
	web_custom_request("Login", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ExplicitAuth/Login", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/vnd.citrix.authenticateresponse-1+xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncType=", 
		"EXTRARES", 
		"Url=../receiver/images/1x/CitrixStoreFront_auth_14B96BFF2B0A6FF8.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", "ENDITEM", 
		"Url=../receiver/images/1x/spinner_white_auth_button_53FD5A337A529DA7.gif", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", "ENDITEM", 
		"LAST");

	web_submit_data("LoginAttempt", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ExplicitAuth/LoginAttempt", 
		"Method=POST", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		"ITEMDATA", 
		"Name=username", "Value={UserName}", "ENDITEM", 
		"Name=password", "Value={Password}", "ENDITEM", 
		"Name=saveCredentials", "Value=false", "ENDITEM", 
		"Name=loginBtn", "Value=Log On", "ENDITEM", 
		"Name=StateContext", "Value=", "ENDITEM", 
		"LAST");

	(web_remove_auto_header("Csrf-Token", "ImplicitGen=Yes", "LAST"));

	(web_remove_auto_header("X-Citrix-IsUsingHTTPS", "ImplicitGen=Yes", "LAST"));

	(web_remove_auto_header("X-Requested-With", "ImplicitGen=Yes", "LAST"));

	web_custom_request("reportDetectionStatus", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClub/clientAssistant/reportDetectionStatus", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"Body=ticket=CDT_9nFRkPaYWvAovijmDKzZu5os7s6RSyZrruQNGEX7WtimRnEGyMpb!u0p0vT_wcPb&protocolVersion=1&hdxVersion=14.7.0.13011&hdxIsPassthrough=False&hdxIsPassthroughVariable=False", 
		"LAST");

 

	web_add_auto_header("Csrf-Token",
		"{CitrixXenApp_CsrfToken}");

	web_add_auto_header("X-Citrix-IsUsingHTTPS", 
		"Yes");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_submit_data("List_2", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/List", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=format", "Value=json", "ENDITEM", 
		"Name=resourceDetails", "Value=Default", "ENDITEM", 
		"EXTRARES", 
		"Url=../receiver/images/1x/CitrixReceiverLogo_Home_5C24BCEC5A182425.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", "ENDITEM", 
		"Url=../receiver/images/1x/spinner_5CF0D1C8A76AAC8E.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", "ENDITEM", 
		"Url=../receiver/images/1x/search_close_BC5A22358E58905F.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", "ENDITEM", 
		"Url=../receiver/images/1x/ico_search_E84E3D63D821F80D.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", "ENDITEM", 
		"LAST");

	web_custom_request("GetUserName", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Authentication/GetUserName", 
		"Method=POST", 
		"Resource=0", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"EncType=", 
		"LAST");

	web_custom_request("AllowSelfServiceAccountManagement", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ExplicitAuth/AllowSelfServiceAccountManagement", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"EncType=", 
		"LAST");
	
	lr_end_transaction("CAD_00_Portal_URL", 2);

	lr_think_time(45);

	lr_start_transaction("CAD_BP3_01_CLick_ICA");

	web_submit_data("{ICA_FILE}", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/GetLaunchStatus/{ICA_FILE}", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=displayNameDesktopTitle", "Value={CITRIX_DESKTOP}", "ENDITEM", 
		"Name=createFileFetchTicket", "Value=false", "ENDITEM", 
		"EXTRARES", 
 
 
 
		"LAST");

	ctrx_nfuse_connect("https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/LaunchIca/{ICA_FILE}.ica?CsrfToken={CitrixXenApp_CsrfToken}&IsUsingHttps=Yes&displayNameDesktopTitle={CITRIX_DESKTOP}&launchId=1567587516803", "last");



	ctrx_wait_for_event("LOGON", "last");

	lr_end_transaction("CAD_BP3_01_CLick_ICA",2);
	
	lr_think_time(45);

	lr_start_transaction("CAD_BP3_03_Open_CAD_App");

	ctrx_mouse_double_click(38, 217, 1, 0, "NULL=snapshot1", "last");

	lr_end_transaction("CAD_BP3_03_Open_CAD_App",2);
	
	lr_think_time(30);

	lr_start_transaction("CAD_BP3_04_Click_Patient");

	ctrx_sync_on_window("CA Digital - CA Digital", ACTIVATE, 0, 0, 1281, 985, "snapshot2", "last");

	ctrx_mouse_click(330, 632, 1, 0, "CA Digital - CA Digital=snapshot3", "last");

	lr_end_transaction("CAD_BP3_04_Click_Patient",2);
	
	lr_think_time(10);

	lr_start_transaction("CAD_BP3_05_Create_Patient");

	ctrx_mouse_click(887, 758, 1, 0, "CA Digital - CA Digital=snapshot4", "last");

	lr_end_transaction("CAD_BP3_05_Create_Patient",2);

	lr_start_transaction("CAD_BP3_06_Patient_Details");

	ctrx_mouse_click(1127, 263, 1, 0, "CA Digital - CA Digital=snapshot5", "last");

	ctrx_type("CAD{PatientID}", "", "last");

	ctrx_mouse_click(1116, 299, 1, 0, "CA Digital - CA Digital=snapshot8", "last");

	ctrx_type("CAF{PatientID}", "", "last");

	ctrx_mouse_click(1125, 338, 1, 0, "CA Digital - CA Digital=snapshot10", "last");

	ctrx_type("CAL{PatientID}", "", "last");

	ctrx_mouse_click(1134, 383, 1, 0, "CA Digital - CA Digital=snapshot12", "last");

	ctrx_type("01/07/1986", "", "last");

	ctrx_mouse_click(1125, 424, 1, 0, "CA Digital - CA Digital=snapshot31", "last");

	ctrx_type("MRN{PatientID}", "", "last");

	ctrx_mouse_click(1131, 498, 1, 0, "CA Digital - CA Digital=snapshot33", "last");

	ctrx_type("09/06/2019", "", "last");

	ctrx_mouse_click(1182, 901, 1, 0, "CA Digital - CA Digital=snapshot36", "last");

	lr_end_transaction("CAD_BP3_06_Patient_Details",2);

	lr_think_time(30);

	lr_start_transaction("CAD_BP3_07_Import_STLFiles");

	ctrx_mouse_click(249, 62, 1, 0, "CA Digital - CA Digital=snapshot37", "last");

	ctrx_sync_on_window("Load document...", ACTIVATE, 415, 309, 450, 364, "snapshot38", "last");

	ctrx_mouse_click(426, 211, 1, 0, "Load document...=snapshot39", "last");

	ctrx_sync_on_window("Open", ACTIVATE, 220, 272, 841, 433, "snapshot40", "last");

	ctrx_mouse_click(351, 99, 1, 0, "Open=snapshot41", "last");

	ctrx_mouse_click(774, 375, 1, 0, "Open=snapshot42", "last");

	ctrx_sync_on_window("Load document...", ACTIVATE, 415, 309, 450, 364, "snapshot43", "last");

	ctrx_mouse_click(427, 247, 1, 0, "Load document...=snapshot44", "last");

	ctrx_sync_on_window("Open", ACTIVATE, 220, 272, 841, 433, "snapshot45", "last");

	ctrx_mouse_click(372, 79, 1, 0, "Open=snapshot46", "last");

	ctrx_mouse_click(786, 372, 1, 0, "Open=snapshot47", "last");
	
	lr_end_transaction("CAD_BP3_07_Import_STLFiles",2);

	lr_think_time(15);
	
	lr_start_transaction("CAD_BP3_08_LoadSTLFiles");


	ctrx_sync_on_window("Load document...", ACTIVATE, 415, 309, 450, 364, "snapshot48", "last");

	ctrx_mouse_click(216, 341, 1, 0, "Load document...=snapshot49", "last");

	lr_end_transaction("CAD_BP3_08_LoadSTLFiles", 2);


	lr_think_time(60);

	lr_start_transaction("CAD_BP3_09_Open_Impressions");

	ctrx_sync_on_window("CA Digital - CA Digital", ACTIVATE, 0, 0, 1281, 985, "snapshot50", "last");

	ctrx_mouse_double_click(293, 288, 1, 0, "CA Digital - CA Digital=snapshot51", "last");

	lr_end_transaction("CAD_BP3_09_Open_Impressions",2);

	lr_think_time(45);

	lr_start_transaction("CAD_BP3_10_Step_1");

	ctrx_sync_on_window("CA Digital - CA Digital_2", ACTIVATE, 0, 0, 1281, 985, "snapshot52", "last");

	ctrx_mouse_click(536, 184, 1, 0, "CA Digital - CA Digital_2=snapshot53", "last");

	ctrx_mouse_click(536, 184, 1, 0, "CA Digital - CA Digital_2=snapshot54", "last");

	(web_remove_auto_header("Csrf-Token", "ImplicitGen=Yes", "LAST"));

	(web_remove_auto_header("X-Citrix-IsUsingHTTPS", "ImplicitGen=Yes", "LAST"));

	(web_remove_auto_header("X-Requested-With", "ImplicitGen=Yes", "LAST"));

	lr_think_time(5);

	ctrx_mouse_click(504, 186, 1, 0, "CA Digital - CA Digital_2=snapshot55", "last");

	ctrx_mouse_click(504, 186, 1, 0, "CA Digital - CA Digital_2=snapshot56", "last");

	lr_end_transaction("CAD_BP3_10_Step_1",2);

	lr_think_time(30);

	lr_start_transaction("CAD_BP3_11_Step_2");

	ctrx_mouse_click(124, 130, 1, 0, "CA Digital - CA Digital_2=snapshot57", "last");

	lr_think_time(15);

	ctrx_mouse_click(789, 521, 1, 0, "CA Digital - CA Digital_2=snapshot58", "last");
	
	lr_think_time(4);

	ctrx_mouse_click(950, 523, 1, 0, "CA Digital - CA Digital_2=snapshot59", "last");

	lr_think_time(4);
	
	ctrx_mouse_click(791, 629, 1, 0, "CA Digital - CA Digital_2=snapshot60", "last");

	lr_think_time(4);
	
	ctrx_mouse_click(950, 630, 1, 0, "CA Digital - CA Digital_2=snapshot61", "last");

	lr_think_time(4);
	
	ctrx_mouse_click(159, 648, 1, 0, "CA Digital - CA Digital_2=snapshot62", "last");

	lr_think_time(4);
	
	ctrx_mouse_click(169, 712, 1, 0, "CA Digital - CA Digital_2=snapshot63", "last");

	lr_think_time(4);
	
	ctrx_mouse_click(172, 766, 1, 0, "CA Digital - CA Digital_2=snapshot64", "last");

	lr_think_time(4);
	
	ctrx_mouse_click(181, 803, 1, 0, "CA Digital - CA Digital_2=snapshot65", "last");

	lr_think_time(4);
	
	ctrx_mouse_click(190, 848, 1, 0, "CA Digital - CA Digital_2=snapshot66", "last");

	lr_think_time(4);
	
	ctrx_mouse_click(215, 875, 1, 0, "CA Digital - CA Digital_2=snapshot67", "last");

	lr_think_time(4);
	
	ctrx_mouse_click(250, 889, 1, 0, "CA Digital - CA Digital_2=snapshot68", "last");

	lr_think_time(4);
	
	ctrx_mouse_click(282, 896, 1, 0, "CA Digital - CA Digital_2=snapshot69", "last");

	lr_think_time(4);
	
	ctrx_mouse_click(317, 893, 1, 0, "CA Digital - CA Digital_2=snapshot70", "last");

	lr_think_time(4);
	
	ctrx_mouse_click(356, 870, 1, 0, "CA Digital - CA Digital_2=snapshot71", "last");

	lr_think_time(4);
	
	ctrx_mouse_click(376, 830, 1, 0, "CA Digital - CA Digital_2=snapshot72", "last");

	lr_think_time(4);
	
	ctrx_mouse_click(392, 795, 1, 0, "CA Digital - CA Digital_2=snapshot73", "last");

	lr_think_time(4);
	
	ctrx_mouse_click(408, 745, 1, 0, "CA Digital - CA Digital_2=snapshot74", "last");

	lr_think_time(4);
	
	ctrx_mouse_click(439, 687, 1, 0, "CA Digital - CA Digital_2=snapshot75", "last");

	lr_think_time(4);
	
	ctrx_mouse_click(142, 493, 1, 0, "CA Digital - CA Digital_2=snapshot76", "last");

	lr_think_time(4);
	
	ctrx_mouse_click(151, 430, 1, 0, "CA Digital - CA Digital_2=snapshot77", "last");

	lr_think_time(4);
	
	ctrx_mouse_click(159, 383, 1, 0, "CA Digital - CA Digital_2=snapshot78", "last");

	lr_think_time(4);
	
	ctrx_mouse_click(168, 343, 1, 0, "CA Digital - CA Digital_2=snapshot79", "last");

	lr_think_time(4);
	
	ctrx_mouse_click(179, 297, 1, 0, "CA Digital - CA Digital_2=snapshot80", "last");

	lr_think_time(4);
	
	ctrx_mouse_click(203, 260, 1, 0, "CA Digital - CA Digital_2=snapshot81", "last");

	lr_think_time(4);
	
	ctrx_mouse_click(246, 241, 1, 0, "CA Digital - CA Digital_2=snapshot82", "last");

	lr_think_time(4);
	
	ctrx_mouse_click(294, 237, 1, 0, "CA Digital - CA Digital_2=snapshot83", "last");

	lr_think_time(4);
	
	ctrx_mouse_click(341, 244, 1, 0, "CA Digital - CA Digital_2=snapshot84", "last");

	lr_think_time(4);
	
	ctrx_mouse_click(377, 282, 1, 0, "CA Digital - CA Digital_2=snapshot85", "last");

	lr_think_time(4);
	
	ctrx_mouse_click(396, 326, 1, 0, "CA Digital - CA Digital_2=snapshot86", "last");

	lr_think_time(4);
	
	ctrx_mouse_click(417, 362, 1, 0, "CA Digital - CA Digital_2=snapshot87", "last");

	lr_think_time(4);
	
	ctrx_mouse_click(430, 408, 1, 0, "CA Digital - CA Digital_2=snapshot88", "last");

	lr_think_time(4);
	
	ctrx_mouse_click(451, 462, 1, 0, "CA Digital - CA Digital_2=snapshot89", "last");

	lr_think_time(4);

	ctrx_mouse_click(806, 578, 1, 0, "CA Digital - CA Digital_2=snapshot90", "last");

	lr_think_time(30);

	ctrx_mouse_down(461, 478, 1, 0, "CA Digital - CA Digital_2=snapshot91", "last");

	ctrx_mouse_up(467, 489, 1, 0, "CA Digital - CA Digital_2=snapshot92", "last");

	ctrx_mouse_down(469, 474, 1, 0, "CA Digital - CA Digital_2=snapshot93", "last");

	ctrx_mouse_up(481, 486, 1, 0, "CA Digital - CA Digital_2=snapshot94", "last");

	ctrx_mouse_click(945, 570, 1, 0, "CA Digital - CA Digital_2=snapshot95", "last");

	lr_end_transaction("CAD_BP3_11_Step_2",2);

	lr_think_time(30);

	lr_start_transaction("CAD_BP3_12_Step_3");

	ctrx_mouse_click(190, 134, 1, 0, "CA Digital - CA Digital_2=snapshot96", "last");

	lr_end_transaction("CAD_BP3_12_Step_3",2);

	lr_think_time(120);

	lr_start_transaction("CAD_BP3_13_Step_4");

	ctrx_mouse_click(256, 130, 1, 0, "CA Digital - CA Digital_2=snapshot97", "last");

	lr_end_transaction("CAD_BP3_13_Step_4",2);

	lr_think_time(60);

	lr_start_transaction("CAD_BP3_14_Export_STL");

	ctrx_mouse_click(54, 918, 1, 0, "CA Digital - CA Digital_2=snapshot98", "last");

	ctrx_sync_on_window("Save", ACTIVATE, 200, 273, 882, 433, "snapshot99", "last");

	ctrx_mouse_click(857, 207, 1, 0, "Save=snapshot100", "last");

	ctrx_sync_on_window("Select Export File Types", ACTIVATE, 508, 391, 265, 201, "snapshot101", "last");

	ctrx_mouse_click(20, 81, 1, 0, "Select Export File Types=snapshot102", "last");

	ctrx_mouse_click(22, 51, 1, 0, "Select Export File Types=snapshot103", "last");

	ctrx_mouse_click(78, 177, 1, 0, "Select Export File Types=snapshot104", "last");

	ctrx_sync_on_window("Save", ACTIVATE, 200, 273, 882, 433, "snapshot105", "last");

	ctrx_mouse_click(823, 372, 1, 0, "Save=snapshot106", "last");

	lr_think_time(60);

 

	ctrx_mouse_click(400, 113, 1, 0, "Warning=snapshot108", "last");

	lr_end_transaction("CAD_BP3_14_Export_STL",2);

	lr_think_time(15);

	lr_start_transaction("CAD_BP3_15_Home");

	ctrx_sync_on_window("CA Digital - CA Digital_2", ACTIVATE, 0, 0, 1281, 985, "snapshot109", "last");

	ctrx_mouse_click(151, 68, 1, 0, "CA Digital - CA Digital_2=snapshot110", "last");

	lr_end_transaction("CAD_BP3_15_Home",2);

	

	return 0;
}
# 6 "c:\\users\\siva.kota\\documents\\phase2\\cad_treatment_plan_p2_v2\\\\combined_CAD_Treatment_Plan_P2_v2.c" 2

# 1 "vuser_end.c" 1
vuser_end()
{
	
	lr_think_time(15);

	lr_start_transaction("CAD_BP3_16_Close_CAD_App");

	ctrx_sync_on_window("CA Digital - CA Digital2", ACTIVATE, 0, 0, 1275, 611, "snapshot3", "last");

	ctrx_mouse_click(1248, 10, 1, 0, "CA Digital - CA Digital=snapshot4", "last");

	lr_end_transaction("CAD_BP3_16_Close_CAD_App",2);

	lr_start_transaction("CAD_BP3_17_Close_Citrix_Server");

	ctrx_logoff(0, "last");

	lr_end_transaction("CAD_BP3_17_Close_Citrix_Server",2);
	
	lr_think_time(10);

	lr_start_transaction("CAD_02_Logout");

	web_add_cookie("CtxsDesktopAutoLaunchDone=no; DOMAIN=storefront.smileco.com");

	web_add_header("Csrf-Token",
		"{CitrixXenApp_CsrfToken}");

	web_add_auto_header("X-Citrix-IsUsingHTTPS", 
		"Yes");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_custom_request("Disconnect", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Sessions/Disconnect", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		"EncType=", 
		"LAST");

	
	lr_end_transaction("CAD_02_Logout", 2);
	
	
	return 0;
}
# 7 "c:\\users\\siva.kota\\documents\\phase2\\cad_treatment_plan_p2_v2\\\\combined_CAD_Treatment_Plan_P2_v2.c" 2

