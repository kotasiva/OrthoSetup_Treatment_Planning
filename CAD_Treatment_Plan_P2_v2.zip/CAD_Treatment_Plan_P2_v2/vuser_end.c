﻿vuser_end()
{
	
	lr_think_time(15);

	lr_start_transaction("CAD_BP3_16_Close_CAD_App");

	ctrx_sync_on_window("CA Digital - CA Digital2", ACTIVATE, 0, 0, 1275, 611, "snapshot3", CTRX_LAST);

	ctrx_mouse_click(1248, 10, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot4", CTRX_LAST);

	lr_end_transaction("CAD_BP3_16_Close_CAD_App",LR_AUTO);

	lr_start_transaction("CAD_BP3_17_Close_Citrix_Server");

	ctrx_logoff(CTRX_NORMAL_LOGOFF, CTRX_LAST);

	lr_end_transaction("CAD_BP3_17_Close_Citrix_Server",LR_AUTO);
	
	lr_think_time(10);

	lr_start_transaction("CAD_02_Logout");

	web_add_cookie("CtxsDesktopAutoLaunchDone=no; DOMAIN=storefront.smileco.com");

	web_add_header("Csrf-Token",
		"{CitrixXenApp_CsrfToken}");

	web_add_auto_header("X-Citrix-IsUsingHTTPS", 
		"Yes");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_custom_request("Disconnect", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Sessions/Disconnect", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	
	lr_end_transaction("CAD_02_Logout", LR_AUTO);
	
	
	return 0;
}
