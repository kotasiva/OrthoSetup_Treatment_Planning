﻿Action()
{


	
	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Links}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP1_04_Click_Patient" );	

	lr_start_transaction("CAD_BP1_04_Click_Patient");

	ctrx_sync_on_window("CA Digital - CA Digital", ACTIVATE, 0, 0, 1281, 681, "snapshot2", CTRX_LAST);

	ctrx_mouse_click(329, 485, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot2", CTRX_LAST);
	

	lr_end_transaction("CAD_BP1_04_Click_Patient",LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP1_04_Click_Patient" );


		//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Links}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP1_05_Create_Patient" );	
		
	lr_start_transaction("CAD_BP1_05_Create_Patient");
	
	ctrx_mouse_click(890, 558, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot3", CTRX_LAST);

	lr_end_transaction("CAD_BP1_05_Create_Patient",LR_AUTO);
	
		//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP1_05_Create_Patient" );


	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Links}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP1_06_Patient_Details" );	
		
	lr_start_transaction("CAD_BP1_06_Patient_Details");
	
	//New Record
	
	ctrx_mouse_click(1223, 242, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot4", CTRX_LAST);

	ctrx_type("{PatientID}", "", CTRX_LAST);

	ctrx_mouse_click(1126, 272, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot5", CTRX_LAST);

	ctrx_type("CADF{FirstnameRand}", "", CTRX_LAST);

	ctrx_mouse_click(1128, 300, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot7", CTRX_LAST);

	ctrx_type("CADL{FirstnameRand}", "", CTRX_LAST);

//	lr_think_time(6);

	ctrx_mouse_click(1138, 330, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot9", CTRX_LAST);

	ctrx_type("01/07/1992", "", CTRX_LAST);

	ctrx_mouse_click(1135, 358, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot12", CTRX_LAST);

	ctrx_type("{FirstnameRand}", "", CTRX_LAST);

//	lr_think_time(7);

	ctrx_mouse_click(1129, 418, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot13", CTRX_LAST);

	ctrx_type("08/06/2019", "", CTRX_LAST);	
	
	ctrx_mouse_click(1181, 662, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot18", CTRX_LAST);
	
	
//	ctrx_mouse_click(1227, 241, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot5", CTRX_LAST);
//	
//	lr_think_time(10);
//
//	ctrx_mouse_click(1207, 243, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot6", CTRX_LAST);
//
//	ctrx_key("NO_KEY", MODIF_SHIFT, "", CTRX_LAST);
//
//	ctrx_type("C{PatientID}", "", CTRX_LAST);
//
//	ctrx_mouse_click(1328, 277, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot9", CTRX_LAST);
//
//	ctrx_mouse_click(1246, 316, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot10", CTRX_LAST);
//
//	ctrx_mouse_click(1206, 302, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot11", CTRX_LAST);
//
//	ctrx_type("CAD{FirstnameRand}", "", CTRX_LAST);
//
//	ctrx_mouse_click(1208, 331, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot13", CTRX_LAST);
//
//	ctrx_type("CAD", "", CTRX_LAST);
//
//	ctrx_mouse_click(1195, 360, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot15", CTRX_LAST);
//
//	ctrx_type("27.10.1986", "", CTRX_LAST);
//
//		//Mrn Number
//	
//	ctrx_mouse_click(1190, 499, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot12", CTRX_LAST);
//
//	ctrx_type("1992211115201", "", CTRX_LAST);
//	
//
//	ctrx_mouse_click(1264, 653, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot18", CTRX_LAST);

	lr_end_transaction("CAD_BP1_06_Patient_Details",LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP1_06_Patient_Details" );




	return 0;
}