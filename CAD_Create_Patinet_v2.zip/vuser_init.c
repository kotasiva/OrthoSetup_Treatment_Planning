﻿#define TRUE 1
#define FALSE 0

#include "as_web.h"

	typedef long time_t;

//	Explicit Declaration of STRTOK Function
	extern char *strtok(char *, const char * );

	int TrackUserCycleTime = FALSE;
	int Debug = FALSE;
	int LoginOnly = FALSE;
    int AbortIteration = FALSE;
	int SkipToLogout = FALSE;
	int CalculateNetworkThroughputFlag = TRUE;
	int CommonTransactionMeasuredEnabled = TRUE;
	int Iteration = 0;
	double Initial_Byte_Request_Count;
	double Initial_Byte_Response_Count;
	double After_Submit_Request_Count;
	double After_Submit_Response_Count;
	double Before_Submit_Request_Count;
	double Before_Submit_Response_Count;
    char *TransactionType = "Simple";
	long file;


/***********************************************************************************
*
* Author:  Siva Kota
* Date:    November 2017
*
* Function Purpose:	
*	This Function will calculate throughput for each transaction / HTTP request
*
* Before Executing Script:  None
*	
*
************************************************************************************/
void CalcRequestResponseNetworkThroughput( int Function, char * DataPointName )
{
	char Str[100];

	if (Debug)
	{
		lr_output_message("Function Value: %d", Function);
		lr_output_message("Datapoint Name: %s", DataPointName);
	}

	switch(Function)
	{

//	Initialize Request & Response Values At Beginning Of Scenario
//	This Function is requested once at the beginning of login
	case 0:

		Initial_Byte_Request_Count = web_get_int_property(HTTP_INFO_TOTAL_REQUEST_STAT); 
		Initial_Byte_Response_Count = web_get_int_property(HTTP_INFO_TOTAL_RESPONSE_STAT); 
		lr_user_data_point("InitByteReqSize", Initial_Byte_Request_Count);
		lr_user_data_point("InitByteRespSize", Initial_Byte_Response_Count);
		if (Debug)
		{
			lr_output_message("Initial Byte Request: %f", Initial_Byte_Request_Count);
			lr_output_message("Initial Byte Response: %f", Initial_Byte_Response_Count);
		}

	break;

//	Capture Before Request / Response Values
	case 1:
		Before_Submit_Request_Count = web_get_int_property(HTTP_INFO_TOTAL_REQUEST_STAT); 
		Before_Submit_Response_Count = web_get_int_property(HTTP_INFO_TOTAL_RESPONSE_STAT); 
		if (Debug)
		{
			lr_output_message("Before Byte Request: %f", Before_Submit_Request_Count);
			lr_output_message("Before Byte Response: %f", Before_Submit_Response_Count);
		}
		if (CommonTransactionMeasuredEnabled)
			if(strcmp(TransactionType, "Simple") == 0)
				lr_start_transaction("CAD SLA KPI Transaction");
			else if(strcmp(TransactionType, "Complex") == 0 )
				lr_start_transaction("CAD SLA KPI Complex Transaction");
			else 
			{
				lr_error_message("Transaction Type Variable Not Set"); 
			}

		break;
	break;

//	Capture After Request / Response Values
	case 2:
		After_Submit_Request_Count = web_get_int_property(HTTP_INFO_TOTAL_REQUEST_STAT); 
		After_Submit_Response_Count = web_get_int_property(HTTP_INFO_TOTAL_RESPONSE_STAT); 
		sprintf(Str, "Request-%s", DataPointName);
		lr_save_string(Str, "RequestDatapoint"); 
		sprintf(Str, "Response-%s", DataPointName);
		lr_save_string(Str, "ResponseDatapoint"); 
		lr_user_data_point(lr_eval_string("{RequestDatapoint}"), After_Submit_Request_Count - Before_Submit_Request_Count);
		lr_user_data_point(lr_eval_string("{ResponseDatapoint}"), After_Submit_Response_Count - Before_Submit_Response_Count);
		if (Debug)
		{
			lr_output_message("Before Byte Request: %f", Before_Submit_Request_Count);
			lr_output_message("Before Byte Response: %f",Before_Submit_Response_Count);
			lr_output_message("After Byte Request: %f", After_Submit_Request_Count);
			lr_output_message("After Byte Response: %f", After_Submit_Response_Count);
			lr_output_message("Net Byte Request (After Minus Before): %f", After_Submit_Request_Count - Before_Submit_Request_Count);
			lr_output_message("Net Byte Response (After Minus Before): %f", After_Submit_Response_Count -Before_Submit_Response_Count);
		}
		if(strcmp(TransactionType, "Simple") == 0)
		{
			lr_end_transaction("CAD SLA KPI Transaction", LR_AUTO);
//  Reset Transaction Type to Simple
			TransactionType = "Simple";
		}
		else if(strcmp(TransactionType, "Complex") == 0)
		{
			lr_end_transaction("CAD SLA KPI Complex Transaction", LR_AUTO);
//  Reset Transaction Type to Simple
			TransactionType = "Simple";
		}
		else
		{
			lr_error_message("Transaction Type Variable Not Set"); 
		}
		break;

//	Capture Final Request / Response Values
//	This function call should be last statement after logout

	case 3:
		After_Submit_Request_Count = web_get_int_property(HTTP_INFO_TOTAL_REQUEST_STAT); 
		After_Submit_Response_Count = web_get_int_property(HTTP_INFO_TOTAL_RESPONSE_STAT); 
		sprintf(Str, "Request-%s", DataPointName);
		lr_save_string(Str, "RequestDatapoint"); 
		sprintf(Str, "Response-%s", DataPointName);
		lr_save_string(Str, "ResponseDatapoint"); 
		lr_user_data_point(lr_eval_string("{RequestDatapoint}"), After_Submit_Request_Count - Initial_Byte_Request_Count);
		lr_user_data_point(lr_eval_string("{ResponseDatapoint}"), After_Submit_Response_Count - Initial_Byte_Response_Count);
		if (Debug)
		{
			lr_output_message("Final (Total) Bytes Request: %f", After_Submit_Request_Count - Initial_Byte_Request_Count);
			lr_output_message("Final (Total) Byte Response: %f", After_Submit_Response_Count - Initial_Byte_Response_Count);
		}

	break;

//	Default
	default:
		lr_error_message("Invalid function code provided for network throughput");
	break;

	}	//End Switch

}
/***********************************************************************************
*
* Author:  Siva Kota
* Date:    November 2017
*
* Function Purpose: Establish Global Thinktime Values
*
* Before Executing Script:  None
*
************************************************************************************/
void SetThinkValues( void )
{
	lr_save_string("10", "Think_Portal");
	lr_save_string("20", "Think_Login");
	lr_save_string("10", "Think_Logout");
	lr_save_string("10", "Think_MouseClicks");
	lr_save_string("25", "Think_Links");
	lr_save_string("60", "Think_Submit");
	lr_save_string("60", "Think_Upload");

}

/***********************************************************************************
*
* Author:  Siva Kota
* Date:    November 2017
*
* Function Purpose: Establish Global Error Checks
*
* Before Executing Script:  None
*
************************************************************************************/
void SetGlobalChecks( void )
{

	web_global_verification("Text/IC=Internal Database Error", "Fail=Found", "ID=Database Error", LAST);
	   web_global_verification("Text/IC=SAMLGateway Inbound Error", "Fail=Found", "ID=Gateway Inbound Error", LAST);
	   web_global_verification("Text/IC=Gateway Timeout", "Fail=Found", "ID=Gateway Timeout Error", LAST);
	   web_global_verification("Text=Internal System Error", "Fail=Found", "ID=System Error", LAST);
	   web_global_verification("Text=You have logged off, or you have left your session idle for more than 10 minutes, causing an automatic log off.", "Fail=Found", "ID=Session Timeout", LAST);
	   web_global_verification("Text=Error 500--Internal Server Error", "Fail=Found", "ID=500 Status Error", LAST);
	   web_global_verification("Text/IC=There was a problem with your request" "Fail=Found", "ID=Submit Error 1", LAST);
	   web_global_verification("TextPfx/IC=Please call the Employee Service Center", "TextSfx/IC=to complete this change", "Fail=Found", "ID=Submit Error 2", LAST);
	   web_global_verification("Text/IC=java.io.IOException", "Fail=Found", "ID=IO Error 1", LAST);
	   web_global_verification("Text/IC=please contact your System Administrator", "Fail=Found", "ID=Contact Sys Admin Error 1", LAST);
	   web_global_verification("Text/IC=>The following errors have occurred:<", "Fail=Found", "ID=Input Errors 1", LAST);
	   web_global_verification("Text/IC=The service is temporarily unavailable. Please try again later", "Fail=Found", "ID=Error - Service Unavailable 1", LAST);
	   web_global_verification("Text/IC=<p>You are not authorized to see this page.</p>", "Fail=Found", "ID=Error - Page No Access 1", LAST);
	   web_global_verification("Text/IC=<p>$EX.DEFAULT.100001$</p>", "Fail=Found", "ID=Error - Page Not Found 2", LAST);
	   web_global_verification("Text/IC=<!-- error.ftl ends here -->", "Fail=Found", "ID=Error - General Header 1", LAST);
	   web_global_verification("Text/IC=Error while rendering", "Fail=Found", "ID=Error - Error while rendering 1", LAST);
	   web_global_verification("Text/IC=html' is not found!!!", "Fail=Found", "ID=Error - HTML Not Found", LAST);
	   web_global_verification("Text/IC=your search request could not be processed.", "Fail=Found", "ID=Error - Search Failed 1", LAST);
	   web_global_verification("Text/IC=Found 0 results.", "Fail=Found", "ID=Error - Search Failed 2", LAST);
	   web_global_verification("Text/IC=You are required to change your Password before continuing", "Fail=Found", "ID=Error - Password Change", LAST);
	   web_global_verification("Text/IC=This page is no longer available.</td>", "Fail=Found", "ID=Session Error 2", LAST); 
	   web_global_verification("Text/IC=You have reached this page in error.<br/>", "Fail=Found", "ID=Error - Reached Page In Error 1", LAST);
	   web_global_verification("Text/IC=For OMD time-reporting employees", "Fail=Found", "ID=Error - Test Data Type", LAST);
	   web_global_verification("Text/IC=Invalid data", "Fail=Found", "ID=Error - Test Data", LAST);
	   web_global_verification("Text/IC=An error has occurred that has stopped this transaction from continuing", "Fail=Found", "ID=Error - Transaction Stopped", LAST);
	   web_global_verification("Text/IC=Failed to decrypt domain name in URL", "Fail=Found", "ID=Error - Decrypt Domain in URL", LAST);
	   web_global_verification("Text/IC=>Data Integrity Error (", "Fail=Found", "ID=Error - Data Integrity Error", LAST);
	   web_global_verification("Text/IC=<br />When trying to save your changes, the system found a conflict with other information in the database", "Fail=Found", "ID=Error - Save Error", LAST);
	   web_global_verification("Text/IC=>If the problem persists, it may be due to an application programming error and should be reported to technical support staff. <", "Fail=Found", "ID=Error - technical", LAST);

}
vuser_init()
{

	SetGlobalChecks();

	SetThinkValues();
	
	return 0;
}
