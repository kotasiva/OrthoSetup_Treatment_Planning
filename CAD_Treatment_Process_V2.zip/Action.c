﻿Action()
{

	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Links}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP3_04_Click_Patient" );	

	lr_start_transaction("CAD_BP3_04_Click_Patient");

	ctrx_sync_on_window("CA Digital - CA Digital", ACTIVATE, -4, -4, 1369, 663, "snapshot2", CTRX_LAST);

	ctrx_mouse_click(375, 484, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot3", CTRX_LAST);

	lr_end_transaction("CAD_BP3_04_Click_Patient",LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP3_04_Click_Patient" );


		//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Links}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP3_05_Create_Patient" );	
		
	lr_start_transaction("CAD_BP3_05_Create_Patient");

	ctrx_mouse_click(941, 547, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot4", CTRX_LAST);

	lr_end_transaction("CAD_BP3_05_Create_Patient",LR_AUTO);
	
		//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP3_05_Create_Patient" );


	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Load}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP3_06_Patient_Details" );	
		
	lr_start_transaction("CAD_BP3_06_Patient_Details");
	
	ctrx_mouse_click(1227, 241, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot5", CTRX_LAST);

	ctrx_mouse_click(1207, 243, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot6", CTRX_LAST);

	ctrx_key("NO_KEY", MODIF_SHIFT, "", CTRX_LAST);

	ctrx_type("C{PatientID}", CTRX_LAST);

	ctrx_mouse_click(1328, 277, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot9", CTRX_LAST);

	ctrx_mouse_click(1246, 316, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot10", CTRX_LAST);

	ctrx_mouse_click(1206, 302, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot11", CTRX_LAST);

	ctrx_type("CAD{FirstnameRand}", CTRX_LAST);
	
	lr_think_time(3);

	ctrx_mouse_click(1208, 331, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot13", CTRX_LAST);

	ctrx_type("CAD{PatientID}", CTRX_LAST);
	
	lr_think_time(3);

	ctrx_mouse_click(1195, 360, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot15", CTRX_LAST);

	ctrx_type("27.10.1986", CTRX_LAST);
	
	//Mrn Number
	
	ctrx_mouse_click(1190, 499, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot12", CTRX_LAST);

	ctrx_type("1992211115201", "", CTRX_LAST);
	

	ctrx_mouse_click(1264, 653, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot18", CTRX_LAST);
	
	lr_end_transaction("CAD_BP3_06_Patient_Details",LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP3_06_Patient_Details" );

	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Links}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP3_07_Import_STLFiles" );	
		
	lr_start_transaction("CAD_BP3_07_Import_STLFiles");

	ctrx_mouse_click(211, 61, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot19", CTRX_LAST);

	lr_end_transaction("CAD_BP3_07_Import_STLFiles",LR_AUTO);
	
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP3_07_Import_STLFiles" );


	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Load}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP3_08_LoadSTLFiles" );

	lr_start_transaction("CAD_BP3_08_LoadSTLFiles");
	
	//New Record
	
	ctrx_sync_on_window("Load document...", ACTIVATE, 457, 204, 447, 318, "snapshot218", CTRX_LAST);

	ctrx_mouse_click(428, 176, LEFT_BUTTON, 0, "Load document...=snapshot219", CTRX_LAST);

	ctrx_sync_on_window("Open", ACTIVATE, 260, 144, 841, 433, "snapshot220", CTRX_LAST);

	ctrx_mouse_click(343, 100, LEFT_BUTTON, 0, "Open=snapshot221", CTRX_LAST);

	ctrx_mouse_click(780, 378, LEFT_BUTTON, 0, "Open=snapshot222", CTRX_LAST);

	ctrx_sync_on_window("Load document...", ACTIVATE, 457, 204, 447, 318, "snapshot223", CTRX_LAST);

	ctrx_mouse_click(426, 214, LEFT_BUTTON, 0, "Load document...=snapshot224", CTRX_LAST);
	
	lr_think_time(10);

	ctrx_sync_on_window("Open", ACTIVATE, 260, 144, 841, 433, "snapshot225", CTRX_LAST);

	ctrx_mouse_click(332, 79, LEFT_BUTTON, 0, "Open=snapshot226", CTRX_LAST);

	ctrx_mouse_click(781, 371, LEFT_BUTTON, 0, "Open=snapshot227", CTRX_LAST);
	
	lr_think_time(10);

	ctrx_sync_on_window("Load document...", ACTIVATE, 457, 204, 447, 318, "snapshot228", CTRX_LAST);

	ctrx_mouse_click(228, 293, LEFT_BUTTON, 0, "Load document...=snapshot229", CTRX_LAST);
	
	
    //Old Record
    
//	ctrx_sync_on_window("Load document...", ACTIVATE, 455, 175, 451, 305, "snapshot20", CTRX_LAST);
//
//	ctrx_mouse_click(431, 164, LEFT_BUTTON, 0, "Load document...=snapshot21", CTRX_LAST);
//
//	ctrx_sync_on_window("Open", ACTIVATE, 255, 124, 851, 408, "snapshot22", CTRX_LAST);
//
//	ctrx_mouse_click(353, 91, LEFT_BUTTON, 0, "Open=snapshot23", CTRX_LAST);
//
//	ctrx_mouse_click(792, 346, LEFT_BUTTON, 0, "Open=snapshot24", CTRX_LAST);
//
//	ctrx_sync_on_window("Load document...", ACTIVATE, 455, 175, 451, 305, "snapshot25", CTRX_LAST);
//
//	ctrx_mouse_click(425, 203, LEFT_BUTTON, 0, "Load document...=snapshot26", CTRX_LAST);
//
//	ctrx_sync_on_window("Open", ACTIVATE, 255, 124, 851, 408, "snapshot27", CTRX_LAST);
//
//	ctrx_mouse_click(327, 71, LEFT_BUTTON, 0, "Open=snapshot28", CTRX_LAST);
//
//	ctrx_mouse_click(797, 345, LEFT_BUTTON, 0, "Open=snapshot29", CTRX_LAST);
//
//	ctrx_sync_on_window("Load document...", ACTIVATE, 455, 175, 451, 305, "snapshot30", CTRX_LAST);
//
//	ctrx_mouse_click(230, 275, LEFT_BUTTON, 0, "Load document...=snapshot31", CTRX_LAST);

	
	lr_end_transaction("CAD_BP3_08_LoadSTLFiles",LR_AUTO);
	
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP3_08_LoadSTLFiles" );

	
	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Links}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP3_09_Open_Impressions" );	
		
	lr_start_transaction("CAD_BP3_09_Open_Impressions");

	ctrx_sync_on_window("CA Digital - CA Digital", ACTIVATE, -4, -4, 1369, 663, "snapshot32", CTRX_LAST);
	
	lr_think_time(30);

	ctrx_mouse_double_click(267, 257, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot33", CTRX_LAST);

	lr_end_transaction("CAD_BP3_09_Open_Impressions",LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP3_09_Open_Impressions" );
	
	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Links}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP3_10_Step_1" );	
		
	lr_start_transaction("CAD_BP3_10_Step_1");
//
//	//New Record
	
	ctrx_sync_on_window("CA Digital - CA Digital_2", ACTIVATE, 0, 0, 1361, 729, "snapshot34", CTRX_LAST);
	
	ctrx_mouse_click(566, 185, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot35", CTRX_LAST);

	ctrx_mouse_click(566, 185, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot36", CTRX_LAST);
	
	//Old Record
//	
//	ctrx_sync_on_window("CA Digital - CA Digital_2", ACTIVATE, -4, -4, 1369, 663, "snapshot34", CTRX_LAST);
//
//	ctrx_mouse_click(568, 185, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot35", CTRX_LAST);
//
//	ctrx_mouse_click(568, 185, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot36", CTRX_LAST);

	lr_end_transaction("CAD_BP3_10_Step_1",LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP3_10_Step_1" );
	
	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Submit}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP3_11_Step_2" );	
		
	lr_start_transaction("CAD_BP3_11_Step_2");

	ctrx_mouse_click(127, 131, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot37", CTRX_LAST);

	lr_think_time(10);

	ctrx_mouse_click(887, 354, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot38", CTRX_LAST);

	lr_think_time(10);

	ctrx_mouse_click(256, 365, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot39", CTRX_LAST);

	lr_think_time(10);

	ctrx_mouse_click(260, 326, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot40", CTRX_LAST);
	
	lr_think_time(10);
	
	ctrx_mouse_click(265, 301, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot41", CTRX_LAST);
	
	lr_think_time(10);

	ctrx_mouse_click(270, 279, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot42", CTRX_LAST);
	
	lr_think_time(10);

	ctrx_mouse_click(277, 255, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot43", CTRX_LAST);
	
	lr_think_time(10);

	ctrx_mouse_click(291, 239, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot44", CTRX_LAST);
	
	lr_think_time(10);

	ctrx_mouse_click(315, 230, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot45", CTRX_LAST);
	
	lr_think_time(10);

	ctrx_mouse_click(342, 226, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot46", CTRX_LAST);
	
	lr_think_time(10);

	ctrx_mouse_click(366, 228, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot47", CTRX_LAST);
	
	lr_think_time(10);

	ctrx_mouse_click(385, 250, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot48", CTRX_LAST);
	
	lr_think_time(10);

	ctrx_mouse_click(399, 270, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot49", CTRX_LAST);
	
	lr_think_time(10);

	ctrx_mouse_click(408, 291, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot50", CTRX_LAST);
	
	lr_think_time(10);

	ctrx_mouse_click(417, 315, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot51", CTRX_LAST);
	
	lr_think_time(10);

	ctrx_mouse_click(428, 347, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot52", CTRX_LAST);

	lr_think_time(15);

	ctrx_mouse_click(405, 500, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot53", CTRX_LAST);

	lr_think_time(15);

	ctrx_mouse_click(1027, 470, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot54", CTRX_LAST);
	
	lr_think_time(10);

	ctrx_mouse_click(407, 503, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot55", CTRX_LAST);

	lr_think_time(10);

	ctrx_mouse_click(396, 530, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot56", CTRX_LAST);
	
	lr_think_time(10);

	ctrx_mouse_click(386, 552, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot57", CTRX_LAST);
	
	lr_think_time(10);

	ctrx_mouse_click(372, 569, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot58", CTRX_LAST);
	
	lr_think_time(10);

	ctrx_mouse_click(352, 579, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot59", CTRX_LAST);
	
	lr_think_time(10);

	ctrx_mouse_click(336, 579, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot60", CTRX_LAST);
	
	lr_think_time(10);

	ctrx_mouse_click(316, 584, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot61", CTRX_LAST);
	
	lr_think_time(10);

	ctrx_mouse_click(301, 573, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot62", CTRX_LAST);
	
	lr_think_time(10);

	ctrx_mouse_click(286, 559, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot63", CTRX_LAST);
	
	lr_think_time(10);

	ctrx_mouse_click(277, 538, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot64", CTRX_LAST);
	
	lr_think_time(10);

	ctrx_mouse_click(274, 517, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot65", CTRX_LAST);
	
	lr_think_time(10);

	ctrx_mouse_click(275, 486, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot66", CTRX_LAST);
	
	lr_think_time(10);

	ctrx_mouse_click(265, 453, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot67", CTRX_LAST);

	lr_end_transaction("CAD_BP3_11_Step_2",LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP3_11_Step_2" );
	
	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Submit}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP3_12_Step_3" );	
		
	lr_start_transaction("CAD_BP3_12_Step_3");

	ctrx_mouse_click(177, 137, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot68", CTRX_LAST);

	ctrx_type(" ", "", CTRX_LAST);

	lr_think_time(10);

	ctrx_mouse_down(633, 296, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot70", CTRX_LAST);

	ctrx_mouse_up(629, 302, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot71", CTRX_LAST);

	ctrx_mouse_down(801, 354, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot72", CTRX_LAST);

	ctrx_mouse_up(796, 349, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot73", CTRX_LAST);

	lr_end_transaction("CAD_BP3_12_Step_3",LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP3_12_Step_3" );
	
	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Submit}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP3_13_Step_4" );	
		
	lr_start_transaction("CAD_BP3_13_Step_4");

	ctrx_mouse_click(226, 130, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot74", CTRX_LAST);

	lr_end_transaction("CAD_BP3_13_Step_4",LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP3_13_Step_4" );
	
	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Submit}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP3_14_Step_5" );	
	
	lr_start_transaction("CAD_BP3_14_Step_5");

	ctrx_mouse_click(282, 131, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot75", CTRX_LAST);

	ctrx_type(" ", "", CTRX_LAST);

	ctrx_mouse_down(473, 496, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot77", CTRX_LAST);

	lr_think_time(15);

	ctrx_mouse_up(454, 485, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot78", CTRX_LAST);

	ctrx_mouse_down(882, 482, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot79", CTRX_LAST);

	ctrx_mouse_up(904, 479, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot80", CTRX_LAST);

	ctrx_mouse_click(249, 315, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot81", CTRX_LAST);

	ctrx_mouse_down(474, 490, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot82", CTRX_LAST);

	ctrx_mouse_up(464, 494, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot83", CTRX_LAST);

	ctrx_mouse_down(880, 485, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot84", CTRX_LAST);

	ctrx_mouse_up(893, 486, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot85", CTRX_LAST);

	lr_end_transaction("CAD_BP3_14_Step_5",LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP3_14_Step_5" );
	
	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Submit}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP3_15_Step_6" );	
		
	lr_start_transaction("CAD_BP3_15_Step_6");

	ctrx_mouse_click(333, 134, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot86", CTRX_LAST);

	ctrx_type(" ", "", CTRX_LAST);

	ctrx_mouse_down(519, 490, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot88", CTRX_LAST);

	ctrx_mouse_up(526, 487, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot89", CTRX_LAST);

	ctrx_mouse_click(444, 278, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot90", CTRX_LAST);

	ctrx_mouse_down(516, 470, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot91", CTRX_LAST);

	ctrx_mouse_up(525, 468, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot92", CTRX_LAST);

	ctrx_mouse_click(440, 334, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot93", CTRX_LAST);

	lr_end_transaction("CAD_BP3_15_Step_6",LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP3_15_Step_6" );
	
	
	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Submit}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP3_16_Step_7" );	
		
	lr_start_transaction("CAD_BP3_16_Step_7");

	ctrx_mouse_click(394, 131, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot94", CTRX_LAST);

	lr_end_transaction("CAD_BP3_16_Step_7",LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP3_16_Step_7" );
	
	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Submit}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP3_17_Step_8" );	
		
	lr_start_transaction("CAD_BP3_17_Step_8");

	ctrx_mouse_click(453, 133, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot95", CTRX_LAST);

	lr_end_transaction("CAD_BP3_17_Step_8",LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP3_17_Step_8" );
	
	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_savePDF}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP3_18_Create_PDF" );	
		
	lr_start_transaction("CAD_BP3_18_Create_PDF");

	ctrx_mouse_click(1167, 233, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot96", CTRX_LAST);

	ctrx_sync_on_window("Save", ACTIVATE, 255, 124, 851, 408, "snapshot97", CTRX_LAST);

	ctrx_type("Treatment_", "", CTRX_LAST);

	ctrx_type("Plan{PatientID}", "", CTRX_LAST);

	lr_think_time(25);

	ctrx_mouse_click(796, 345, LEFT_BUTTON, 0, "Save=snapshot102", CTRX_LAST);

	lr_end_transaction("CAD_BP3_18_Create_PDF",LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP3_18_Create_PDF" );
	
	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Links}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP3_19_Home" );	
		
	lr_start_transaction("CAD_BP3_19_Home");

	ctrx_sync_on_window("CA Digital - CA Digital_2", ACTIVATE, -4, -4, 1369, 663, "snapshot103", CTRX_LAST);

	ctrx_mouse_click(142, 66, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot104", CTRX_LAST);

	lr_end_transaction("CAD_BP3_19_Home",LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP3_19_Home" );
	
	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_MouseClicks}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP3_20_Close_CA_App" );	
		
	lr_start_transaction("CAD_BP3_20_Close_CA_App");

	ctrx_sync_on_window("CA Digital - CA Digital_2", ACTIVATE, -4, -4, 1369, 663, "snapshot105", CTRX_LAST);

	ctrx_mouse_click(1351, 10, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot106", CTRX_LAST);
		
//	ctrx_sync_on_window("CA Digital - CA Digital", ACTIVATE, 0, 0, 1275, 611, "snapshot105", CTRX_LAST);
//
//	ctrx_mouse_click(1248, 10, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot106", CTRX_LAST);

	lr_end_transaction("CAD_BP3_20_Close_CA_App",LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP3_20_Close_CA_App" );
	
	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_MouseClicks}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP3_21_Close_Citrix_Server" );	
		
	lr_start_transaction("CAD_BP3_21_Close_Citrix_Server");

	ctrx_logoff(CTRX_NORMAL_LOGOFF, CTRX_LAST);

	lr_end_transaction("CAD_BP3_21_Close_Citrix_Server",LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP3_21_Close_Citrix_Server" );
	
	return 0;
}