﻿vuser_end()
{


	
	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_MouseClicks}")));

//	Initialize Throughput Calculations
//	Declare Transaction
	TransactionType = "Simple";

	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1, "CAD_02_Logout");

	
	lr_start_transaction("CAD_02_Logout");

	web_add_cookie("CtxsDesktopAutoLaunchDone=no; DOMAIN=storefront.smileco.com");

	web_custom_request("Disconnect", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Sessions/Disconnect", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t42.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_02_Logout");
    if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 3, "CAD_BP3_Treatment_Plan_Process_Total");

	lr_end_transaction("CAD_02_Logout", LR_AUTO);
	
	return 0;
}
