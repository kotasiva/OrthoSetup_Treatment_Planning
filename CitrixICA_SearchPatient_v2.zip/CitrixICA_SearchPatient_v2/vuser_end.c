﻿vuser_end()
{

		//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Links}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP2_09_Close_CA_App" );	
		
	lr_start_transaction("CAD_BP2_09_Close_CA_App");

//	ctrx_sync_on_window("CA Digital - CA Digital_2", ACTIVATE, -4, -4, 1369, 663, "snapshot105", CTRX_LAST);
//
//	ctrx_mouse_click(1351, 10, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot106", CTRX_LAST);
//		


	ctrx_sync_on_window("CA Digital - CA Digital", ACTIVATE, 0, 0, 1275, 611, "snapshot105", CTRX_LAST);

	ctrx_mouse_click(1248, 10, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot106", CTRX_LAST);

	lr_end_transaction("CAD_BP2_09_Close_CA_App",LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP2_09_Close_CA_App" );
	
	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Links}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP2_10_Close_Citrix_Server" );	
		
	lr_start_transaction("CAD_BP2_10_Close_Citrix_Server");

	ctrx_logoff(CTRX_NORMAL_LOGOFF, CTRX_LAST);

	lr_end_transaction("CAD_BP2_10_Close_Citrix_Server",LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP2_10_Close_Citrix_Server" );

//	Initialize Throughput Calculations
//	Declare Transaction
	TransactionType = "Simple";

	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1, "CAD_02_Logout");

	
	lr_start_transaction("CAD_02_Logout");

	web_add_cookie("CtxsDesktopAutoLaunchDone=no; DOMAIN=storefront.smileco.com");

	web_custom_request("Disconnect", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Sessions/Disconnect", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t42.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_02_Logout");
    if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 3, "CAD_BP2_SearchPatient_Total");

	lr_end_transaction("CAD_02_Logout", LR_AUTO);

	return 0;
}