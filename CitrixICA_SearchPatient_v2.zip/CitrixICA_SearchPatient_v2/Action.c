﻿Action()
{

	
	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Links}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP2_04_Click_Patient" );	

	lr_start_transaction("CAD_BP2_04_Click_Patient");


	ctrx_sync_on_window("CA Digital - CA Digital", ACTIVATE, -4, -4, 1369, 663, "snapshot2", CTRX_LAST);

	ctrx_mouse_click(375, 484, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot3", CTRX_LAST);

	lr_end_transaction("CAD_BP2_04_Click_Patient",LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP2_04_Click_Patient" );

	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Links}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP2_05_Search_LastName" );	

	lr_start_transaction("CAD_BP2_05_Search_LastName");

	ctrx_mouse_click(665, 262, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot4", CTRX_LAST);

	ctrx_type("CAL895199518", "", CTRX_LAST);

	ctrx_mouse_click(913, 267, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot5", CTRX_LAST);

	lr_end_transaction("CAD_BP2_05_Search_LastName",LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP2_05_Search_LastName" );

		//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Links}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP2_06_Home" );	

	lr_start_transaction("CAD_BP2_06_Home");

	ctrx_mouse_click(148, 67, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot6", CTRX_LAST);

	lr_end_transaction("CAD_BP2_06_Home",LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP2_06_Home" );

		//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Links}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP2_07_Click_Patient" );	

	lr_start_transaction("CAD_BP2_07_Click_Patient");

	ctrx_mouse_click(381, 472, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot7", CTRX_LAST);
	
	lr_end_transaction("CAD_BP2_07_Click_Patient", LR_AUTO);


	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP2_07_Click_Patient" );

		//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Links}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
	
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP2_08_Search_FirstName" );	

	lr_start_transaction("CAD_BP2_08_Search_FirstName");

	ctrx_mouse_click(819, 270, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot8", CTRX_LAST);

	ctrx_mouse_click(808, 292, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot9", CTRX_LAST);

	ctrx_mouse_click(433, 271, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot10", CTRX_LAST);

	ctrx_type("CAF895199518", "", CTRX_LAST);

	ctrx_mouse_click(904, 270, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot11", CTRX_LAST);

	lr_end_transaction("CAD_BP2_08_Search_FirstName",LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP2_08_Search_FirstName" );
	
	
	
			//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Links}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP2_09_Home" );	

	lr_start_transaction("CAD_BP2_09_Home");

	ctrx_mouse_click(148, 67, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot6", CTRX_LAST);

	lr_end_transaction("CAD_BP2_09_Home",LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP2_09_Home" );

		//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Links}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP2_10_Click_Patient" );	

	lr_start_transaction("CAD_BP2_10_Click_Patient");

	ctrx_mouse_click(381, 472, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot7", CTRX_LAST);
	
	lr_end_transaction("CAD_BP2_10_Click_Patient", LR_AUTO);


	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP2_10_Click_Patient" );
	
	
	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Links}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
	
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP2_11_Search_PatientID" );	
	
	lr_start_transaction("CAD_BP2_11_Search_PatientID");

    ctrx_mouse_double_click(404, 314, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot60", CTRX_LAST);

    ctrx_type("CAD895199518", "", CTRX_LAST);

    ctrx_mouse_click(799, 314, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot61", CTRX_LAST);

    lr_end_transaction("CAD_BP2_11_Search_PatientID",LR_AUTO);
    
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP2_11_Search_PatientID" );
	
	
	
	

	return 0;
}
