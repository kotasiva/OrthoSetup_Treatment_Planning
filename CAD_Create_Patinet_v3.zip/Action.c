﻿Action()
{

	web_set_sockets_option("SSL_VERSION", "2&3");


	web_url("SmileDirectClubWeb", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=custom/style.css", ENDITEM, 
		"Url=receiver/js/external/hammer.v2.0.8.min_F699A1E56189259A.js", ENDITEM, 
		"Url=receiver/images/1x/CitrixReceiver_WebScreen_CBE548FB8FEE049E.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/js/external/jquery.dotdotdot.min_08EE54CBA886AD0A.js", ENDITEM, 
		"Url=receiver/js/external/velocity.min_B218502A82F66680.js", ENDITEM, 
		"Url=receiver/js/external/slick.min_FEB62CC230E2BA2A.js", ENDITEM, 
		"Url=receiver/js/ctxs.core.min_33B1CC992A07D57E.js", ENDITEM, 
		"Url=receiver/js/ctxs.webui.min_895B3076E3BA6027.js", ENDITEM, 
		"Url=receiver/images/1x/folder_template_C13BB96DEBC9F30F.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/images/common/ReceiverFullScreenBackground_46E559C0E6B5A27B.jpg", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=custom/script.js", ENDITEM, 
		"Url=custom/strings.en.js", ENDITEM, 
		"Url=receiver/images/1x/actionSprite_531B7A6FF85CA98E.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/images/1x/viewSprite_B2F322BDCB824FAF.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/images/common/authspinner_B0BCD339560CA593.gif", ENDITEM, 
		"Url=receiver/images/common/icon_loading_9A0623127A028FEB.png", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL2NqTTJXVmxLZW1OTFNISnJWREJMZG5GbGRWbGxTVGNyTVRFMFBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL1duZHhaRlZXV0VWTWRuYzNPRGw2VEhWUUsyRkNTSE5WYVhoclBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL1UxZFNOblpTYkhaRmVUbEJNRzAzTjB3MWNHRkRLMUIyYm1zNFBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL00zZE9NVWROUmtWMFQwZDBhME5yWVRJM2NsaDBia04yUTFkU1QxbFNkVGhXU1ZWQlRXWlNWbFJpZHowLS9pbWFnZQ--?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL2NFTm9NM1JKUnpObVZFTnpORXhRTUUxT2EyY3lVa3N5TXl0alBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL2JHRnhlRmhYYmtwdmJqbFVWV3hwVlZaV1EyOXBlbmxITTI5QlBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		LAST);

	web_add_auto_header("X-Citrix-IsUsingHTTPS", 
		"Yes");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

/*Correlation comment: Automatic rules - Do not change!  
Original value='DFFFA3689D6B71C82012E60F0CD651CC' 
Name ='CitrixXenApp_CsrfToken' 
Type ='Rule' 
AppName ='Citrix_XenApp' 
RuleName ='CsrfToken'*/
	web_reg_save_param_ex(
		"ParamName=CitrixXenApp_CsrfToken",
		"LB/IC=CsrfToken=",
		"RB/IC=;",
		SEARCH_FILTERS,
		"Scope=Cookies",
		LAST);

	web_custom_request("Configuration", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Home/Configuration", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_add_auto_header("Csrf-Token",
		"{CitrixXenApp_CsrfToken}");

	lr_think_time(4);

	web_custom_request("GetDetectionTicket", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionTicket", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("GetDetectionStatus", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionStatus", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body=ticket=CDT_jomcZ!36Y1ASZQRxP2mQn5os7s6RSyZrruQNGEX7WtimRnEGyMpb!u0p0vT_wcPb", 
		LAST);

	web_custom_request("GetDetectionStatus_2", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionStatus", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body=ticket=CDT_jomcZ!36Y1ASZQRxP2mQn5os7s6RSyZrruQNGEX7WtimRnEGyMpb!u0p0vT_wcPb", 
		LAST);

	web_custom_request("GetDetectionStatus_3", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionStatus", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body=ticket=CDT_jomcZ!36Y1ASZQRxP2mQn5os7s6RSyZrruQNGEX7WtimRnEGyMpb!u0p0vT_wcPb", 
		LAST);

	web_add_cookie("CtxsUserPreferredClient=Native; DOMAIN=storefront.smileco.com");

	web_add_cookie("CtxsClientDetectionDone=true; DOMAIN=storefront.smileco.com");

	web_add_cookie("CtxsHasUpgradeBeenShown=true; DOMAIN=storefront.smileco.com");

	web_submit_data("List", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/List", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=format", "Value=json", ENDITEM, 
		"Name=resourceDetails", "Value=Default", ENDITEM, 
		LAST);

	web_custom_request("GetAuthMethods", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Authentication/GetAuthMethods", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("Login", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ExplicitAuth/Login", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/vnd.citrix.authenticateresponse-1+xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=", 
		EXTRARES, 
		"Url=../receiver/images/1x/CitrixStoreFront_auth_14B96BFF2B0A6FF8.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		LAST);

	web_revert_auto_header("Csrf-Token");

	web_revert_auto_header("X-Citrix-IsUsingHTTPS");

	web_revert_auto_header("X-Requested-With");

	lr_think_time(6);

	web_custom_request("reportDetectionStatus", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClub/clientAssistant/reportDetectionStatus", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"Body=ticket=CDT_jomcZ!36Y1ASZQRxP2mQn5os7s6RSyZrruQNGEX7WtimRnEGyMpb!u0p0vT_wcPb&protocolVersion=1&hdxVersion=14.7.0.13011&hdxIsPassthrough=False&hdxIsPassthroughVariable=False", 
		EXTRARES, 
		"Url=/Citrix/SmileDirectClubWeb/receiver/images/1x/spinner_white_auth_button_53FD5A337A529DA7.gif", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		LAST);

	lr_start_transaction("Login");

	web_add_auto_header("Csrf-Token",
		"{CitrixXenApp_CsrfToken}");

	web_add_auto_header("X-Citrix-IsUsingHTTPS", 
		"Yes");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_submit_data("LoginAttempt", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ExplicitAuth/LoginAttempt", 
		"Method=POST", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=username", "Value={useName}", ENDITEM, 
		"Name=password", "Value={Password}", ENDITEM, 
		"Name=saveCredentials", "Value=false", ENDITEM, 
		"Name=loginBtn", "Value=Log On", ENDITEM, 
		"Name=StateContext", "Value=", ENDITEM, 
		LAST);

	web_add_cookie("CtxsPasswordChangeAllowed=true; DOMAIN=storefront.smileco.com");

	web_submit_data("List_2", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/List", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=format", "Value=json", ENDITEM, 
		"Name=resourceDetails", "Value=Default", ENDITEM, 
		EXTRARES, 
		"Url=../receiver/images/1x/CitrixReceiverLogo_Home_5C24BCEC5A182425.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=../receiver/images/1x/spinner_5CF0D1C8A76AAC8E.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=../receiver/images/1x/ico_search_E84E3D63D821F80D.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=../receiver/images/1x/search_close_BC5A22358E58905F.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		LAST);

	web_custom_request("GetUserName", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Authentication/GetUserName", 
		"Method=POST", 
		"Resource=0", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("AllowSelfServiceAccountManagement", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ExplicitAuth/AllowSelfServiceAccountManagement", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	lr_end_transaction("Login",LR_AUTO);

	lr_think_time(9);

	lr_start_transaction("ICA");

	web_submit_data("{ICA_FILE}", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/GetLaunchStatus/{ICA_FILE}", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=displayNameDesktopTitle", "Value={CITRIX_DESKTOP}", ENDITEM, 
		"Name=createFileFetchTicket", "Value=false", ENDITEM, 
		EXTRARES, 
//		"Url=https://safebrowsing.googleapis.com/v4/threatListUpdates:fetch?$req="
//		"Ch0KDGdvb2dsZWNocm9tZRINNzUuMC4zNzcwLjE0MhopCAUQARobCg0IBRAGGAEiAzAwMTABEIT8BhoCGAsnksYDIgQgASACKAEaKQgBEAEaGwoNCAEQBhgBIgMwMDEwARC0qQYaAhgLGARDLyIEIAEgAigBGikIBxABGhsKDQgHEAYYASIDMDAxMAEQqecFGgIYC_zKWE8iBCABIAIoARonCAEQARoZCg0IARAGGAEiAzAwMTADEBQaAhgLmhN4KiIEIAEgAigDGigIARAIGhoKDQgBEAgYASIDMDAxMAQQ3RcaAhgL1G6oRCIEIAEgAigEGicICRABGhkKDQgJEAYYASIDMDAxMAYQAhoCGAsFHOT7IgQgASACKAYaJwgPEAEaGQoNCA8QBhgBIgMwMDEwARBvGgIYC2u4_YAiBCABIAIoARonCAkQARoZCg0ICRAGGAEiAzAwMTABEBUaAhgLm5xhAyIEIAEgAigBGicIChAIGhkKDQ"
//		"gKEAgYASIDMDAxMAEQBRoCGAtJNtG4IgQgASACKAEaKAgIEAEaGgoNCAgQBhgBIgMwMDEwARDABhoCGAsqYFZaIgQgASACKAEaKAgNEAEaGgoNCA0QBhgBIgMwMDEwARChRRoCGAtEzNIPIgQgASACKAEaKQgDEAEaGwoNCAMQBhgBIgMwMDEwARDFrAYaAhgLT6AtSiIEIAEgAigBGikIDhABGhsKDQgOEAYYASIDMDAxMAEQmIYCGgIYC4AD04EiBCABIAIoASICCAE=&$ct=application/x-protobuf&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", "Referer=", ENDITEM, 
		LAST);

	ctrx_nfuse_connect("https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/LaunchIca/{ICA_FILE}.ica?CsrfToken={CitrixXenApp_CsrfToken}&IsUsingHttps=Yes&displayNameDesktopTitle={CITRIX_DESKTOP}&launchId=1565604149900", CTRX_LAST);

	lr_end_transaction("ICA",LR_AUTO);

	lr_start_transaction("Open_ICA");

	ctrx_wait_for_event("LOGON", CTRX_LAST);

	lr_end_transaction("Open_ICA",LR_AUTO);


	lr_think_time(10);

	lr_start_transaction("Open_CAD");

	ctrx_mouse_double_click(29, 232, LEFT_BUTTON, 0, "NULL=snapshot3", CTRX_LAST);

	lr_end_transaction("Open_CAD",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("Patient_files");

	ctrx_sync_on_window("CA Digital - CA Digital", ACTIVATE, 0, 0, 1281, 761, "snapshot4", CTRX_LAST);

	ctrx_mouse_click(345, 485, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot5", CTRX_LAST);

	lr_end_transaction("Patient_files",LR_AUTO);

	lr_think_time(16);

	lr_start_transaction("Create_Patient");

	ctrx_mouse_click(893, 621, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot6", CTRX_LAST);

	lr_end_transaction("Create_Patient",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("Patient_details");

	ctrx_mouse_click(1148, 235, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot7", CTRX_LAST);

	ctrx_type("CAD{PATIENT_ID}", "", CTRX_LAST);

	ctrx_mouse_click(1124, 267, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot9", CTRX_LAST);

	ctrx_type("CADFNAME{PATIENT_ID}", "", CTRX_LAST);

	ctrx_mouse_click(1125, 298, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot12", CTRX_LAST);

	ctrx_type("CADLNAME{PATIENT_ID}", "", CTRX_LAST);

	ctrx_key("TAB_KEY", 0, "", CTRX_LAST);

	ctrx_type("01/07/1986", "", CTRX_LAST);

	lr_think_time(3);

	ctrx_mouse_click(1128, 360, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot16", CTRX_LAST);

	ctrx_type("CADMRN{PATIENT_ID}", "", CTRX_LAST);

	lr_think_time(3);

	ctrx_mouse_click(1139, 429, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot17", CTRX_LAST);

	ctrx_type("{Date}", "", CTRX_LAST);

	lr_end_transaction("Patient_details",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("Save");

	ctrx_mouse_click(1188, 683, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot20", CTRX_LAST);

	web_revert_auto_header("Csrf-Token");

	web_revert_auto_header("X-Citrix-IsUsingHTTPS");

	web_revert_auto_header("X-Requested-With");

	lr_end_transaction("Save",LR_AUTO);



	return 0;
}