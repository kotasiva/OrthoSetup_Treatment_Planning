Action()
{

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=75", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://ssl.gstatic.com/safebrowsing/csd/client_model_v5_variation_0.pb", "Referer=", ENDITEM, 
		"Url=https://ssl.gstatic.com/safebrowsing/csd/client_model_v5_ext_variation_0.pb", "Referer=", ENDITEM, 
		LAST);

	lr_think_time(19);

	web_url("SmileDirectClubWeb", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=custom/style.css", ENDITEM, 
		"Url=receiver/js/external/hammer.v2.0.8.min_F699A1E56189259A.js", ENDITEM, 
		"Url=receiver/images/1x/CitrixReceiver_WebScreen_CBE548FB8FEE049E.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/js/external/jquery.dotdotdot.min_08EE54CBA886AD0A.js", ENDITEM, 
		"Url=receiver/js/external/velocity.min_B218502A82F66680.js", ENDITEM, 
		"Url=receiver/js/external/slick.min_FEB62CC230E2BA2A.js", ENDITEM, 
		"Url=receiver/js/ctxs.core.min_33B1CC992A07D57E.js", ENDITEM, 
		"Url=receiver/js/ctxs.webui.min_895B3076E3BA6027.js", ENDITEM, 
		"Url=receiver/images/1x/folder_template_C13BB96DEBC9F30F.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/images/common/ReceiverFullScreenBackground_46E559C0E6B5A27B.jpg", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=custom/script.js", ENDITEM, 
		"Url=custom/strings.en.js", ENDITEM, 
		"Url=receiver/images/1x/actionSprite_531B7A6FF85CA98E.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/images/1x/viewSprite_B2F322BDCB824FAF.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/images/common/authspinner_B0BCD339560CA593.gif", ENDITEM, 
		"Url=receiver/images/common/icon_loading_9A0623127A028FEB.png", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL2NqTTJXVmxLZW1OTFNISnJWREJMZG5GbGRWbGxTVGNyTVRFMFBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL1duZHhaRlZXV0VWTWRuYzNPRGw2VEhWUUsyRkNTSE5WYVhoclBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL1UxZFNOblpTYkhaRmVUbEJNRzAzTjB3MWNHRkRLMUIyYm1zNFBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL00zZE9NVWROUmtWMFQwZDBhME5yWVRJM2NsaDBia04yUTFkU1QxbFNkVGhXU1ZWQlRXWlNWbFJpZHowLS9pbWFnZQ--?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL2NFTm9NM1JKUnpObVZFTnpORXhRTUUxT2EyY3lVa3N5TXl0alBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL2JHRnhlRmhYYmtwdmJqbFVWV3hwVlZaV1EyOXBlbmxITTI5QlBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		LAST);

	web_add_auto_header("X-Citrix-IsUsingHTTPS", 
		"Yes");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_custom_request("Configuration", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Home/Configuration", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_add_auto_header("Csrf-Token", 
		"DFFFA3689D6B71C82012E60F0CD651CC");

	lr_think_time(4);

	web_custom_request("GetDetectionTicket", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionTicket", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("GetDetectionStatus", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionStatus", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body=ticket=CDT_jomcZ!36Y1ASZQRxP2mQn5os7s6RSyZrruQNGEX7WtimRnEGyMpb!u0p0vT_wcPb", 
		LAST);

	web_custom_request("GetDetectionStatus_2", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionStatus", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body=ticket=CDT_jomcZ!36Y1ASZQRxP2mQn5os7s6RSyZrruQNGEX7WtimRnEGyMpb!u0p0vT_wcPb", 
		LAST);

	web_custom_request("GetDetectionStatus_3", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionStatus", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body=ticket=CDT_jomcZ!36Y1ASZQRxP2mQn5os7s6RSyZrruQNGEX7WtimRnEGyMpb!u0p0vT_wcPb", 
		LAST);

	web_add_cookie("CtxsUserPreferredClient=Native; DOMAIN=storefront.smileco.com");

	web_add_cookie("CtxsClientDetectionDone=true; DOMAIN=storefront.smileco.com");

	web_add_cookie("CtxsHasUpgradeBeenShown=true; DOMAIN=storefront.smileco.com");

	web_submit_data("List", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/List", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=format", "Value=json", ENDITEM, 
		"Name=resourceDetails", "Value=Default", ENDITEM, 
		LAST);

	web_custom_request("GetAuthMethods", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Authentication/GetAuthMethods", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("Login", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ExplicitAuth/Login", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/vnd.citrix.authenticateresponse-1+xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=", 
		EXTRARES, 
		"Url=../receiver/images/1x/CitrixStoreFront_auth_14B96BFF2B0A6FF8.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		LAST);

	web_revert_auto_header("Csrf-Token");

	web_revert_auto_header("X-Citrix-IsUsingHTTPS");

	web_revert_auto_header("X-Requested-With");

	lr_think_time(6);

	web_custom_request("reportDetectionStatus", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClub/clientAssistant/reportDetectionStatus", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"Body=ticket=CDT_jomcZ!36Y1ASZQRxP2mQn5os7s6RSyZrruQNGEX7WtimRnEGyMpb!u0p0vT_wcPb&protocolVersion=1&hdxVersion=14.7.0.13011&hdxIsPassthrough=False&hdxIsPassthroughVariable=False", 
		EXTRARES, 
		"Url=/Citrix/SmileDirectClubWeb/receiver/images/1x/spinner_white_auth_button_53FD5A337A529DA7.gif", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		LAST);

	lr_start_transaction("Login");

	web_add_auto_header("Csrf-Token", 
		"DFFFA3689D6B71C82012E60F0CD651CC");

	web_add_auto_header("X-Citrix-IsUsingHTTPS", 
		"Yes");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_submit_data("LoginAttempt", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ExplicitAuth/LoginAttempt", 
		"Method=POST", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=username", "Value=Crtest.user5", ENDITEM, 
		"Name=password", "Value=P@$$word5", ENDITEM, 
		"Name=saveCredentials", "Value=false", ENDITEM, 
		"Name=loginBtn", "Value=Log On", ENDITEM, 
		"Name=StateContext", "Value=", ENDITEM, 
		LAST);

	web_add_cookie("CtxsPasswordChangeAllowed=true; DOMAIN=storefront.smileco.com");

	web_submit_data("List_2", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/List", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=format", "Value=json", ENDITEM, 
		"Name=resourceDetails", "Value=Default", ENDITEM, 
		EXTRARES, 
		"Url=../receiver/images/1x/CitrixReceiverLogo_Home_5C24BCEC5A182425.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=../receiver/images/1x/spinner_5CF0D1C8A76AAC8E.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=../receiver/images/1x/ico_search_E84E3D63D821F80D.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=../receiver/images/1x/search_close_BC5A22358E58905F.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		LAST);

	web_custom_request("GetUserName", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Authentication/GetUserName", 
		"Method=POST", 
		"Resource=0", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("AllowSelfServiceAccountManagement", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ExplicitAuth/AllowSelfServiceAccountManagement", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	lr_end_transaction("Login",LR_AUTO);

	lr_think_time(9);

	lr_start_transaction("ICA");

	web_submit_data("WGVuRGVza3RvcCBDb250cm9sbGVyLldpbjEwX2NhZHRzdCAkUzc2LTEzNA--", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/GetLaunchStatus/WGVuRGVza3RvcCBDb250cm9sbGVyLldpbjEwX2NhZHRzdCAkUzc2LTEzNA--", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=displayNameDesktopTitle", "Value=Win10_CADTraining", ENDITEM, 
		"Name=createFileFetchTicket", "Value=false", ENDITEM, 
		EXTRARES, 
		"Url=https://safebrowsing.googleapis.com/v4/threatListUpdates:fetch?$req="
		"Ch0KDGdvb2dsZWNocm9tZRINNzUuMC4zNzcwLjE0MhopCAUQARobCg0IBRAGGAEiAzAwMTABEIT8BhoCGAsnksYDIgQgASACKAEaKQgBEAEaGwoNCAEQBhgBIgMwMDEwARC0qQYaAhgLGARDLyIEIAEgAigBGikIBxABGhsKDQgHEAYYASIDMDAxMAEQqecFGgIYC_zKWE8iBCABIAIoARonCAEQARoZCg0IARAGGAEiAzAwMTADEBQaAhgLmhN4KiIEIAEgAigDGigIARAIGhoKDQgBEAgYASIDMDAxMAQQ3RcaAhgL1G6oRCIEIAEgAigEGicICRABGhkKDQgJEAYYASIDMDAxMAYQAhoCGAsFHOT7IgQgASACKAYaJwgPEAEaGQoNCA8QBhgBIgMwMDEwARBvGgIYC2u4_YAiBCABIAIoARonCAkQARoZCg0ICRAGGAEiAzAwMTABEBUaAhgLm5xhAyIEIAEgAigBGicIChAIGhkKDQ"
		"gKEAgYASIDMDAxMAEQBRoCGAtJNtG4IgQgASACKAEaKAgIEAEaGgoNCAgQBhgBIgMwMDEwARDABhoCGAsqYFZaIgQgASACKAEaKAgNEAEaGgoNCA0QBhgBIgMwMDEwARChRRoCGAtEzNIPIgQgASACKAEaKQgDEAEaGwoNCAMQBhgBIgMwMDEwARDFrAYaAhgLT6AtSiIEIAEgAigBGikIDhABGhsKDQgOEAYYASIDMDAxMAEQmIYCGgIYC4AD04EiBCABIAIoASICCAE=&$ct=application/x-protobuf&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", "Referer=", ENDITEM, 
		LAST);

	ctrx_nfuse_connect("https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/LaunchIca/WGVuRGVza3RvcCBDb250cm9sbGVyLldpbjEwX2NhZHRzdCAkUzc2LTEzNA--.ica?CsrfToken=DFFFA3689D6B71C82012E60F0CD651CC&IsUsingHttps=Yes&displayNameDesktopTitle=Win10_CADTraining&launchId=1565604149900", CTRX_LAST);

	lr_end_transaction("ICA",LR_AUTO);

	lr_start_transaction("Open_ICA");

	ctrx_wait_for_event("LOGON", CTRX_LAST);

	lr_end_transaction("Open_ICA",LR_AUTO);

	lr_think_time(33);

	lr_start_transaction("Close_IE");

	ctrx_sync_on_window("UltiPro - Internet Explorer", ACTIVATE, 43, 36, 787, 594, "snapshot1", CTRX_LAST);

	ctrx_mouse_click(763, 12, LEFT_BUTTON, 0, "UltiPro - Internet Explorer=snapshot2", CTRX_LAST);

	lr_end_transaction("Close_IE",LR_AUTO);

	lr_think_time(17);

	lr_start_transaction("Open_CAD");

	ctrx_mouse_double_click(29, 232, LEFT_BUTTON, 0, "NULL=snapshot3", CTRX_LAST);

	lr_end_transaction("Open_CAD",LR_AUTO);

	lr_think_time(55);

	lr_start_transaction("Patient_files");

	ctrx_sync_on_window("CA Digital - CA Digital", ACTIVATE, 0, 0, 1281, 761, "snapshot4", CTRX_LAST);

	ctrx_mouse_click(345, 485, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot5", CTRX_LAST);

	lr_end_transaction("Patient_files",LR_AUTO);

	lr_think_time(16);

	lr_start_transaction("Create_Patient");

	ctrx_mouse_click(893, 621, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot6", CTRX_LAST);

	lr_end_transaction("Create_Patient",LR_AUTO);

	lr_think_time(11);

	lr_start_transaction("Patient_details");

	ctrx_mouse_click(1148, 235, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot7", CTRX_LAST);

	ctrx_type("CAD", "", CTRX_LAST);

	ctrx_type("F", "", CTRX_LAST);

	lr_think_time(7);

	ctrx_type("28746", "", CTRX_LAST);

	ctrx_mouse_click(1124, 267, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot9", CTRX_LAST);

	ctrx_type("CADFNAME", "", CTRX_LAST);

	ctrx_mouse_click(1125, 298, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot12", CTRX_LAST);

	ctrx_type("CADLNAME", "", CTRX_LAST);

	ctrx_key("TAB_KEY", 0, "", CTRX_LAST);

	ctrx_type("01/07/1986", "", CTRX_LAST);

	lr_think_time(4);

	ctrx_mouse_click(1128, 360, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot16", CTRX_LAST);

	ctrx_type("CADMRN6390267", "", CTRX_LAST);

	lr_think_time(6);

	ctrx_mouse_click(1139, 429, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot17", CTRX_LAST);

	ctrx_type("08/12/2019", "", CTRX_LAST);

	lr_end_transaction("Patient_details",LR_AUTO);

	lr_think_time(15);

	lr_start_transaction("Save");

	ctrx_mouse_click(1188, 683, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot20", CTRX_LAST);

	web_revert_auto_header("Csrf-Token");

	web_revert_auto_header("X-Citrix-IsUsingHTTPS");

	web_revert_auto_header("X-Requested-With");

	lr_think_time(21);

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=9:454323615&cup2hreq=b191d8149d72c1afc0348826c9b74d4b3506f19dfe5d1131008b7bb2908986cf", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx2,crx3\",\"app\":[{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"CHBF\",\"cohortname\":\"Auto\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{efd8eba6-701c-442d-8936-9e3c8e8fa49c}\",\"rd\":4605},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"hnimpnehoodheedghdeeijklkeaacbdc\",\"brand\":\"CHBF\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.1cd7dc2056afaa0f6a705c9a17d22bba6578b33f5dae9e2d6518a0bfcced2396\"}]},\"ping\":{\"ping_freshness\":\"{fdcebcbf-07da-4f50-9c95-898b40f5f95e}\",\"rd\":4605},\"updatecheck\":{},\"version\":\"0.57.44.2492\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"CHBF\",\"cohort\":\"1:bm1:\",\"cohorthint\":\"M54ToM99\",\"cohortname\":\"M54ToM99\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.d2c5ef6972360a7006d320139d300bc3586faee6ee368ddc33f9895aa40a9482\"}]},\"ping\":{\""
		"ping_freshness\":\"{dc429b39-6209-47f8-be75-3845722ecf96}\",\"rd\":4605},\"updatecheck\":{},\"version\":\"9.3\"},{\"appid\":\"mimojjlkmoijpicakmndhoigimigcmbb\",\"brand\":\"CHBF\",\"cohort\":\"1:d0j:\",\"cohorthint\":\"Chrome [M50... M99]\",\"cohortname\":\"Chrome [M50... M99]\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.6487a703fc966c91ebc419bf928b2aca0dc8d823087dc0f05e564ee7ad3cd797\"}]},\"ping\":{\"ping_freshness\":\"{ebadf32b-fef8-4ed0-9f92-38bdecd426dd}\",\"rd\":4605},\""
		"updatecheck\":{},\"version\":\"32.0.0.223\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"CHBF\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{69d9404b-0068-4716-b7e8-5c52a4a032ec}\",\"rd\":4605},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"CHBF\",\"cohort\":\"1:cux:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.fd49e95c952bdb265a80513767311a5e069ac9dbf2ed4b480b96513b0ccbe086\"}]},\"ping\":{\"ping_freshness\":\"{9b9f90a1-cb72-4902-a346-3c509ac18b10}\",\"rd\":4605},\"updatecheck\":{},\"version\":\"36\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"CHBF\",\"cohort\":\"1:j5l:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.3eb16d6c28b502ac4cfee8f4a148df05f4d93229fa36a71db8b08d06329ff18a\"}]},\"ping\":{\"ping_freshness\":\""
		"{e6e3443c-07cf-4ea7-b838-3d101f3912b2}\",\"rd\":4605},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"aemomkdncapdnfajjbbcbdebjljbpmpj\",\"brand\":\"CHBF\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.65717b0144bfb0bd193f8ce31bf0dd7c95ff6d5844f2bc0c742974c1ccf889ae\"}]},\"ping\":{\"ping_freshness\":\"{f56b0ed7-0057-4ecc-85f6-46dc11e4e007}\",\"rd\":4605},\"updatecheck\":{},\"version\":\"1.0.5.0\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"CHBF\",\"cohort\":\"1:ofl:\""
		",\"cohorthint\":\"stable64\",\"cohortname\":\"stable64\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\"ping\":{\"ping_freshness\":\"{2babf2e3-8c50-4cfc-afd1-a8a270410b9d}\",\"rd\":4605},\"updatecheck\":{},\"version\":\"2018.8.8.0\"},{\"appid\":\"copjbmjbojbakpaedmpkhmiplmmehfck\",\"brand\":\"CHBF\",\"cohort\":\"1:p1x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp"
		"\":\"1.207921137eee9c0831e0bd890330986c10dfd9382034491b82de3f86ae6915f7\"}]},\"ping\":{\"ping_freshness\":\"{e71beabe-0609-4bed-9c52-76dca3558b62}\",\"rd\":4605},\"updatecheck\":{},\"version\":\"2018.9.6.0\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"CHBF\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{7023f86e-c162-4cdc-8af9-b8ff2c06e3cb}\",\"rd\":4605},\"updatecheck\":{},\"version\":\"4.10.1440.18\"},{\"appid\":\"gkmgaooipdjhmangpemjhigmamcehddo\",\"brand\":\"CHBF\",\""
		"cohort\":\"1:pw3:\",\"cohorthint\":\"Stable Location B\",\"cohortname\":\"Stable Location B\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.58da1c18b749f17d1af2330dd8daa07139025e035f5315624c2a15c8e6c10efe\"}]},\"ping\":{\"ping_freshness\":\"{54a262c4-e3ae-43ba-80bb-b10ff505a8a8}\",\"rd\":4605},\"tag\":\"eset_exp_b\",\"updatecheck\":{},\"version\":\"44.212.200.3\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"CHBF\",\"cohort\":\"1:jcl:\",\"cohorthint\":\"Auto\",\""
		"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.a0d2b691aa6c3379b294f98ddc502f1d43ff8c04315faadbf785f2ed08b0e762\"}]},\"ping\":{\"ping_freshness\":\"{711c5e0f-fb67-4fa0-977d-c0f4c4e49914}\",\"rd\":4605},\"updatecheck\":{},\"version\":\"5328\"},{\"appid\":\"ojjgnpkioondelmggbekfhllhdaimnho\",\"brand\":\"CHBF\",\"cohort\":\"1:0:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.d31a7ec86da6faba8aee1657b5bf1e1a34c9faf53f6d3696ef421c388fccafab\"}]},\"ping\":{\"ping_freshness\":\"{43fa5e17-babe-4f64-a76c-7c45390e7a7d}\",\"rd\":4605},\"updatecheck\":{},\"version\":\"1210\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":true,\"hw\":{\"physmemory\":16},\"lang\":\"en-US\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.17134.885\"},\"prodversion\":\"75.0.3770.142\",\"protocol\":\"3.1\",\"requestid\":\""
		"{8221f2de-fcc6-499a-abe5-7090ae9752cf}\",\"sessionid\":\"{25c37d2b-7341-48bb-acbd-dfa53f6c8274}\",\"updater\":{\"autoupdatecheckenabled\":false,\"ismachine\":true,\"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":-1,\"version\":\"1.3.34.13\"},\"updaterversion\":\"75.0.3770.142\"}}", 
		LAST);

	lr_end_transaction("Save",LR_AUTO);

	lr_think_time(12);

	web_custom_request("json_2", 
		"URL=https://update.googleapis.com/service/update2/json", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx2,crx3\",\"app\":[{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"event\":[{\"download_time_ms\":12108,\"downloaded\":18759,\"downloader\":\"bits\",\"eventresult\":1,\"eventtype\":14,\"nextversion\":\"5329\",\"previousversion\":\"5328\",\"total\":18759,\"url\":\"http://redirector.gvt1.com/edgedl/release2/chrome_component/GhiYao5bmSa3VuebK1LSAA_5329/APWxsYKkRnftZjOLozwZiG0\"},{\"eventresult\":1,\"eventtype\":3,\""
		"nextfp\":\"1.a8398e54a993c0835e73c910990e98683fdae888b184a08d0df4126d3236ecc9\",\"nextversion\":\"5329\",\"previousfp\":\"1.a0d2b691aa6c3379b294f98ddc502f1d43ff8c04315faadbf785f2ed08b0e762\",\"previousversion\":\"5328\"}],\"version\":\"5329\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"hw\":{\"physmemory\":16},\"lang\":\"en-US\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.17134.885\"},\"prodversion\":\"75.0.3770.142\",\"protocol\":\"3.1\",\"requestid"
		"\":\"{4c8d4d3f-24c8-47b5-b2f8-c205aca25a24}\",\"sessionid\":\"{25c37d2b-7341-48bb-acbd-dfa53f6c8274}\",\"updaterversion\":\"75.0.3770.142\"}}", 
		LAST);

	lr_think_time(32);

	lr_start_transaction("Import_STL_FILES");

	ctrx_mouse_click(225, 60, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot21", CTRX_LAST);

	lr_end_transaction("Import_STL_FILES",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("Upper_jaw");

	ctrx_sync_on_window("Load document...", ACTIVATE, 415, 217, 450, 325, "snapshot22", CTRX_LAST);

	ctrx_mouse_click(429, 183, LEFT_BUTTON, 0, "Load document...=snapshot23", CTRX_LAST);

	ctrx_sync_on_window("Open", ACTIVATE, 220, 161, 841, 433, "snapshot24", CTRX_LAST);

	ctrx_mouse_click(361, 103, LEFT_BUTTON, 0, "Open=snapshot25", CTRX_LAST);

	ctrx_mouse_click(776, 372, LEFT_BUTTON, 0, "Open=snapshot26", CTRX_LAST);

	lr_end_transaction("Upper_jaw",LR_AUTO);

	lr_think_time(9);

	lr_start_transaction("Lower_jaw");

	ctrx_sync_on_window("Load document...", ACTIVATE, 415, 217, 450, 325, "snapshot27", CTRX_LAST);

	ctrx_mouse_click(426, 219, LEFT_BUTTON, 0, "Load document...=snapshot28", CTRX_LAST);

	ctrx_sync_on_window("Open", ACTIVATE, 220, 161, 841, 433, "snapshot29", CTRX_LAST);

	ctrx_mouse_click(363, 79, LEFT_BUTTON, 0, "Open=snapshot30", CTRX_LAST);

	ctrx_mouse_click(762, 381, LEFT_BUTTON, 0, "Open=snapshot31", CTRX_LAST);

	lr_end_transaction("Lower_jaw",LR_AUTO);

	lr_think_time(11);

	lr_start_transaction("Load_STL_FILES");

	ctrx_sync_on_window("Load document...", ACTIVATE, 415, 217, 450, 325, "snapshot32", CTRX_LAST);

	ctrx_mouse_click(214, 296, LEFT_BUTTON, 0, "Load document...=snapshot33", CTRX_LAST);

	lr_end_transaction("Load_STL_FILES",LR_AUTO);

	lr_think_time(41);

	lr_start_transaction("Open_Loaded_STL_FILES");

	ctrx_sync_on_window("CA Digital - CA Digital", ACTIVATE, 0, 0, 1281, 761, "snapshot34", CTRX_LAST);

	ctrx_mouse_double_click(261, 283, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot35", CTRX_LAST);

	lr_end_transaction("Open_Loaded_STL_FILES",LR_AUTO);

	lr_think_time(42);

	lr_start_transaction("Step1");

	ctrx_sync_on_window("CA Digital - CA Digital_2", ACTIVATE, 0, 0, 1281, 761, "snapshot36", CTRX_LAST);

	ctrx_mouse_click(500, 187, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot37", CTRX_LAST);

	ctrx_mouse_click(63, 331, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot38", CTRX_LAST);

	lr_think_time(6);

	ctrx_mouse_click(366, 366, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot39", CTRX_LAST);

	ctrx_type("  ", "", CTRX_LAST);

	ctrx_mouse_click(174, 370, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot42", CTRX_LAST);

	lr_think_time(6);

	ctrx_mouse_click(499, 188, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot43", CTRX_LAST);

	lr_end_transaction("Step1",LR_AUTO);

	lr_think_time(22);

	lr_start_transaction("step2");

	ctrx_mouse_click(132, 128, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot44", CTRX_LAST);

	lr_think_time(10);

	ctrx_mouse_click(796, 422, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot45", CTRX_LAST);

	ctrx_mouse_click(956, 420, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot46", CTRX_LAST);

	lr_think_time(8);

	ctrx_mouse_click(794, 499, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot47", CTRX_LAST);

	ctrx_mouse_click(954, 506, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot48", CTRX_LAST);

	lr_think_time(7);

	ctrx_mouse_click(189, 402, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot49", CTRX_LAST);

	ctrx_mouse_click(198, 361, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot50", CTRX_LAST);

	ctrx_mouse_click(202, 330, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot51", CTRX_LAST);

	ctrx_mouse_click(208, 304, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot52", CTRX_LAST);

	ctrx_mouse_click(218, 272, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot53", CTRX_LAST);

	ctrx_mouse_click(231, 241, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot54", CTRX_LAST);

	ctrx_mouse_click(264, 231, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot55", CTRX_LAST);

	ctrx_mouse_click(296, 226, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot56", CTRX_LAST);

	ctrx_mouse_click(330, 233, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot57", CTRX_LAST);

	ctrx_mouse_click(356, 259, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot58", CTRX_LAST);

	ctrx_mouse_click(375, 287, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot59", CTRX_LAST);

	ctrx_mouse_click(380, 316, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot60", CTRX_LAST);

	ctrx_mouse_click(390, 343, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot61", CTRX_LAST);

	ctrx_mouse_click(409, 383, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot62", CTRX_LAST);

	ctrx_mouse_click(204, 514, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot63", CTRX_LAST);

	ctrx_mouse_click(210, 554, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot64", CTRX_LAST);

	ctrx_mouse_click(213, 595, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot65", CTRX_LAST);

	ctrx_mouse_click(217, 623, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot66", CTRX_LAST);

	ctrx_mouse_click(226, 650, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot67", CTRX_LAST);

	ctrx_mouse_click(246, 671, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot68", CTRX_LAST);

	ctrx_mouse_click(263, 677, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot69", CTRX_LAST);

	ctrx_mouse_click(289, 680, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot70", CTRX_LAST);

	ctrx_mouse_click(310, 674, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot71", CTRX_LAST);

	ctrx_mouse_click(330, 660, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot72", CTRX_LAST);

	ctrx_mouse_click(353, 640, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot73", CTRX_LAST);

	ctrx_mouse_click(363, 616, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot74", CTRX_LAST);

	ctrx_mouse_click(378, 580, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot76", CTRX_LAST);

	ctrx_mouse_click(397, 543, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot77", CTRX_LAST);

	ctrx_mouse_click(795, 403, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot78", CTRX_LAST);

	ctrx_mouse_click(799, 379, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot79", CTRX_LAST);

	ctrx_mouse_click(808, 349, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot80", CTRX_LAST);

	ctrx_mouse_click(820, 329, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot81", CTRX_LAST);

	ctrx_mouse_click(830, 310, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot82", CTRX_LAST);

	ctrx_mouse_click(846, 299, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot83", CTRX_LAST);

	ctrx_mouse_click(863, 294, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot84", CTRX_LAST);

	ctrx_mouse_click(885, 294, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot85", CTRX_LAST);

	ctrx_mouse_click(914, 298, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot86", CTRX_LAST);

	ctrx_mouse_click(922, 307, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot87", CTRX_LAST);

	ctrx_mouse_click(933, 324, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot88", CTRX_LAST);

	ctrx_mouse_click(939, 346, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot89", CTRX_LAST);

	ctrx_mouse_click(945, 370, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot90", CTRX_LAST);

	ctrx_mouse_click(951, 397, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot91", CTRX_LAST);

	ctrx_mouse_click(796, 532, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot92", CTRX_LAST);

	ctrx_mouse_click(799, 564, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot93", CTRX_LAST);

	ctrx_mouse_click(811, 590, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot94", CTRX_LAST);

	ctrx_mouse_click(816, 611, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot95", CTRX_LAST);

	ctrx_mouse_click(832, 629, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot96", CTRX_LAST);

	ctrx_mouse_click(843, 630, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot97", CTRX_LAST);

	ctrx_mouse_click(860, 635, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot98", CTRX_LAST);

	ctrx_mouse_click(885, 632, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot99", CTRX_LAST);

	ctrx_mouse_click(909, 628, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot100", CTRX_LAST);

	ctrx_mouse_click(921, 621, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot101", CTRX_LAST);

	ctrx_mouse_click(933, 607, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot102", CTRX_LAST);

	ctrx_mouse_click(943, 589, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot103", CTRX_LAST);

	ctrx_mouse_click(943, 569, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot104", CTRX_LAST);

	ctrx_mouse_click(949, 531, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot105", CTRX_LAST);

	ctrx_mouse_click(812, 460, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot106", CTRX_LAST);

	lr_end_transaction("step2",LR_AUTO);

	lr_think_time(55);

	lr_start_transaction("Step3");

	ctrx_mouse_click(182, 136, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot107", CTRX_LAST);

	ctrx_type(" ", "", CTRX_LAST);

	lr_end_transaction("Step3",LR_AUTO);

	return 0;
}