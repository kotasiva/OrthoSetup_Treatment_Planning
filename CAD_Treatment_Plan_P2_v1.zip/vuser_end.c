﻿vuser_end()
{
	
	lr_think_time(20);

	lr_start_transaction("Close_CAD");

	ctrx_sync_on_window("CA Digital - CA Digital_2", ACTIVATE, 0, 0, 1281, 985, "snapshot111", CTRX_LAST);

	ctrx_mouse_click(1254, 12, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot112", CTRX_LAST);

	lr_end_transaction("Close_CAD",LR_AUTO);

	lr_start_transaction("Close_Citrix");

	ctrx_logoff(CTRX_NORMAL_LOGOFF, CTRX_LAST);

	lr_end_transaction("Close_Citrix",LR_AUTO);

	lr_start_transaction("Logout");

	web_add_cookie("CtxsDesktopAutoLaunchDone=no; DOMAIN=storefront.smileco.com");

	web_add_header("Csrf-Token",
		"{CitrixXenApp_CsrfToken}");

	web_add_auto_header("X-Citrix-IsUsingHTTPS", 
		"Yes");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

		web_custom_request("Disconnect", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Sessions/Disconnect", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);



	web_custom_request("Logoff", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Authentication/Logoff", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);
	
	lr_end_transaction("Logout", LR_AUTO);
	
	
	return 0;
}
