﻿Action()
{


	
	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Links}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP1_04_Click_Patient" );	

	lr_start_transaction("CAD_BP1_04_Click_Patient");
	

	ctrx_sync_on_window("CA Digital - CA Digital", ACTIVATE, 0, 0, 1281, 985, "snapshot2", CTRX_LAST);

	ctrx_mouse_click(330, 632, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot3", CTRX_LAST);
	

	lr_end_transaction("CAD_BP1_04_Click_Patient",LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP1_04_Click_Patient" );


		//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Links}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP1_05_Create_Patient" );	
		
	lr_start_transaction("CAD_BP1_05_Create_Patient");
	
	ctrx_mouse_click(887, 758, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot4", CTRX_LAST);

	lr_end_transaction("CAD_BP1_05_Create_Patient",LR_AUTO);
	
		//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP1_05_Create_Patient" );


	//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Links}")));
	
// 	Declare Complex Transaction
// 	Intitialize network throughput
	TransactionType = "Simple";
//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1,"CAD_BP1_06_Patient_Details" );	
		
	lr_start_transaction("CAD_BP1_06_Patient_Details");
	
	ctrx_mouse_click(1127, 263, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot5", CTRX_LAST);

	ctrx_type("CAD{PatientID}", "", CTRX_LAST);

	ctrx_mouse_click(1116, 299, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot8", CTRX_LAST);

	ctrx_type("CAF{PatientID}", "", CTRX_LAST);

	ctrx_mouse_click(1125, 338, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot10", CTRX_LAST);

	ctrx_type("CAL{PatientID}", "", CTRX_LAST);

	ctrx_mouse_click(1134, 383, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot12", CTRX_LAST);

	ctrx_type("01/07/1986", "", CTRX_LAST);

	ctrx_mouse_click(1125, 424, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot31", CTRX_LAST);

	ctrx_type("MRN{PatientID}", "", CTRX_LAST);

	ctrx_mouse_click(1131, 498, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot33", CTRX_LAST);

	ctrx_type("09/04/2019", "", CTRX_LAST);

	ctrx_mouse_click(1182, 901, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot36", CTRX_LAST);

	lr_end_transaction("CAD_BP1_06_Patient_Details",LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_BP1_06_Patient_Details" );




	return 0;
}