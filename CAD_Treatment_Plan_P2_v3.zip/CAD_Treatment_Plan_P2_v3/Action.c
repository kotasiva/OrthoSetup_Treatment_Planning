﻿Action()
{

	web_set_sockets_option("SSL_VERSION", "TLS");
	
		//Realistic thinktime
	lr_think_time(atoi(lr_eval_string("{Think_Portal}")));
	
	// Initialize Throughput Calculations
    // Declare Complex Transaction
	TransactionType = "Simple";
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 0, "CAD_BP3_Treatment_Plan_Process_Start" );
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 1, "CAD_00_Portal_URL" );
	
	lr_start_transaction("CAD_00_Portal_URL");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=77", 
		"Resource=1", 
		"RecContentType=application/x-gzip", 
		"Referer=", 
		"Snapshot=t1.inf", 
		LAST);

	lr_think_time(4);

	web_url("SmileDirectClubWeb", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=custom/style.css", ENDITEM, 
		"Url=receiver/js/external/hammer.v2.0.8.min_F699A1E56189259A.js", ENDITEM, 
		"Url=receiver/js/external/jquery.dotdotdot.min_08EE54CBA886AD0A.js", ENDITEM, 
		"Url=receiver/js/external/velocity.min_B218502A82F66680.js", ENDITEM, 
		"Url=receiver/js/external/slick.min_FEB62CC230E2BA2A.js", ENDITEM, 
		"Url=receiver/js/ctxs.core.min_33B1CC992A07D57E.js", ENDITEM, 
		"Url=receiver/images/1x/CitrixReceiver_WebScreen_CBE548FB8FEE049E.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/images/1x/folder_template_C13BB96DEBC9F30F.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/images/1x/actionSprite_531B7A6FF85CA98E.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/js/ctxs.webui.min_895B3076E3BA6027.js", ENDITEM, 
		"Url=receiver/images/common/ReceiverFullScreenBackground_46E559C0E6B5A27B.jpg", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=custom/script.js", ENDITEM, 
		"Url=custom/strings.en.js", ENDITEM, 
		"Url=receiver/images/1x/viewSprite_B2F322BDCB824FAF.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/images/common/authspinner_B0BCD339560CA593.gif", ENDITEM, 
		"Url=receiver/images/common/icon_loading_9A0623127A028FEB.png", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL2NFTm9NM1JKUnpObVZFTnpORXhRTUUxT2EyY3lVa3N5TXl0alBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL1duZHhaRlZXV0VWTWRuYzNPRGw2VEhWUUsyRkNTSE5WYVhoclBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL00zZE9NVWROUmtWMFQwZDBhME5yWVRJM2NsaDBia04yUTFkU1QxbFNkVGhXU1ZWQlRXWlNWbFJpZHowLS9pbWFnZQ--?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL2NqTTJXVmxLZW1OTFNISnJWREJMZG5GbGRWbGxTVGNyTVRFMFBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL2JHRnhlRmhYYmtwdmJqbFVWV3hwVlZaV1EyOXBlbmxITTI5QlBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL1UxZFNOblpTYkhaRmVUbEJNRzAzTjB3MWNHRkRLMUIyYm1zNFBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		LAST);

	web_add_auto_header("X-Citrix-IsUsingHTTPS", 
		"Yes");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

/*Correlation comment: Automatic rules - Do not change!  
Original value='A1A0BE4D7E28A176823C4EE517D043E1' 
Name ='CitrixXenApp_CsrfToken' 
Type ='Rule' 
AppName ='Citrix_XenApp' 
RuleName ='CsrfToken'*/
	web_reg_save_param_ex(
		"ParamName=CitrixXenApp_CsrfToken",
		"LB/IC=CsrfToken=",
		"RB/IC=;",
		SEARCH_FILTERS,
		"Scope=Cookies",
		"RequestUrl=*/Configuration*",
		LAST);

	web_custom_request("Configuration", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Home/Configuration", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncType=", 
		EXTRARES, 
		"Url=https://clients1.google.com/tbproxy/af/query?q=Chc2LjEuMTcxNS4xNDQyL2VuIChHR0xMKRMZtxZWN-1XI8ojLXBB36gkIy0pLWCOJBQ=", "Referer=", ENDITEM, 
		"Url=https://ssl.gstatic.com/safebrowsing/csd/client_model_v5_variation_0.pb", "Referer=", ENDITEM, 
		"Url=https://ssl.gstatic.com/safebrowsing/csd/client_model_v5_ext_variation_0.pb", "Referer=", ENDITEM, 
		LAST);

	web_add_auto_header("Csrf-Token",
		"{CitrixXenApp_CsrfToken}");

	web_custom_request("GetDetectionTicket", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionTicket", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncType=", 
		EXTRARES, 
		"Url=http://r3---sn-5ualdn76.gvt1.com/edgedl/chromewebstore/L2Nocm9tZV9leHRlbnNpb24vYmxvYnMvY2Y1QUFXUjZlVjI5UldyLVpDTFJFcEx6QQ/7719.805.0.2_pkedcjkdefgpdelpbcmbmeomcjbeemfm.crx?cms_redirect=yes&mip=12.107.218.94&mm=28&mn=sn-5ualdn76&ms=nvh&mt=1569404061&mv=m&mvi=2&pl=17&shardbypass=yes", "Referer=", ENDITEM, 
		LAST);

	web_submit_data("GetDetectionStatus", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionStatus", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=ticket", "Value=CDT_yTrIuTeozANmqlJ7GcWZirikRJz1Uo6OkJgmxJQPK0CEUdmmVW8MQh5WtjsSDC9s", ENDITEM, 
		LAST);

	web_submit_data("GetDetectionStatus_2", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionStatus", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=ticket", "Value=CDT_yTrIuTeozANmqlJ7GcWZirikRJz1Uo6OkJgmxJQPK0CEUdmmVW8MQh5WtjsSDC9s", ENDITEM, 
		LAST);

	web_add_cookie("CtxsUserPreferredClient=Native; DOMAIN=storefront.smileco.com");

	web_add_cookie("CtxsClientDetectionDone=true; DOMAIN=storefront.smileco.com");

	web_add_cookie("CtxsHasUpgradeBeenShown=true; DOMAIN=storefront.smileco.com");

	web_submit_data("List", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/List", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=format", "Value=json", ENDITEM, 
		"Name=resourceDetails", "Value=Default", ENDITEM, 
		LAST);

	web_custom_request("GetAuthMethods", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Authentication/GetAuthMethods", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("Login", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ExplicitAuth/Login", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/vnd.citrix.authenticateresponse-1+xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"EncType=", 
		EXTRARES, 
		"Url=../receiver/images/1x/CitrixStoreFront_auth_14B96BFF2B0A6FF8.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=https://clients1.google.com/tbproxy/af/query?q=Chc2LjEuMTcxNS4xNDQyL2VuIChHR0xMKRMZvqVRrhN9bbIjLeeNQA4kIy3OQUx6JBQ=", "Referer=", ENDITEM, 
		LAST);
	
	

	web_revert_auto_header("Csrf-Token");

	web_revert_auto_header("X-Citrix-IsUsingHTTPS");

	web_revert_auto_header("X-Requested-With");

	lr_think_time(6);

	web_submit_data("reportDetectionStatus", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClub/clientAssistant/reportDetectionStatus", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=ticket", "Value=CDT_yTrIuTeozANmqlJ7GcWZirikRJz1Uo6OkJgmxJQPK0CEUdmmVW8MQh5WtjsSDC9s", ENDITEM, 
		"Name=protocolVersion", "Value=1", ENDITEM, 
		"Name=hdxVersion", "Value=14.7.0.13011", ENDITEM, 
		"Name=hdxIsPassthrough", "Value=False", ENDITEM, 
		"Name=hdxIsPassthroughVariable", "Value=False", ENDITEM, 
		EXTRARES, 
		"Url=/Citrix/SmileDirectClubWeb/receiver/images/1x/spinner_white_auth_button_53FD5A337A529DA7.gif", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		LAST);

	web_add_auto_header("Csrf-Token",
		"{CitrixXenApp_CsrfToken}");

	web_add_auto_header("X-Citrix-IsUsingHTTPS", 
		"Yes");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_submit_data("LoginAttempt", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ExplicitAuth/LoginAttempt", 
		"Method=POST", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=username", "Value={UserName}", ENDITEM, 
		"Name=password", "Value={Password}", ENDITEM, 
		"Name=saveCredentials", "Value=false", ENDITEM, 
		"Name=loginBtn", "Value=Log On", ENDITEM, 
		"Name=StateContext", "Value=", ENDITEM, 
		LAST);

	web_add_cookie("CtxsPasswordChangeAllowed=true; DOMAIN=storefront.smileco.com");

	web_submit_data("List_2", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/List", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=format", "Value=json", ENDITEM, 
		"Name=resourceDetails", "Value=Default", ENDITEM, 
		EXTRARES, 
		"Url=../receiver/images/1x/CitrixReceiverLogo_Home_5C24BCEC5A182425.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=../receiver/images/1x/spinner_5CF0D1C8A76AAC8E.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=../receiver/images/1x/ico_search_E84E3D63D821F80D.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=../receiver/images/1x/search_close_BC5A22358E58905F.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		LAST);

	web_custom_request("GetUserName", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Authentication/GetUserName", 
		"Method=POST", 
		"Resource=0", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("AllowSelfServiceAccountManagement", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ExplicitAuth/AllowSelfServiceAccountManagement", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

		lr_end_transaction("CAD_00_Portal_URL", LR_AUTO);
	
	//	Calculate Throughput Calculations
	if(CalculateNetworkThroughputFlag)
		CalcRequestResponseNetworkThroughput( 2, "CAD_00_Portal_URL");

	lr_think_time(15);

	lr_start_transaction("CAD_BP3_01_CLick_ICA");

	web_submit_data("WGVuRGVza3RvcCBDb250cm9sbGVyLkNBRFBlcmZvcm1hbmNlICRTODEtMTQ0", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/GetLaunchStatus/WGVuRGVza3RvcCBDb250cm9sbGVyLkNBRFBlcmZvcm1hbmNlICRTODEtMTQ0", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=displayNameDesktopTitle", "Value=CADPerformance", ENDITEM, 
		"Name=createFileFetchTicket", "Value=false", ENDITEM, 
		EXTRARES, 
		"Url=https://www.gstatic.com/chrome/config/plugins_3/plugins_win.json", "Referer=", ENDITEM, 
		LAST);

	ctrx_nfuse_connect("https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/LaunchIca/WGVuRGVza3RvcCBDb250cm9sbGVyLkNBRFBlcmZvcm1hbmNlICRTODEtMTQ0.ica?CsrfToken={CitrixXenApp_CsrfToken}&IsUsingHttps=Yes&displayNameDesktopTitle=CADPerformance&launchId=1569404233896", CTRX_LAST);

	lr_end_transaction("CAD_BP3_01_CLick_ICA",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("CAD_BP3_02_Open_ICA");

	ctrx_wait_for_event("LOGON", CTRX_LAST);

	lr_end_transaction("CAD_BP3_02_Open_ICA",LR_AUTO);

	lr_think_time(30);

	lr_start_transaction("CAD_BP3_03_Open_CAD_App");

	ctrx_mouse_click(49, 236, LEFT_BUTTON, 0, "NULL=snapshot4", CTRX_LAST);

	ctrx_sync_on_window("Desktop", ACTIVATE, 0, 0, 1281, 1025, "snapshot5", CTRX_LAST);

	ctrx_mouse_double_click(49, 236, LEFT_BUTTON, 0, "Desktop=snapshot6", CTRX_LAST);

	lr_end_transaction("CAD_BP3_03_Open_CAD_App",LR_AUTO);

	lr_think_time(60);

	lr_start_transaction("CAD_BP3_04_Click_Patient");

	ctrx_sync_on_window("CA Digital - CA Digital", ACTIVATE, 0, 0, 1281, 985, "snapshot7", CTRX_LAST);

	ctrx_mouse_click(319, 661, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot9", CTRX_LAST);

	lr_end_transaction("CAD_BP3_04_Click_Patient",LR_AUTO);

	lr_think_time(11);

	lr_start_transaction("CAD_BP3_05_Create_Patient");

	ctrx_mouse_click(834, 756, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot10", CTRX_LAST);

	lr_end_transaction("CAD_BP3_05_Create_Patient",LR_AUTO);

	lr_think_time(30);

	lr_start_transaction("CAD_BP3_06_Patient_Details");

	ctrx_mouse_click(1166, 266, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot11", CTRX_LAST);

	ctrx_type("CADP{PatientID}", "", CTRX_LAST);

	ctrx_mouse_click(1159, 303, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot13", CTRX_LAST);

	ctrx_type("CADF{PatientID}", "", CTRX_LAST);

	ctrx_mouse_click(1149, 346, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot15", CTRX_LAST);

	ctrx_type("CADL{PatientID}", "", CTRX_LAST);

	ctrx_mouse_click(1149, 380, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot17", CTRX_LAST);

	ctrx_type("01/07/1986", "", CTRX_LAST);

	ctrx_mouse_click(1150, 423, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot22", CTRX_LAST);

	ctrx_type("MRN{PatientID}", "", CTRX_LAST);

	ctrx_mouse_click(1145, 503, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot25", CTRX_LAST);

	ctrx_type("09/25/2019", "", CTRX_LAST);

	ctrx_mouse_click(1188, 902, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot30", CTRX_LAST);

	lr_end_transaction("CAD_BP3_06_Patient_Details",LR_AUTO);

	lr_think_time(30);

	lr_start_transaction("CAD_BP3_07_Import_STLFiles");

	ctrx_mouse_click(254, 61, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot31", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_sync_on_window("Load document...", ACTIVATE, 415, 309, 450, 364, "snapshot32", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(428, 213, LEFT_BUTTON, 0, "Load document...=snapshot33", CTRX_LAST);

	lr_think_time(4);

	ctrx_sync_on_window("Open", ACTIVATE, 220, 272, 841, 433, "snapshot34", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(54, 322, LEFT_BUTTON, 0, "Open=snapshot35", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(144, 208, LEFT_BUTTON, 0, "Open=snapshot36", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_double_click(144, 208, LEFT_BUTTON, 0, "Open=snapshot37", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_type("v", "", CTRX_LAST);

	lr_think_time(6);

	ctrx_mouse_click(781, 378, LEFT_BUTTON, 0, "Open=snapshot38", CTRX_LAST);

	lr_think_time(4);

	ctrx_mouse_click(137, 81, LEFT_BUTTON, 0, "Open=snapshot39", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(767, 373, LEFT_BUTTON, 0, "Open=snapshot41", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(200, 83, LEFT_BUTTON, 0, "Open=snapshot42", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(799, 376, LEFT_BUTTON, 0, "Open=snapshot43", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(415, 98, LEFT_BUTTON, 0, "Open=snapshot44", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(792, 376, LEFT_BUTTON, 0, "Open=snapshot45", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_sync_on_window("Load document...", ACTIVATE, 415, 309, 450, 364, "snapshot46", CTRX_LAST);
	
	lr_end_transaction("CAD_BP3_07_Import_STLFiles",LR_AUTO);
	
	lr_think_time(10);
	
	lr_start_transaction("CAD_BP3_08_LoadSTLFiles");


	ctrx_mouse_click(425, 247, LEFT_BUTTON, 0, "Load document...=snapshot47", CTRX_LAST);

	ctrx_sync_on_window("Open", ACTIVATE, 220, 272, 841, 433, "snapshot48", CTRX_LAST);

	ctrx_mouse_click(411, 80, LEFT_BUTTON, 0, "Open=snapshot49", CTRX_LAST);

	ctrx_mouse_click(794, 379, LEFT_BUTTON, 0, "Open=snapshot51", CTRX_LAST);

	ctrx_sync_on_window("Load document...", ACTIVATE, 415, 309, 450, 364, "snapshot52", CTRX_LAST);

	ctrx_mouse_click(223, 335, LEFT_BUTTON, 0, "Load document...=snapshot54", CTRX_LAST);

	lr_end_transaction("CAD_BP3_08_LoadSTLFiles", LR_AUTO);


	lr_think_time(60);

	lr_start_transaction("CAD_BP3_09_Open_Impressions");

	ctrx_sync_on_window("CA Digital - CA Digital", ACTIVATE, 0, 0, 1281, 985, "snapshot55", CTRX_LAST);

	ctrx_mouse_double_click(288, 281, LEFT_BUTTON, 0, "CA Digital - CA Digital=snapshot56", CTRX_LAST);

	lr_end_transaction("CAD_BP3_09_Open_Impressions",LR_AUTO);


	lr_think_time(25);

	lr_start_transaction("CAD_BP3_10_Step_1");

	ctrx_sync_on_window("CA Digital - CA Digital_2", ACTIVATE, 0, 0, 1281, 985, "snapshot57", CTRX_LAST);

	ctrx_mouse_click(647, 181, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot58", CTRX_LAST);

	lr_end_transaction("CAD_BP3_10_Step_1",LR_AUTO);

	lr_think_time(15);

	lr_start_transaction("CAD_BP3_11_Step_2");

	ctrx_mouse_click(127, 132, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot59", CTRX_LAST);

	lr_think_time(13);

	ctrx_mouse_click(172, 466, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot60", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(186, 422, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot61", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(202, 381, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot63", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(216, 346, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot64", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(229, 306, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot66", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(249, 276, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot67", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(289, 251, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot68", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(326, 258, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot69", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(366, 287, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot70", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(395, 315, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot72", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(399, 348, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot73", CTRX_LAST);

	lr_think_time(4);
	
	ctrx_mouse_click(411, 389, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot74", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(424, 427, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot75", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(439, 484, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot76", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(789, 523, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot77", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(951, 521, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot78", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(184, 673, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot79", CTRX_LAST);

	lr_think_time(4);

	ctrx_mouse_click(199, 728, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot80", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(221, 769, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot81", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(231, 799, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot83", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(237, 842, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot84", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(262, 861, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot85", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(292, 875, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot86", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(319, 874, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot87", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(346, 858, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot88", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(372, 835, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot90", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(390, 803, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot91", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(399, 764, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot92", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(412, 723, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot93", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(424, 669, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot94", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(790, 628, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot95", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(951, 630, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot96", CTRX_LAST);
	
	lr_think_time(4);

	ctrx_mouse_click(820, 583, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot98", CTRX_LAST);

	lr_end_transaction("CAD_BP3_11_Step_2",LR_AUTO);

	lr_think_time(120);

	lr_start_transaction("CAD_BP3_12_Step_3");

	ctrx_mouse_click(182, 141, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot99", CTRX_LAST);

	lr_think_time(101);

	ctrx_mouse_click(798, 186, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot100", CTRX_LAST);
	
	lr_think_time(20);

	ctrx_mouse_click(755, 236, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot101", CTRX_LAST);

	lr_think_time(15);

	ctrx_mouse_click(58, 295, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot102", CTRX_LAST);

	lr_think_time(15);

	ctrx_mouse_click(193, 355, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot103", CTRX_LAST);

	lr_think_time(10);

	ctrx_mouse_down(143, 330, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot104", CTRX_LAST);

	ctrx_mouse_up(137, 330, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot105", CTRX_LAST);

	lr_think_time(15);

	ctrx_mouse_down(135, 328, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot106", CTRX_LAST);

	ctrx_mouse_up(144, 332, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot107", CTRX_LAST);

	ctrx_mouse_click(144, 332, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot108", CTRX_LAST);

	ctrx_mouse_click(145, 333, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot109", CTRX_LAST);

	ctrx_mouse_click(453, 512, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot110", CTRX_LAST);

	lr_think_time(15);

	ctrx_mouse_click(449, 502, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot111", CTRX_LAST);

	lr_end_transaction("CAD_BP3_12_Step_3",LR_AUTO);

	lr_think_time(15);

	lr_start_transaction("CAD_BP3_13_Step_4");

	ctrx_mouse_click(252, 123, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot112", CTRX_LAST);

	lr_end_transaction("CAD_BP3_13_Step_4",LR_AUTO);

	lr_think_time(60);

	lr_start_transaction("CAD_BP3_14_Export_STL");

	ctrx_mouse_click(62, 923, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot113", CTRX_LAST);

	lr_think_time(9);

	ctrx_sync_on_window("Save", ACTIVATE, 200, 273, 882, 433, "snapshot114", CTRX_LAST);

	ctrx_mouse_click(849, 213, LEFT_BUTTON, 0, "Save=snapshot115", CTRX_LAST);

	ctrx_sync_on_window("Select Export File Types", ACTIVATE, 508, 391, 265, 201, "snapshot116", CTRX_LAST);

	ctrx_mouse_click(23, 50, LEFT_BUTTON, 0, "Select Export File Types=snapshot117", CTRX_LAST);

	ctrx_mouse_click(21, 79, LEFT_BUTTON, 0, "Select Export File Types=snapshot118", CTRX_LAST);

	ctrx_mouse_click(57, 173, LEFT_BUTTON, 0, "Select Export File Types=snapshot119", CTRX_LAST);

	ctrx_sync_on_window("Save", ACTIVATE, 200, 273, 882, 433, "snapshot120", CTRX_LAST);

	ctrx_mouse_click(827, 374, LEFT_BUTTON, 0, "Save=snapshot121", CTRX_LAST);

	lr_end_transaction("CAD_BP3_14_Export_STL",LR_AUTO);

	lr_think_time(180);

	lr_start_transaction("CAD_BP3_15_Home");

	ctrx_sync_on_window("CA Digital - CA Digital_2", ACTIVATE, 0, 0, 1281, 985, "snapshot122", CTRX_LAST);

	ctrx_mouse_click(155, 69, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot123", CTRX_LAST);

//	web_add_auto_header("Csrf-Token",
//		"{CitrixXenApp_CsrfToken}");
//
//	web_add_auto_header("X-Citrix-IsUsingHTTPS", 
//		"Yes");
//
//	web_add_auto_header("X-Requested-With", 
//		"XMLHttpRequest");
//
//	web_custom_request("KeepAlive", 
//		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Home/KeepAlive", 
//		"Method=HEAD", 
//		"Resource=0", 
//		"RecContentType=text/html", 
//		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
//		"Snapshot=t19.inf", 
//		"Mode=HTML", 
//		LAST);

	lr_end_transaction("CAD_BP3_15_Home",LR_AUTO);




	return 0;
}