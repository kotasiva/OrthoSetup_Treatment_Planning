﻿vuser_end()
{
	
	lr_think_time(15);

	lr_start_transaction("CAD_BP3_16_Close_CAD_App");

	ctrx_sync_on_window("CA Digital - CA Digital_2", ACTIVATE, 0, 0, 1281, 985, "snapshot124", CTRX_LAST);

	ctrx_mouse_click(1082, 44, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot126", CTRX_LAST);

	ctrx_mouse_click(1258, 10, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot127", CTRX_LAST);

	lr_think_time(5);

	ctrx_mouse_click(1258, 10, LEFT_BUTTON, 0, "CA Digital - CA Digital_2=snapshot128", CTRX_LAST);

	lr_think_time(10);

	ctrx_mouse_click(246, 994, RIGHT_BUTTON, 0, "NULL=snapshot130", CTRX_LAST);

	ctrx_sync_on_window("246_524_314_471", CREATE, 246, 524, 314, 471, "snapshot131", CTRX_LAST);

	ctrx_mouse_click(324, 900, LEFT_BUTTON, 0, "NULL=snapshot132", CTRX_LAST);

	ctrx_sync_on_window("Task Manager", ACTIVATE, 163, 156, 366, 366, "snapshot133", CTRX_LAST);

	ctrx_mouse_click(18, 341, LEFT_BUTTON, 0, "Task Manager=snapshot134", CTRX_LAST);

	lr_think_time(10);

	ctrx_sync_on_window("Task Manager", ACTIVATE, 163, 156, 667, 594, "snapshot135", CTRX_LAST);

	ctrx_mouse_click(71, 189, LEFT_BUTTON, 0, "Task Manager=snapshot136", CTRX_LAST);

	ctrx_mouse_click(71, 189, RIGHT_BUTTON, 0, "Task Manager=snapshot137", CTRX_LAST);

	ctrx_sync_on_window("234_345_185_197", CREATE, 234, 345, 185, 197, "snapshot138", CTRX_LAST);

	ctrx_mouse_click(110, 227, LEFT_BUTTON, 0, "Task Manager=snapshot139", CTRX_LAST);

	lr_think_time(15);

	ctrx_sync_on_window("Task Manager", ACTIVATE, 163, 156, 667, 594, "snapshot140", CTRX_LAST);

	ctrx_mouse_click(655, 19, LEFT_BUTTON, 0, "Task Manager=snapshot141", CTRX_LAST);

	ctrx_mouse_click(886, 391, LEFT_BUTTON, 0, "NULL=snapshot142", CTRX_LAST);

	lr_end_transaction("CAD_BP3_16_Close_CAD_App",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("CAD_BP3_17_Close_Citrix_Server");

	ctrx_logoff(CTRX_NORMAL_LOGOFF, CTRX_LAST);

	lr_end_transaction("CAD_BP3_17_Close_Citrix_Server",LR_AUTO);

	
	
	
	lr_think_time(10);

	

	
	lr_start_transaction("CAD_02_Logout");

	web_add_cookie("CtxsDesktopAutoLaunchDone=no; DOMAIN=storefront.smileco.com");

	lr_think_time(12);

	web_custom_request("Disconnect", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Sessions/Disconnect", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("Logoff", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Authentication/Logoff", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	lr_end_transaction("CAD_02_Logout",LR_AUTO);

	
	
	
	return 0;
}
